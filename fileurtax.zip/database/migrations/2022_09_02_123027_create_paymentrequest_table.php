<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentrequestTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('paymentrequest', function (Blueprint $table) {
            $table->id();
            $table->string('consultationId',15);
            $table->string('customerId',15);
            $table->string('status',15);
            $table->string('paymentStatus',15);
            $table->string('requestDate');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('paymentrequest');
    }
}
