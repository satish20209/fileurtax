<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiceprovidercsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('serviceprovidercs', function (Blueprint $table) {
            $table->id();
            $table->string('recognitions')->nullable();
            $table->string('registrationNumber')->nullable();
            $table->string('pancard')->nullable();
            $table->string('aadhaarcard')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('country')->nullable();
            $table->string('experience')->nullable(); 
            $table->string('pincode')->nullable();
            $table->string('address')->nullable();
            $table->string('description')->nullable();
            $table->string('registrationCertificate')->nullable();
            $table->string('facebook')->nullable();
            $table->string('twitter')->nullable();
            $table->string('linkedin')->nullable();
            $table->string('publication_areas_1')->nullable();
            $table->string('publication_areas_2')->nullable();
            $table->string('publication_areas_3')->nullable();
            $table->string('monday')->nullable();
            $table->string('tuesday')->nullable();
            $table->string('wednesday')->nullable();
            $table->string('thursday')->nullable();
            $table->string('friday')->nullable();
            $table->string('saturday')->nullable();
            $table->string('sunday')->nullable();
            $table->string('userId');
            $table->string('pancardpic')->nullable();
            $table->string('aadharpic')->nullable();
            $table->string('services')->nullable();
            $table->string('lat')->nullable();
            $table->string('longt')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('serviceprovidercs');
    }
}
