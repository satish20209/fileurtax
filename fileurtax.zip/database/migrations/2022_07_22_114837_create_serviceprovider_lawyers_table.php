<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiceproviderLawyersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('serviceprovider_lawyers', function (Blueprint $table) {
            $table->id();
            $table->string('practincingSince')->nullable();
            $table->string('amount')->nullable();
            $table->string('secondary_practice_area')->nullable();
            $table->string('country')->nullable();
            $table->string('barEnrollmentNumber')->nullable();
            $table->string('language')->nullable();
            $table->string('practice_state')->nullable();
            $table->string('state')->nullable();
            $table->string('enrollment_state')->nullable();
            $table->string('practice_Areas_primary')->nullable();
            $table->string('practice_courts')->nullable();
            $table->string('city')->nullable();
            $table->string('address')->nullable();
            $table->string('pincode')->nullable();
            $table->string('aadhaarcard')->nullable();
            $table->string('pancard')->nullable();
            $table->string('abouts')->nullable();
            $table->string('facebook')->nullable();
            $table->string('twitter')->nullable();
            $table->string('linkedin')->nullable();
            $table->string('publication_areas_1')->nullable();
            $table->string('publication_areas_2')->nullable();
            $table->string('publication_areas_3')->nullable();
            $table->string('monday')->nullable();
            $table->string('tuesday')->nullable();
            $table->string('wednesday')->nullable();
            $table->string('thursday')->nullable();
            $table->string('friday')->nullable();
            $table->string('saturday')->nullable();
            $table->string('sunday')->nullable();
            $table->string('barCouncildD')->nullable();
            $table->string('lat')->nullable();
            $table->string('longt')->nullable();
            $table->string('pancardpic')->nullable();
            $table->string('aadharpic')->nullable();
            $table->string('userId');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('serviceprovider_lawyers');
    }
}
