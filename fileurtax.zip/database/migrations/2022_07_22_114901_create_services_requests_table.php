<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServicesRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('services_requests', function (Blueprint $table) {
            $table->id();
            $table->string('customer_id');
            $table->string('service_provider_id')->nullable();
            $table->string('status')->nullable();
            $table->string('accept')->nullable();
            $table->string('requestDate');
            $table->string('apptime')->nullable();
            $table->string('appdate')->nullable();
            $table->string('timeperiod')->nullable();
            $table->string('fee')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('services_requests');
    }
}
