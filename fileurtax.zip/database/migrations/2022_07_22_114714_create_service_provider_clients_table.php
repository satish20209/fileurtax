<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiceProviderClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('service_provider_clients', function (Blueprint $table) {
            $table->id();
            $table->string('fname');
            $table->string('lname');
            $table->string('email');
            $table->string('password');
            $table->string('mobile');
            $table->string('dob');
            $table->string('qualification');
            $table->string('lat')->nullable();
            $table->string('longt')->nullable();
            $table->integer('parentService')->nullable();
            $table->integer('services')->nullable();
            $table->string('experience');
            $table->string('image')->nullable();
            $table->string('salary_range');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('service_provider_clients');
    }
}
