<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBookconsultaionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bookconsultaions', function (Blueprint $table) {
            $table->id();
            $table->string('country');
            $table->string('mobile');
            $table->string('email');
            $table->string('fname');
            $table->string('lname');
            $table->string('state');
            $table->string('city');
            $table->string('docs');
            $table->string('docs_type');
            $table->string('docs_language');
            $table->string('plane');
            $table->string('date');
            $table->string('time');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bookconsultaions');
    }
}
