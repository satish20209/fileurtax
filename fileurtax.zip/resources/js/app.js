const { default: Axios } = require('axios');
const { default: Echo } = require('laravel-echo');


require('./bootstrap');

const form = document.querySelector("#form");

form.addEventListener('submit',(e)=>{
    
    e.preventDefault();
        const fileinput = document.querySelector("#file_chat");        
    if(fileinput.value != ""){
        Axios.post('chatmsg',new FormData(form));
        $('.name-progress-box').addClass("d-none");
        $("#fileName").val("");
        form.reset();
       

    }else{
        Axios.post('chatmsg',new FormData(form));
        form.reset();
    }
    
});

const user_id = document.querySelector("#user_id");
const newuser_id = user_id.value;
const second_id = document.querySelector("#second_id");
const secuser_id = second_id.value;
const channelname = 'chat.'+secuser_id+'.'+newuser_id;

const channel = window.Echo.channel(channelname);
channel.subscribed().listen('.raj',(e)=>{
    console.log(e)
    const sender=localStorage.getItem('sender');
    
    var stlp = "";
    var cls = "";
    var stlli = "";
    
    if(sender==e.sendar){
        
        stlli = 'float: right;width: fit-content;height: fit-content;padding:5px;margin-bottom:16px !important;background:#e6f0f9;border-radius: 30px;border-top-right-radius: 0;';
        stlp = 'color: black; margin: 0px; padding: 5px; font-size: 18px;';
        cls = "m-0 p-2";
        
    }
    else{
        stlli = 'width: fit-content;height: fit-content;padding:5px;margin-bottom:16px !important;background:#fff0d9;border-radius: 30px;border-top-left-radius: 0;';
        stlp = 'color: black; margin: 0px; padding: 5px; font-size: 18px;';
        cls = "m-0 p-2";    
    }
    
    var chatbox = document.querySelector(".message-append");
        var li=document.createElement('LI');
            li.className = cls;
            li.style = stlli;
        var p=document.createElement('P');
        if(e.msg != null && e.filename  != null && e.filename != ''){
            p.innerHTML=e.msg+" "+"<span class=''>"+e.filename+"<i id='"+e.fileId+"' class='filedownloadss fa fa-download mt-1'></i></span>";
            p.style = stlp;
            li.insertAdjacentElement("beforeend",p);
            chatbox.insertAdjacentElement("beforeend",li);
            $(".chat-conversation").scrollTop($(".chat-conversation")[0].scrollHeight);
        } else if(e.filename != null && e.filename != ''){
            console.log(e)
            p.innerHTML="<span  class=''>"+e.filename+"<i  id="+e.fileId+" class='filedownloadss fa fa-download mt-1'></i></span>";
            p.style = stlp;
            li.insertAdjacentElement("beforeend",p);
            chatbox.insertAdjacentElement("beforeend",li);
            $(".chat-conversation").scrollTop($(".chat-conversation")[0].scrollHeight);
        } else if(e.msg != null){
            p.innerHTML=e.msg;
            p.style = stlp;
            li.insertAdjacentElement("beforeend",p);
            chatbox.insertAdjacentElement("beforeend",li);
            $(".chat-conversation").scrollTop($(".chat-conversation")[0].scrollHeight);
        } 
        $(".filedownloadss").each(function(){
            $(this).click(function(){ 
                $.ajax({
                    type: "GET",
                    url: "/getChatFilename",
                    dataType: "json",
                    data:{'id':$(this).attr('id')},
                    success: function (response) {
                        var data = response.data.chanelId.split('-');
                        $('#downloadbtn').attr('href','download/'+data[0]+'_'+data[1]+'/'+response.data.filechat)
                        var ancoorbtn=document.getElementById('downloadbtn');                          
                        ancoorbtn.click(); 
                    },
                });
            })
        })
              
});
