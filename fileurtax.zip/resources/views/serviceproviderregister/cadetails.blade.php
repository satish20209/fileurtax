<x-home.topbar/>
<x-home.header/>
@section('token')
{{$token}}
@endsection
@section('country')
@foreach ($country as $key => $values)
    @php
        $values = (array) $values;
    @endphp
    <option value="{{ $values['state_name'] }}">{{ $values['state_name'] }}
    </option>
@endforeach
@endsection
    <x-detailspages.ca/>
<x-home.footer/>