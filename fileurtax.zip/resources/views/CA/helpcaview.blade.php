<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CA Help - FileUrTax</title>
</head>
<body>
    <div class="container-scroller" id="app">
        <x-CA.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-CA.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              {{-- Main Dashboard Content --}}
              <x-CA.helpca/>
              {{-- Main Dashboard Content End --}}
            </div>
            <x-CA.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
      
</body>
</html>
