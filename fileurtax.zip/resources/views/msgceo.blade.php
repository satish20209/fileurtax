@section("title")
FileUrTax | MESSAGE FROM THE CEO
@endsection
<x-home.topbar/>
<x-home.header/>
<x-home.msgceo/>
<x-home.footer/>