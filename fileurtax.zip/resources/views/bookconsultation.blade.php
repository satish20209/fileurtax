
{{-- add -breadcrumbs  --}}
@section("title")
Book a consultation with experts from FileUrTax by filling in your details along with the consultation package and scheduling your appointment with us.
@endsection

@section("description")
Book consultations regarding returning ITR, GST filing, GST registration process, registration of Private Limited Company, or for any other legal advice.

@endsection
@section("keywords")
return itr,e file itr,filing gst return,income tax e file website,gst filing,gst registration online,gst registration process,incometax e file,online gst apply,company registered in india,registration of pvt ltd company,lawyers near me,corporation tax,constitutional lawyer,legal advice,property law
@endsection


<link rel="icon" type="image/x-icon" href="{{ asset('images/favicon.ico') }}">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>
<script src="js/bookconsultaion.js?cache=<?php echo time(); ?>"> </script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="js/cities.js"></script>
<x-home.topbar />
<x-home.header />



<!-- Page Title -->
<section class="page-title" style="background-image:url(images/background/1.jpg)">
    <div class="auto-container">
        <h1>Book Consultation</h1>
        <ul class="page-breadcrumb">
            <li><a href="/">Home</a></li>
            <li>Book Consultation</li>
        </ul>
    </div>
</section>
<!-- End Page Title -->

<div class="p-1 p-md-5 p-sm-5 p-lg-5" p>
    <div class="text-center mb-4 mt-5">
        <h2 class="hedding-all-page">Schedule a consultation with our team in a jiffy and get your doubts cleared.</h2>
        <h5>Schedule an appointment and clear your doubts.</h5>
    </div>
        @if (session("successMessage"))
                <div class="alert alert-success">
                    {{ session('successMessage') }}
                </div>
                @elseif (session("faildMessae"))
            <div class="alert alert-danger">
                {{ session('faildMessae') }}
            </div>
        @endif
        @php
            Session::forget('successMessage');
            Session::forget('faildMessae');
        @endphp
    <div class="shadow bg-transparent">
        {{-- top text --}}
        <div class="w-100 p-3 d-flex justify-content-between " style="background: rgb(243, 240, 240)">
            <h5 class="hedding-h5">Your Information</h5>
            <i class="-times-circle-o text-primary" style="font-size: 20px"></i>
        </div>
        <div class="w-100 p-3 border" style="background:rgb(223, 241, 233)">
            <div class="progress mb-3">
                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"
                    style="width:100%">
                    <span class="sr-only">100% Complete</span>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-4">
                    <h6 class="hedding-h5">Your Information</h6>
                    <small>Enter Details</small>
                </div>
                <div class="col-4">
                    <h6 class="hedding-h5">Select Consultation Plan</h6>
                    <small>Choose Your Consultation and Upload Documents</small>
                </div>
                <div class="col-4">
                    <h6 class="hedding-h5">Schedule Date/Time</h6>
                    <small>Schedule Appointment</small>
                </div>
            </div>


        </div>
        {{-- end top tet --}}
        {{-- form code --}}
        <div>
            
            <div class="row section-first ">
                <div class="col-12 col-md-6 col-sm-6 col-lg-6">
                    <form action="/bookconsultaionfun" method="POST" class="bookconsultaion-form">
                        @csrf
                        <div class="p-4">
                            <p>Please enter your contact details</p>
                            <div class="row">
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label for="email" class="form-label"><span class="text-danger">*</span>Country</label>
                                        <select class="form-select countrycode" value="india" name="country" >
                                            <option selected value="+91">India</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col">
                                    <label for="mobile" class="form-label"><span class="text-danger">*</span>Phone No</label>
                                    <input type="text" id="number" class="form-control required1 mobile" placeholder="Enter Your Phone No." name="mobile" >
                                    
                                </div>


                                {{-- code for otp --}}
                                <div class="row mb-2 d-none">
                                    <div id="recaptcha-container" class="col"></div>
                                    <div class="mr-1 mt-4 col">
                                      <button type="button" onclick="sendOTP();" class="btn btn-success">Send OTP</button>
                                    </div>
                              </div>
                              
                              <div class="verify_div d-none mb-2 row">
                                    <div class="col">
                                            <label for="mobile" class="form-label"><span class="text-danger">*</span>Enter Otp</label>
                                            <input type="text" id="verification" class="form-control" placeholder="******">
                                    </div>
                                    <div class=" mr-1 mt-4 col">
                                        <button type="button" onclick="verify()" class="btn btn-success">Verify</button>
                                    </div>
                                </div>

                              {{-- end code for otp --}}

                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label"><span class="text-danger">*</span>Email Id</label>
                                <input type="email" class="form-control required2" id="email" name="email"  placeholder="Email Id" >
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label for="fname" class="form-label"><span class="text-danger">*</span>Your First Name</label>
                                        <input type="text" class="form-control required3" maxlength="15" minlength="3" id="fname" placeholder="Enter First Name" name="fname">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label for="lname" class="form-label"><span class="text-danger">*</span>Your Last Name</label>
                                        <input type="text" class="form-control required4" id="lname" placeholder="Enter Last Name" name="lname">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label for="email" class="form-label"><span class="text-danger">*</span>State</label>
                                        
                                        <select  id="sts" name="state" class="form-select select-state"  ></select>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="mb-3">
                                        <label for="email" class="form-label"><span class="text-danger">*</span>City</label>
                                        <select id="city_names" class="form-select select-city" name="city">
                                            <option  selected="selected">Select City</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                </div>
                <div class="col-12 col-md-6 col-sm-6 col-lg-6">
                    <div class="p-4">
                        <h6><span class="text-danger">*</span>Do You Have Paper With You ?</h6>

                        <div class="form-check mb-3 d-flex justify-content-around" style="width:39%">
                            <div >
                                <input class="form-check-input" type="radio" id="yes" value="yes" name="docs" required>
                                <label for="yes" class="mr-2">Yes</label>
                            </div>
                            <div >
                                <input class="form-check-input" type="radio" checked id="no" value="no" name="docs" required>
                                <label for="no">No</label>
                            </div>
                        </div>
                        <h6 class="mt-2"><span class="text-danger">*</span>In which format the documents are available ?</h6>
                        <div class="form-check mb-3 d-flex justify-content-around " style="width:39%">
                            <div >
                                <input class="form-check-input" type="radio" id="yes" value="yes" name="docs_type" required>
                                <label for="yes" class="mr-2 ">Yes</label>
                            </div>
                            <div >
                                <input class="form-check-input" type="radio" checked id="no" value="no" name="docs_type" required>
                                <label for="no">No</label>
                            </div>
                        </div>
                        <h6><span class="text-danger">*</span>Language Of Document ?</h6>
                        <select class="form-select mb-3" name="docs_language" required>
                            <option selected>English</option>
                            <option value="1">Hindi</option>
                            <option value="2">Urdu</option>
                            <option value="3">Bengali</option>
                            <option value="3">Marathi</option>
                            <option value="3">Telugu</option>
                            <option value="3">Tamil</option>
                            <option value="3">Gujarati</option>
                            <option value="3">Urdu</option>
                            <option value="3">Kannada</option>
                            <option value="3">Odia</option>
                            <option value="3">Malayalam</option>
                            <option value="3">Punjabi</option>
                            <option value="3">Assamese</option>
                        </select>
                        
                        <button type="button" class="btn btn-primary fisrt-btn-con">Save & Next</button>
                    </div>

                    
                </div>
            
            
            </div>

            <div class="section-second d-none">
                <div class=" p-3">
                    <table class="table p-3 table-striped table-bordered border-dark ">
                        <tbody>
                            <tr class="p-5">
                                <td class="pb-3 pt-4">
                                    <input class="form-check-input p-0 m-0 me-2 amount" type="radio" id="yes" value="999 60 Minutes" name="plane" required> 
                                    <span class="hedding-table"><span class="text-danger">*</span>60 Minutes</span>
                                </td>
                                <td class="pb-3 pt-4">
                                    <span class="hedding-table-sv">Savings &#8377; 981 </span>
                                </td>
                                <td class="pb-3 pt-4">
                                    <span class="hedding-table-sv"> Valid for 30 days</span>
                                </td>
                                <td class="pb-3 pt-4">
                                    <span class="hedding-table">&#8377; 999</span>
                                    <small>(16.6/min)</small>
                                </td>
                            </tr>
                            <tr>
                                <td class="pb-3 pt-4">
                                    <input class="form-check-input p-0 m-0 me-2 amount" type="radio" id="yes" value="849 45 Minutes" name="plane" checked required>
                                    <span class="hedding-table"><span class="text-danger">*</span>45 Minutes</span> <span class="text-danger"> Most
                                        popular</span>
                                </td>
                                <td class="pb-3 pt-4"> <span class="hedding-table-sv" >Savings &#8377; 645 </span></td>
                                <td class="pb-3 pt-4">
                                    <span class="hedding-table-sv">Valid for 30 days</span>
                                </td>
                                <td class="pb-3 pt-4">
                                    <span class="hedding-table">&#8377; 849</span>
                                    <small>(18.6/min)</small>
                                </td>
                            </tr>
                            <tr>
                                <td class="pb-3 pt-4">
                                    <input class="form-check-input p-0 m-0 me-2 amount" type="radio" id="yes" value="699 30 Minutes" name="plane" required>
                                    <span class="hedding-table"><span class="text-danger">*</span>30 Minutes</span>
                                </td>
                                <td class="pb-3 pt-4">
                                    <span class="hedding-table-sv">Savings &#8377; 302 </span>
                                </td>
                                <td class="pb-3 pt-4">
                                    <span class="hedding-table-sv">Valid for 30 days</span>
                                </td>
                                <td class="pb-3 pt-4">
                                    <span class="hedding-table">&#8377; 699</span>
                                    <small>(23.6/min)</small>
                                </td>
                            </tr>
                        </tbody>
                      </table>
                      <div>
                        <button type="button" class="btn btn-primary fisrt-btn-con-back">Back</button>
                        <button type="button" class="btn btn-primary me-auto second-btn-con" style="float: right">Save & Next</button>
                    </div>
                </div>
            </div>

            <div class="section-three p-5 d-none">
                <div class="mb-3">
                    <span class="date-time-span"><span class="text-danger">*</span>Date</span>
                    <input type="date"  id="date-input"  name="date" min="<?php echo date("Y-m-d"); ?>" class="form-control" placeholder="DD-MM-YYYY">
                </div>
                
               <div class="mb-3">
                <span class="date-time-span"><span class="text-danger">*</span>Time</span>
                <input type="time" id="time-input"  name="time" class="form-control" placeholder="12:01:00">
               </div>
                    <div>
                        <button type="button" class="btn btn-primary me-auto second-btn-con-back">Back</button>
                        <button class="btn btn-primary booknow" type="button" style="float: right" > Book Now</button>
                    </div>
                </form>
            </div>
        </div>
        {{-- end form code --}}
    </div>
</div>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script>
    $('.mobile').on('keypress', function(e) {
            var $this = $(this);
            var regex = new RegExp("^[0-9\b]+$");
            var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
            // for 10 digit number only
            if ($this.val().length > 9) {
                e.preventDefault();
                return false;
            }
            if (e.charCode < 54 && e.charCode > 47) {
                if ($this.val().length == 0) {
                    // warning for validate mobile number
                    e.preventDefault();
                    return false;
                } else {
                    return true;
                }

            }
            if (regex.test(str)) {
                return true;
            }
            e.preventDefault();
            return false;
        });

    $("#email").on("change",function(){
    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        if(!this.value.match(regex)){
        alert("enter valid email id")
        $("#email").val("");
        }
    });
</script>
<x-home.footer />