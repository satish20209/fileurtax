@php
$email = "";
if(session('caAuth')){
    $email = session('caAuth');
    ;
}elseif (session('csAuth')) {
    $email = session('csAuth');
    
}
elseif (session('cmaAuth')) {
    $email = session('cmaAuth');
    
}
elseif (session('layerAuth')) {
    $email = session('layerAuth');
    
}
$laywerDetails =DB::table('members')->where('email',$email)->first();
$serviceRequestsExists="";
    if($laywerDetails){
        $serviceRequests = DB::table('services_requests')->where(['service_provider_id' => $laywerDetails->id,'status' => '1',])->orderBy('id','desc')->get();
        $serviceRequestsExists = DB::table('services_requests')->where(['service_provider_id' => $laywerDetails->id,'status' => '1',])->exists();
    }
@endphp
@if (session("cmaAuth"))
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CMA Chat - FileUrTax</title>
</head>
<body token="{{ csrf_token() }}">
    <div class="container-scroller" id="app">
        <x-CMA.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-CMA.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              {{-- Main Dashboard Content --}}
              <div>
                <ol>
                    @if($serviceRequestsExists)
                        @foreach ($serviceRequests as  $alldata)
                        @php
                            $user_fname = DB::table('members')->where('id', $alldata->customer_id)->first('fname')->fname;
                        @endphp
                            <li><a href="/chat?id=consl-{{Crypt::encrypt($laywerDetails->id)}},user-{{Crypt::encrypt($alldata->customer_id)}}">{{ $user_fname }}</a></li>
                        @endforeach
                    @endif
                </ol>
            </div>
              {{-- Main Dashboard Content End --}}
            </div>
            <x-CMA.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
</body>
</html>
@elseif(session("csAuth"))
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CS Chat - FileUrTax</title>
</head>
<body>
    <div class="container-scroller" id="app">
        <x-CS.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-CS.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              {{-- Main Dashboard Content --}}
              <div>
                <ol>
                    @if($serviceRequestsExists)
                        @foreach ($serviceRequests as  $alldata)
                        @php
                            $user_fname = DB::table('members')->where('id', $alldata->customer_id)->first('fname')->fname;
                        @endphp
                        
                            <li><a href="/chat?id=consl-{{Crypt::encrypt($laywerDetails->id)}},user-{{Crypt::encrypt($alldata->customer_id)}}">{{ $user_fname }}</a></li>
                        @endforeach
                    
                    @endif
                </ol>
            </div>
              {{-- Main Dashboard Content End --}}
            </div>
            <x-CS.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
</body>
</html>
@elseif(session("caAuth"))
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CA Chat - FileUrTax</title>
</head>
<body>
    <div class="container-scroller" id="app">
        <x-CA.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-CA.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              <div>
                <ol>
                    @if($serviceRequestsExists)
                        @foreach ($serviceRequests as  $alldata)
                        @php
                            $user_fname = DB::table('members')->where('id', $alldata->customer_id)->first('fname')->fname;
                        @endphp
                        
                            <li><a href="/chat?id=consl-{{Crypt::encrypt($laywerDetails->id)}},user-{{Crypt::encrypt($alldata->customer_id)}}">{{ $user_fname }}</a></li>
                        @endforeach
                    
                    @endif
                </ol>
            </div>
              {{-- Main Dashboard Content End --}}
            </div>
            <x-CA.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
</body>
</html>
@elseif(session("layerAuth"))
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lawyer Chat - FileUrTax</title>
</head>
<body>
  
  <div class="container-scroller" id="app">
        <x-lawyer.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-lawyer.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              {{-- Main Dashboard Content --}}
              <div>
                <ol>
                    @if($serviceRequestsExists)
                        @foreach ($serviceRequests as  $alldata)
                        @php
                            $user_fname = DB::table('members')->where('id', $alldata->customer_id)->first('fname')->fname;
                        @endphp
                        
                            <li><a href="/chat?id=consl-{{Crypt::encrypt($laywerDetails->id)}},user-{{Crypt::encrypt($alldata->customer_id)}}">{{ $user_fname }}</a></li>
                        @endforeach
                    
                    @endif
                </ol>
            </div>
              {{-- Main Dashboard Content End --}}
            </div>
            <x-lawyer.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
</body>
</html>
@endif