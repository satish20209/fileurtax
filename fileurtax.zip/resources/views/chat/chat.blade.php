<?php header('Access-Control-Allow-Origin: *'); ?>
<!DOCTYPE html>
<html lang="en">
    {{-- ⚠️ --}}
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="images/favicon.ico">
    {{-- <meta name="csrf-token" content="{{ csrf_token() }}" /> --}}

    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <title>Chat | Fileurtax</title>
    <script src="https://sdk.amazonaws.com/js/aws-sdk-2.770.0.min.js"></script>
    <link rel="stylesheet" href="prograsebar/jQuery-plugin-progressbar.css">
	

</head>

<body token="{{ csrf_token() }}">
    @php
        if (str_starts_with(request()->get('id'), 'consl')) {
            $data = explode(',', request()->get('id'));
            $consul_id = Crypt::decrypt(explode('-', $data[0])[1]);
            $user_id = Crypt::decrypt(explode('-', $data[1])[1]);
            $send = $consul_id;
        } elseif (str_starts_with(request()->get('id'), 'user')) {
            $data = explode(',', request()->get('id'));
            $user_id = Crypt::decrypt(explode('-', $data[0])[1]);
            $consul_id = Crypt::decrypt(explode('-', $data[1])[1]);
            $send = $user_id;
        }
    @endphp
    <div id="layout-wrapper">
        <header id="page-topbar">
            <div class="navbar-header">
                <div class="d-flex">
                    <!-- LOGO -->
                    <div class="navbar-brand-box">
                        <a href="index.html" class="logo logo-dark">
                            <span class="logo-sm">
                                <img src="images/logo-cmp.png" alt="" width="100">
                            </span>
                            <span class="logo-lg">
                                <img src="images/logo-cmp.png" alt="" width="100">
                            </span>
                        </a>
                        <a href="index.html" class="logo logo-light">
                            <span class="logo-sm">
                                <img src="images/logo-cmp.png" alt="" width="150">
                            </span>
                            <span class="logo-lg">
                                <img src="images/logo-cmp.png" alt="" width="100">
                            </span>
                        </a>
                    </div>
                    <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect"
                        id="vertical-menu-btn">
                        <i class="fa fa-fw fa-bars"></i>
                    </button>
                </div>
                <div class="d-flex">
                    <div class="dropdown d-inline-block">
                        <button type="button" class="btn header-item noti-icon waves-effect"
                            id="page-header-notifications-dropdown" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <i class="bx bx-bell bx-tada"></i>
                            <span class="badge bg-danger rounded-pill">0</span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                            aria-labelledby="page-header-notifications-dropdown">
                            <div class="p-3">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h6 class="m-0" key="t-notifications"> Notifications </h6>
                                    </div>
                                    <div class="col-auto">
                                        <a href="#!" class="small" key="t-view-all"> View All</a>
                                    </div>
                                </div>
                            </div>
                            <div data-simplebar style="max-height: 230px;">
                                <a href="javascript: void(0);" class="text-reset notification-item">
                                    <div class="d-flex">
                                        <div class="avatar-xs me-3">
                                            <span class="avatar-title bg-primary rounded-circle font-size-16">
                                                <i class="bx bx-cart"></i>
                                            </span>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1" key="t-your-order">No Message</h6>
                                            <div class="font-size-12 text-muted">
                                                <p class="mb-1" key="t-grammer">No Message</p>
                                                <p class="mb-0"><i class="mdi mdi-clock-outline"></i> <span
                                                        key="t-min-ago">0 Min Ago</span></p>
                                            </div>
                                        </div>
                                    </div>
                                </a>

                            </div>
                            <div class="p-2 border-top d-grid">
                                <a class="btn btn-sm btn-link font-size-14 text-center" href="javascript:void(0)">
                                    <i class="mdi mdi-arrow-right-circle me-1"></i> <span key="t-view-more">View
                                        More..</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="dropdown d-inline-block">
                        <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="rounded-circle header-profile-user" src="images/guest-user.png"
                                alt="Header Avatar">
                            <span class="d-none d-xl-inline-block ms-1" key="t-henry"></span>
                            <i class="mdi mdi-chevron-down d-none d-xl-inline-block"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end">
                            <!-- item-->
                            <a class="dropdown-item" href="login"><i
                                    class="bx bx-user font-size-16 align-middle me-1"></i> <span
                                    key="t-profile">Profile</span></a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="/customerLogOut"><i
                                    class="bx bx-power-off font-size-16 align-middle me-1 text-danger"></i> <span
                                    key="t-logout">Logout</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="vertical-menu">
            <div data-simplebar class="h-100">
                <div id="sidebar-menu">
                    <!-- Left Menu Start -->
                    <ul class="metismenu list-unstyled" id="side-menu">
                        <li class="menu-title" key="t-menu">Menu</li>
                        <li>
                            @if (session('cmaAuth'))
                                <a href="cmaDashboard" class="waves-effect">
                                    <i class="mdi mdi-view-dashboard text-primary" style="font-size: 16px"></i>
                                    <span class="menu-title" style="font-size: 16px">Dashboard</span>
                                </a>
                            @elseif(session('csAuth'))
                                <a href="csDashboard" class="waves-effect">
                                    <i class="mdi mdi-view-dashboard text-primary" style="font-size: 16px"></i>
                                    <span class="menu-title" style="font-size: 16px">Dashboard</span>
                                </a>
                            @elseif(session('caAuth'))
                                <a href="caDashboard" class="waves-effect">
                                    <i class="mdi mdi-view-dashboard text-primary"></i>
                                    <span class="menu-title">Dashboard</span>
                                </a>
                            @elseif(session('layerAuth'))
                            @php
                               $fnameid = $user_id;
                            @endphp
                                <a href="lawyerDashboard" class="waves-effect">
                                    <i class="mdi mdi-view-dashboard text-primary" style="font-size: 16px"></i>
                                    <span class="menu-title" style="font-size: 16px">Dashboard</span>
                                </a>
                            @elseif(session('customerAuth'))
                            @php
                               $fnameid = $consul_id;
                            @endphp
                                <a href="customerDashboard" class="waves-effect">
                                    <i class="mdi mdi-view-dashboard text-primary" style="font-size: 16px"></i>
                                    <span class="menu-title" style="font-size: 16px">Dashboard</span>
                                </a>
                            @endif
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="main-content mt-5">
            <div class="container-fluid">
                <div class="d-lg-flex">
                    <div class="chat-leftsidebar me-lg-4 d-none">
                        <div class="">
                            <div class="chat-leftsidebar-nav">
                                <ul class="nav nav-pills nav-justified">
                                    <li class="nav-item">
                                        <a href="#chat" data-bs-toggle="tab" aria-expanded="true"
                                            class="nav-link active">
                                            <i class="bx bx-chat font-size-20 d-sm-none"></i>
                                            <span class="d-none d-sm-block">Chat</span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="search-box chat-search-box py-4">
                                    <div class="position-relative">
                                        <input type="text" class="form-control" placeholder="Search...">
                                        <i class="bx bx-search-alt search-icon"></i>
                                    </div>
                                </div>
                                <div class="tab-content py-4">
                                    <div class="tab-pane show active" id="chat">
                                        <div>
                                            <h5 class="font-size-14 mb-3">Recent</h5>
                                            <ul class="list-unstyled chat-list" data-simplebar
                                                style="max-height: 410px;">
                                                <li class="active">
                                                    <a href="javascript: void(0);">
                                                        <div class="d-flex">
                                                            <div class="flex-shrink-0 align-self-center me-3">
                                                                <i class="mdi mdi-circle font-size-10"></i>
                                                            </div>
                                                            <div class="flex-shrink-0 align-self-center me-3">
                                                                <img src="images/guest-user.png"
                                                                    class="rounded-circle avatar-xs" alt="">
                                                            </div>

                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="text-truncate font-size-14 mb-1">Steven
                                                                    Franklin</h5>
                                                                <p class="text-truncate mb-0">Hey! there I'm available
                                                                </p>
                                                            </div>
                                                            <div class="font-size-11">05 min</div>
                                                        </div>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-100 user-chat mt-4">
                        <div class="card">
                            <div class="p-3 border-bottom ">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="d-flex justify-content-between">

                                        <h5 class="font-size-15 mb-1">
                                            @php
                                                $fname = DB::table("members")->where("id",$fnameid)->first()->fname;
                                            @endphp
                                            {{$fname}}
                                        </h5>
                                        <p class="text-muted mb-0"><i class="mdi mdi-circle text-success align-middle me-1"></i> Active now</p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="chat-conversation p-3 overflow-auto mb-4" style="height: 66vh">
                                    <ul class="list-unstyled message-append mb-0" data-simplebar
                                        style="max-height: 486px;">
                                        @php
                                            $user = DB::table('chats')
                                                ->where('chanelId', $user_id . '-' . $consul_id)
                                                ->get();
                                            
                                        @endphp
                                        @foreach ($user as $msgdata)
                                            @if ($msgdata->sender == $send)
                                                <li class="m-0 p-2" style="float: right;background:#e6f0f9;width: fit-content; height: fit-content; padding: 5px; margin-bottom: 16px !important;border-radius: 30px;border-top-right-radius: 0;">
                                                    <p style="color: black; margin: 0px; padding: 5px; font-size: 18px;">
                                                        {{ $msgdata->msg}}
                                                        @if ($msgdata->filechat)
                                                            {{ $msgdata->filechat }}
                                                            <a href="download/{{ $user_id }}_{{ $consul_id }}/{{ $msgdata->filechat }}"
                                                                download target="_blank"> <i
                                                                    class='fa fa-download mt-1'></i></a>
                                                        @endif
                                                    </p>
                                                </li>
                                            @else
                                                <li class="m-0 p-2"
                                                    style="background:#fff0d9;width: fit-content; height: fit-content; padding: 5px; margin-bottom: 16px !important;border-radius: 30px;border-top-left-radius: 0;">
                                                    <p
                                                        style="color: black; margin: 0px; padding: 5px; font-size: 18px;">
                                                        {{ $msgdata->msg }}
                                                        @if ($msgdata->filechat)
                                                            {{ $msgdata->filechat }}
                                                            <a href="download/{{ $user_id }}_{{ $consul_id }}/{{ $msgdata->filechat }}"
                                                                download target="_blank"><i
                                                                    class='fa fa-download mt-1'></i></a>
                                                        @endif
                                                    </p>
                                                </li>
                                            @endif
                                        @endforeach
                                        <a hidden id="downloadbtn" href="google.com" download></a>
                                    </ul>
                                </div>
                                <div class="chat-input-section">
                                    <div class="row">
                                        <div class="col m-0">
                                            <div class="position-relative">
                                                {{-- <div class="progress">
                                                    <div class="progress-bar"></div>
                                                </div>
                                                <div id="uploadStatus"></div> --}}
                                                <form id="form" enctype="multipart/form-data">
                                                    @csrf
                                                    <input type="hidden" id="fileName" name="filechat">
                                                    <input type="hidden" name="to" id="user_id" value="{{ $consul_id }}">
                                                    <input type="hidden" name="from" id="second_id" value="{{ $user_id }}">
                                                    <input type="hidden" id='sender' name="sender" value="{{ $send }}">
                                                    <div class="chat-input-live p-2">
                                                        <input type="text" class="w-100 form-control" name="msg" placeholder="Enter Message..." id="msg" autocomplete="off">
                                                            
                                                        <div class="d-flex name-progress-box d-none">
                                                            <p class="mt-2 bg-primary p-1 text-white rounded filename_show me-3 d-none"></p>
                                                            <div class="progress-bar position mt-3"></div>
                                                        </div>
                                                    </div>

                                                    <div class="chat-input-links" id="tooltip-container">
                                                        <ul class="list-inline mb-0">
                                                            <li class="list-inline-item upload-files-chat"><a
                                                                    href="javascript: void(0);" title="Add Files"><i
                                                                        class="mdi mdi-file-document-outline"></i></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                            </div>
                                        </div>
                                        <div class="col-auto mt-2 m-0 me-3">
                                            <button
                                                type="submit"class="btn btn-primary btn-rounded chat-send w-md waves-effect waves-light "><span
                                                    class="d-none d-sm-inline-block">Send</span> <i
                                                    class="mdi mdi-send"></i></button>
                                            </form>
                                            <form class="chatfile">
                                                @csrf
                                                <input type="file" name="chatfile" chanelId="{{ $user_id }}_{{ $consul_id }}" class="d-none" id="file_chat">
                                                <input type="hidden" name="filename" id="automatic-filename">
                                                <input type="hidden" name="foldername" value="fileurtax/chat/{{ $user_id }}_{{ $consul_id }}">
                                                <button class="chatfile_btn" type="submit"></button>
                                            </form>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- end row -->
            </div>
            <!-- container-fluid -->
        </div>
    </div>
    <script>
        localStorage.setItem('sender', {{ $send }});
        window.onload = function() {
            $(".chat-conversation").scrollTop($(".chat-conversation")[0].scrollHeight);
        }
    </script>
    <script src="assets/libs/jquery/jquery.min.js"></script>
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="assets/js/app.js"></script>
    <script src="js/app.js"></script>
    <script src="prograsebar/jQuery-plugin-progressbar.js"></script>
</body>

</html>
