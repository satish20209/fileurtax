<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Super Admin Consultants | FILEURTAX</title>
    <link rel="stylesheet" href="css/superAdmin/materialdesignicons.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/superAdmin/perfect-scrollbar.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/superAdmin/app.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@6.9.96/css/materialdesignicons.css">
</head>
<body>
    <div class="container-scroller" id="app">
        <x-superAdmin.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-superAdmin.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              {{-- Main Dashboard Content --}}
              <x-superAdmin.superAdminViewConsultants/>
              {{-- Main Dashboard Content End --}}
            </div>
            <x-superAdmin.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
      <script src="js/app.js?cache=<?php echo time(); ?>"></script>
      <script src="js/perfect-scrollbar.min.js?cache=<?php echo time(); ?>"></script>
      <script src="js/off-canvas.js?cache=<?php echo time(); ?>"></script>
      <script src="js/hoverable-collapse.js?cache=<?php echo time(); ?>"></script>
      <script src="js/misc.js?cache=<?php echo time(); ?>"></script>
      <script src="js/settings.js?cache=<?php echo time(); ?>"></script>
      <script src="js/todolist.js?cache=<?php echo time(); ?>"></script>
</body>
</html>
