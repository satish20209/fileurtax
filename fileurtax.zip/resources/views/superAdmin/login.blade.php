<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
        integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
   rel="stylesheet">
   <link rel="stylesheet" href="css/admin.css?cache=<?php echo time(); ?>">
   <title>Super Admin | Login </title>
</head>
<body style="background-image: url('../images/adminbg.jpg');background-size:cover">
        <div class="conn-login-main">
            <div class="conn-h4">
                <h1 class="text-center admin-h4">SUPER ADMIN LOGIN</h1>
            </div>
            <div class="conn-form">
                <h5 class="admin-h5 text-center">WELCOME TO FILEURTAX</h5>
                {{-- <form action="{{route('superAdminAuth')}}" method="POST"> --}}
                    @csrf
                    <input class="form-control mb-3" id="email" type="email" name="email" placeholder="Enter Your Email"
                    autocomplete="off" oninput="removeEmailError()" required>
                    <div id="emailInvalid" class="text-danger"></div>
                    <input class="form-control mb-3" id="password" type="password" name="password"
                    placeholder="Enter Your Password" oninput="removePasswordError()" required>
                    <div id="passwordInvalid" class="text-danger"></div>
                    <button type="button" onclick="superAdminAuth()" class="btn btn-danger mb-3">LOGIN</button>
               
            </div>
        </div >


        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
    integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
{{-- Script for Super Admin Auth Start --}}
<script>
    function removeEmailError() {
        $('#emailInvalid').html('');
    }
    function removePasswordError() {
        $('#passwordInvalid').html('');
    }
    function superAdminAuth() {
        var emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var email = $('#email').val();
        var password = $('#password').val();

        if (email.match(emailFormat)) {
            var checkEmailFormat = 'OK';
        }else {
            var checkEmailFormat = 'NOT OK';
            $('#emailInvalid').html('Please Enter a Valid Email Id');
        }

        if (!email.length > 0) {
            $('#emailInvalid').html('Please Enter Your Email');
        }

        if (!password.length > 0) {
            $('#passwordInvalid').html('Please Enter Your Password');
        }

        if (checkEmailFormat == 'OK' && email.length > 0 && password.length > 0) {
            $.ajax({
                url:'superAdminAuth',
                type:'POST',
                data: {
                    '_token': '{{csrf_token()}}',
                    email:email,
                    password:password,
                },
                success: function(response) {
                    $('#emailInvalid').html(response.emailStatus);
                    $('#passwordInvalid').html(response.passwordStatus);
                    if (response.redirect == 'superAdminDashboard') {
                        window.location.href = 'superAdminDashboard';
                    }
                },
                error: function(errors) {
                  
                },
            });
        }else {
            
        }
    }
</script>
{{-- Script for Super Admin Auth End --}}
</body>
</html>

