<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Super Admin Admins Accounts | FILEURTAX</title>
    <link rel="stylesheet" href="css/superAdmin/materialdesignicons.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/superAdmin/perfect-scrollbar.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/superAdmin/app.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@6.9.96/css/materialdesignicons.css">
</head>
<body>
    <div class="container-scroller" id="app">
        <x-superAdmin.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-superAdmin.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              {{-- Main Dashboard Content --}}
              <x-superAdmin.superAdminViewAdmins/>
              {{-- Main Dashboard Content End --}}
            </div>
            <x-superAdmin.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
</body>
</html>
