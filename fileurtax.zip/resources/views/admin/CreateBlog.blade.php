<!doctype html>
<html lang="en">
<head>
        <meta charset="utf-8" />
        <title>Dashboard |  Fileurtax- Admin & Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Shivila" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="images/favicon.ico">

        <!-- Bootstrap Css -->
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />

    </head>

    <body data-sidebar="light">

    <!-- <body data-layout="horizontal" data-topbar="dark"> -->

        <!-- Begin page -->
        <div id="layout-wrapper">
            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="d-flex">
                        <!-- LOGO -->
                        <div class="navbar-brand-box">
                            

                            <a href="/" class="logo logo-light">
                                <span class="logo-sm">
                                    <img src="images/logo-cmp.png" alt="" width="30">
                                </span>
                                <span class="logo-lg">
                                    <img src="images/logo-cmp.png" alt="" width="100">
                                </span>
                            </a>
                        </div>

                        <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect" id="vertical-menu-btn">
                            <i class="fa fa-fw fa-bars"></i>
                        </button>

                        <!-- App Search-->
                        <form class="app-search d-none d-lg-block">
                            <div class="position-relative">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="bx bx-search-alt"></span>
                            </div>
                        </form>

                        
                    </div>

                    <div class="d-flex">

                        <div class="dropdown d-inline-block d-lg-none ms-2">
                            <button type="button" class="btn header-item noti-icon waves-effect" id="page-header-search-dropdown"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-magnify"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                                aria-labelledby="page-header-search-dropdown">
        
                                <form class="p-3">
                                    <div class="form-group m-0">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" type="submit"><i class="mdi mdi-magnify"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="dropdown d-none d-lg-inline-block ms-1">
                            <button type="button" class="btn header-item noti-icon waves-effect" data-bs-toggle="fullscreen">
                                <i class="bx bx-fullscreen"></i>
                            </button>
                        </div>

                        

                        <div class="dropdown d-inline-block">
                            <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img class="rounded-circle header-profile-user" src="images/guest-user.png"
                                    alt="Header Avatar">
                                    <span class="d-none d-xl-inline-block ms-1" key="t-henry">
                                        @php
                                            $name = DB::table('admins')->where('admin_email',session('admin_email_session'))->first()->name;
                                        @endphp
                                        {{$name}}
                                    </span>
                                <i class="mdi mdi-chevron-down d-none d-xl-inline-block"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!-- item-->
                                <a class="dropdown-item" href="adminlogin"><i class="bx bx-user font-size-16 align-middle me-1"></i> <span key="t-profile">Profile</span></a>
                                <a class="dropdown-item d-block" href="adminlogin"><i class="bx bx-wrench font-size-16 align-middle me-1"></i> <span key="t-settings">Settings</span></a>
                                <a class="dropdown-item" href="adminlogin"><i class="bx bx-lock-open font-size-16 align-middle me-1"></i> <span key="t-lock-screen">Lock screen</span></a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="/logoutAdmin"><i class="bx bx-power-off font-size-16 align-middle me-1 text-danger"></i> <span key="t-logout">Logout</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title" key="t-menu">Menu</li>

                            <li>
                                <a href="adminlogin" class="waves-effect">
                                    <i class="bx bx-home-circle"></i>
                                    <span key="t-dashboards">Dashboards</span>
                                </a>
                            </li>
                            <li class="menu-title" key="t-menu">Menu</li>
                            <li>
                                <a href="/adminviewcustomer" target="" class="waves-effect">
                                
                                    <i class="bx bx-user"></i>
                                    <span key="t-Customers">Customers</span>
                                </a>
                            </li>
                            <li>
                                <a href="/adminviewconsultant" target="" class="waves-effect">
                                    <i class="bx bx-group"></i>
                                    <span key="t-Service Providers">Service Providers</span>
                                </a>
                            </li>
                            <li>
                                <a href="/adminviewrequest" target="" class="waves-effect">
                                    <i class="bx bx-support"></i>
                                    <span key="t-Service Providers Request">Service Providers Request</span>
                                </a>
                            </li>
                            <li>
                                <a href="/adminfeedback" target="" class="waves-effect">
                                    <i class="bx bx-chat"></i>
                                    <span key="t-chat">Feedbacks</span>
                                </a>
                            </li>
                            <li>
                                <a href="/adminblog" target="" class="waves-effect">
                                    <i class="bx bx-chat"></i>
                                    <span key="t-chat">Blog</span>
                                </a>
                            </li>
                            <li>
                                <a href="/adminhelp"  class="waves-effect">
                                    <i class="bx bx-chat"></i>
                                    <span key="t-chat">Help/Support</span>
                                </a>
                            </li>
                            {{-- <li class="menu-title" key="t-apps">Apps</li>
                            <li>
                                <a href="/adminchat" target="" class="waves-effect">
                                    <i class="bx bx-chat"></i>
                                    <span key="t-chat">Chat</span>
                                </a>
                            </li> --}}
                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->

            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->

            <div class="main-content pb-5">
                <x-admin.CreateBlog/>
                <!-- End Page-content -->                
            </div>
            <footer class="footer bg-dark">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-4 text-light">
                            All Right Reserved. Developed by <a href="https://shivila.com/" style="color:rgb(240, 161, 3)" target="_blank">Shivila Technologies.</a>
                        </div>
                        <div class="col-sm-8 text-light">
                            <div class="text-sm-end d-none d-sm-block">
                                Copyright © 2022 Shivila Technologies Private Limited. Use of our Products/Services is
                        governed by our Privacy Policy.
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
    integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

        <script src="assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>
        <script src="assets/js/app.js"></script>
        <script src="js/admin.js?cache=<?php echo time(); ?>"> </script>
        
    </body>
</html>

