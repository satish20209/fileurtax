<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
   rel="stylesheet">
   <link rel="stylesheet" href="css/admin.css?cache=<?php echo time(); ?>">
   
   <title>Admin | Login </title>
</head>
<body style="background-image: url('../images/adminbg.jpg');background-size:cover">
        <div class="conn-login-main">
            <div class="conn-h4">
                <h3 class="text-center admin-h4">ADMIN LOGIN</h3>
            </div>
            <div class="conn-form">
                <h5 class="admin-h5 text-center">WELCOME TO FILEURTAX</h5>
               <form method="post">
                @csrf
                <input type="email" required name="admin_email" class="form-control mb-3 email" placeholder="Enter Your Email">
                <input type="password" required name="admin_password" class="form-control mb-3 password" placeholder="Enter Your Password">
                <button class="btn btn-danger loginbtnadmin" type="button">Login</button>

                <div class=" mt-3 alert alert-danger erroradminlogin d-none" role="alert">
                    
                  </div>
               </form>
            </div>
        </div>
        
        <script>
            $("input").on("input",function(){
                $(".erroradminlogin").addClass("d-none");
            })
            // login response 
            $(".loginbtnadmin").click(function(){
                $.ajax({
                type: "POST",
                url: "/admindashboard",
                data:{
                    '_token': '{{csrf_token()}}',
                    admin_email:$(".email").val(),
                    admin_password:$(".password").val(),
                },
                dataType: "json",
                beforeSend: function() {
                    $(".loader-icon").removeClass('d-none');
                },
                    success: function(data, response) {
                       
                        if(response == "success"){
                            $(".erroradminlogin").html("Login Success ");
                            window.location.href = "/adminlogin";
                        }
                    },
                    error: function (jqXHR ,response) {
                        $(".erroradminlogin").removeClass("d-none");
                        $(".erroradminlogin").html(jqXHR.responseJSON.response);

                                   
                }
            });
            })
        </script>
</body>
</html>

