<div class="container-fluid text-center">
    <div class="container text-center">
        <div class="row text-center">
            <div class="col-md-8 text-center">
                <h4>Change Password</h4>
                <div class="card p-5" style="width: 40rem">
                    @php
                        $superAdmin = DB::table('super_admins')
                        ->where('email',session('superAdmin'))
                        ->first();
                    @endphp
                    <form action="{{route('superadminPassword')}}" method="POST">
                        @csrf
                        <input name="email" type="text" class="form-control mt-3 mb-3" value="{{$superAdmin->email}}" disabled>
                        <input name="password" type="password" class="form-control mt-3 mb-3" placeholder="Enter New Password" required>
                        <button type="submit" class="btn btn-primary">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>