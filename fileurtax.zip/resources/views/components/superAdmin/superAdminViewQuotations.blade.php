{{-- Quotations' List --}}
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title mb-4">Quotations' List</h5>
        <div class="fluid-container">
          @php
            $quotations = DB::table('askquotations')
            ->get();
          @endphp
          @if ($quotations->count() > 0)
          @foreach ($quotations as $quotation)
          <div class="table-responsive">
            <table class="table table-striped table-bordered">
              <tr>
                <th>Customer Name</th>
                <th>Customer Email</th>
                <th>Customer Mobile</th>
                <th>Message</th>
                <th>Service</th>
                <th>Quotation Price</th>
                <th>Bids</th>
              </tr>
              <tr>
                <td>{{$quotation->name}}</td>
                <td>{{$quotation->email}}</td>
                <td>{{$quotation->mobile}}</td>
                <td>{{$quotation->message}}</td>
                <td>
                  @if ($quotation->services == 'L')
                    Lawyer
                  @elseif ($quotation->services == 'CA')
                    CA
                  @elseif ($quotation->services == 'CS')
                    CS 
                  @elseif ($quotation->services == 'CMA')
                    CMA
                  @endif
                </td>
                <td>₹ {{$quotation->quotation_price}}.00</td>
                <td><a href="superAdminBids?quotationId={{$quotation->id}}" target="_blank" class="mdi mdi-eye"></a></td>
              </tr>
            </table>
          </div>
          @endforeach
          @else
              <div class="text-center">
                <p>There Are No Quotations Submitted Yet.</p>
              </div>
          @endif
        </div>
      </div>
    </div>
  </div>
</div>
{{-- Quotations' List  End --}}






