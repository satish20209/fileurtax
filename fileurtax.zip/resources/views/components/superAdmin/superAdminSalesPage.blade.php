<div class="row">
    <div class="col-md-12 col-xl-12 grid-margin stretch-card">
        {{-- Recent Consultation Bookings --}}
        @php
            $consultations = DB::table('paymentes')
            ->where('package_id',NULL)
            ->orderBy('id','desc')
            ->get();
        @endphp
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Recent</h4>
            <div class="shedule-list d-flex align-items-center justify-content-between mb-3">
              <h3>Consultations Bookings</h3>
            </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th class="bg-primary text-light">Customer Name</th>
                            <th class="bg-primary text-light">Customer Email</th>
                            <th class="bg-primary text-light">Payment Status</th>
                            <th class="bg-primary text-light">Transaction Id</th>
                            <th class="bg-primary text-light">Price</th>
                        </tr>
                        @foreach ($consultations as $consultation)
                            <tr>
                                <td>{{$consultation->name}}</td>
                                <td>{{$consultation->user_email}}</td>
                                <td>
                                    @if ($consultation->payment_status == 'success')
                                        <div class="badge badge-success">Complete</div>
                                    @else
                                        <div class="badge badge-danger">Pending</div>
                                    @endif
                                </td>
                                <td>{{$consultation->txn_id}}</td>
                                <td>{{$consultation->amount}}</td>
                            </tr>
                        @endforeach
                    </table>
                </div>
           {{-- @foreach ($consultations as $consultation)
            <div class="event border-bottom py-3">
                <p class="mb-2 font-weight-medium">{{$consultation->name}}</p>
                <p class="mb-2 font-weight-medium">{{$consultation->user_email}}</p>
                <div class="d-flex align-items-center">
                @if ($consultation->payment_status == 'success')
                    <div class="badge badge-success">Complete</div>
                @else
                    <div class="badge badge-danger">Pending</div>
                @endif
                <small class="text-muted ml-2">₹ {{$consultation->amount}}.00</small>
                <small class="text-muted ml-2">Transaction Id: {{$consultation->txn_id}}</small>
                </div>
            </div>
           @endforeach --}}
          </div>
        </div>
        {{-- Recent Consultation Bookings End --}}
    </div>

    <div class="col-md-12 col-xl-12 grid-margin stretch-card">
        {{-- Recent Packages Bookings --}}
        @php
            $packages = DB::table('paymentes')
            ->where('package_id','!=',NULL)
            ->orderBy('id','desc')
            ->get();
        @endphp
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Recent</h4>
            <div class="shedule-list d-flex align-items-center justify-content-between mb-3">
              <h3>Packages Bookings</h3>
            </div>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th class="bg-primary text-light">Customer Name</th>
                            <th class="bg-primary text-light">Customer Email</th>
                            <th class="bg-primary text-light">Package Name</th>
                            <th class="bg-primary text-light">Payment Status</th>
                            <th class="bg-primary text-light">Transaction Id</th>
                            <th class="bg-primary text-light">Price</th>
                        </tr>
                        @foreach ($packages as $package)
                            <tr>
                                <td>{{$package->name}}</td>
                                <td>{{$package->user_email}}</td>
                                <td>{{$package->package_id}}</td>
                                <td>
                                    @if ($package->status !== 'pending')
                                        <div class="badge badge-success">Complete</div>
                                    @else
                                        <div class="badge badge-danger">Pending</div>
                                    @endif
                                </td>
                                <td>{{$package->txn_id}}</td>
                                <td>{{$package->amount}}</td>
                            </tr>
                        @endforeach
                    </table>
                </div>
           {{-- @foreach ($consultations as $consultation)
            <div class="event border-bottom py-3">
                <p class="mb-2 font-weight-medium">{{$consultation->name}}</p>
                <p class="mb-2 font-weight-medium">{{$consultation->user_email}}</p>
                <div class="d-flex align-items-center">
                @if ($consultation->payment_status == 'success')
                    <div class="badge badge-success">Complete</div>
                @else
                    <div class="badge badge-danger">Pending</div>
                @endif
                <small class="text-muted ml-2">₹ {{$consultation->amount}}.00</small>
                <small class="text-muted ml-2">Transaction Id: {{$consultation->txn_id}}</small>
                </div>
            </div>
           @endforeach --}}
          </div>
        </div>
        {{-- Recent Packages Bookings End --}}
    </div>
</div>