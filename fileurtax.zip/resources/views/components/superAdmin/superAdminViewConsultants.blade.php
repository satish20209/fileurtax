{{-- Consultant List --}}
<div class="row">
    <div class="col-lg-12 grid-margin">
      <div class="card">
        <div class="card-body text-center">
          <h3 class="card-title text-large text-primary"><b>Consultants' List</b></h3>
          <div class="table-responsive">
            <table class="table table-striped table-bordered">
              <thead class="bg-primary text-light">
                <tr>
                  <th> Profile Picture </th>
                  <th> Name </th>
                  <th> Profession </th>
                  <th> Email </th>
                  <th> Phone </th>
                  <th> Action </th>
                </tr>
              </thead>
              <tbody>
                @php
                    $customers = DB::table('members')
                    ->where('role','!=','C')
                    ->paginate(10);
                @endphp
                @foreach ($customers as $customer)
                  <tr>
                    @if ($customer->profileImage == NULL || $customer->profileImage == '') 
                        <td class="font-weight-medium">
                            <img src="images/userPic.png" alt="Customer Profile Picture">
                        </td>
                    @else
                        <td class="font-weight-medium">
                            <img src="https://fileurtax-jobaroundyou.s3.ap-south-1.amazonaws.com/fileurtax/serviceprovider/{{$customer->email}}/{{$customer->profileImage}}" alt="Customer Profile Picture">
                        </td>
                    @endif
                    
                    <td>{{$customer->fname}} </td>
                    @if ($customer->role == 'L')
                        <td>Lawyer </td>
                    @elseif ($customer->role == 'CA')
                        <td>CA </td>
                    @elseif ($customer->role == 'CS')
                        <td>CS </td>
                    @elseif ($customer->role == 'CMA')
                        <td>CMA </td>
                    @endif
                    <td> {{$customer->email}} </td>
                    <td> {{$customer->mobile}} </td>
                    <td>
                        <a class="mdi mdi-email text-danger" href="mailto:{{$customer->email}}"></a>
                        <a class="mdi mdi-phone text-success" href="tel:{{$customer->mobile}}"></a>
                        <a class="mdi mdi-eye text-warning" target="_blank" href="consultantProfile?consultantId={{$customer->id}}"></a>

                    </td>
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="d-flex justify-content-center">
    {!! $customers->links() !!}
  </div>
{{-- Consultant List  End --}}




