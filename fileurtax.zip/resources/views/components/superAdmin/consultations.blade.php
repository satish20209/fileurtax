{{-- Monthly Sales Report --}}
<div class="row">
    <div class="col-lg-12 grid-margin">
      <div class="card">
        <div class="card-body text-center">
          <h3 class="card-title text-large text-primary"><b>Monthly Sales Report</b></h3>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th> Packages Sold </th>
                  <th> Revenue </th>
                  <th> Growth </th>
                  <th> Month </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="font-weight-medium"> 10 </td>
                  <td>₹ 6000 </td>
                  <td class="text-danger"> 60% <i class="mdi mdi-arrow-down"></i></td>
                  <td> July, 2022 </td>
                </tr>
                <tr>
                  <td class="font-weight-medium"> 17 </td>
                  <td> ₹ 13000 </td>
                  <td class="text-success"> 30% <i class="mdi mdi-arrow-up"></i></td>
                  <td> June, 2022 </td>
                </tr>
                <tr>
                  <td class="font-weight-medium"> 5</td>
                  <td> ₹ 3000 </td>
                  <td class="text-danger"> 53.64% <i class="mdi mdi-arrow-down"></i></td>
                  <td> May, 2022 </td>
                </tr>
                <tr>
                  <td class="font-weight-medium"> 100 </td>
                  <td> ₹ 30000</td>
                  <td class="text-success"> 10% <i class="mdi mdi-arrow-up"></i></td>
                  <td> April, 2022 </td>
                </tr>
                <tr>
                  <td class="font-weight-medium"> 90 </td>
                  <td> ₹ 24000 </td>
                  <td class="text-danger"> 34% <i class="mdi mdi-arrow-down"></i></td>
                  <td> March, 2022 </td>
                </tr>
                <tr>
                  <td class="font-weight-medium"> 142 </td>
                  <td>  ₹ 34000 </td>
                  <td class="text-success"> 32% <i class="mdi mdi-arrow-up"></i></td>
                  <td> February, 2022 </td>
                </tr>
                <tr>
                  <td class="font-weight-medium"> 113 </td>
                  <td> ₹ 27000 </td>
                  <td class="text-danger"> 32.03% <i class="mdi mdi-arrow-down"></i></td>
                  <td> January, 2022 </td>
                </tr>
                <tr>
                  <td class="font-weight-medium"> 130 </td>
                  <td> ₹ 35000 </td>
                  <td class="text-success"> 15.64% <i class="mdi mdi-arrow-up"></i></td>
                  <td> December, 2022 </td>
                </tr>
                <tr>
                  <td class="font-weight-medium"> 121 </td>
                  <td> ₹ 31000 </td>
                  <td class="text-success"> 12% <i class="mdi mdi-arrow-up"></i></td>
                  <td> November, 2022 </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
{{-- Monthly Sales Report  End --}}

{{-- Package Wise Sales Report --}}
<div class="row">
  <div class="col-lg-12 grid-margin">
    <div class="card">
      <div class="card-body text-center">
        <h3 class="card-title text-large text-primary"><b>Package Wise Sales Report</b></h3>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th> Packages Name </th>
                <th> Packages Sold </th>
                <th> Revenue </th>
                <th> Growth </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="font-weight-bold"> Tax Filling </td>
                <td class="font-weight-medium"> 102 </td>
                <td> ₹ 32000 </td>
                <td class="text-danger"> 53% <i class="mdi mdi-arrow-down"></i></td>
              </tr>
              <tr>
                <td class="font-weight-bold"> GST Registration </td>
                <td class="font-weight-medium"> 52 </td>
                <td> ₹ 14000 </td>
                <td class="text-success"> 34% <i class="mdi mdi-arrow-up"></i></td>
              </tr>
              <tr>
                <td class="font-weight-bold"> TradeMark Registration</td>
                <td class="font-weight-medium"> 13 </td>
                <td> ₹ 4000 </td>
                <td class="text-danger"> 14% <i class="mdi mdi-arrow-down"></i></td>
              </tr>
              <tr>
                <td class="font-weight-bold"> Book Keeping</td>
                <td class="font-weight-medium"> 87 </td>
                <td> ₹ 46000 </td>
                <td class="text-success"> 73% <i class="mdi mdi-arrow-up"></i></td>
              </tr>
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
{{-- Package Wise Sales Report  End --}}