{{-- Leads List --}}
<div class="row">
    <div class="col-lg-12 grid-margin">
      <div class="card">
        <div class="card-body text-center">
          <h3 class="card-title text-large text-primary"><b>All Leads</b></h3>
          <div class="table-responsive">
            <table class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th> Contact No. </th>
                  <th> Name </th>
                  <th> Email </th>
                  <th> Action </th>
                </tr>
              </thead>
              <tbody>
                @php
                    $clientDetails = DB::table('users')->paginate(10);
                @endphp
                @foreach ($clientDetails as $client)
                  <tr>
                    <td class="font-weight-medium"> {{$client->mobile}} </td>
                    <td>{{$client->name}} </td>
                    <td> {{$client->email}} </td>
                    <td>
                      <a href="tel:{{$client->mobile}}" class="mdi mdi-phone text-success"></a>
                      @if ($client->email !== NULL)
                      <a href="mailto:{{$client->email}}" class="mdi mdi-email text-danger"></a>
                      @endif
                    </td>
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="d-flex justify-content-center">
    {!! $clientDetails->links() !!}
  </div>
{{-- Leads List  End --}}




