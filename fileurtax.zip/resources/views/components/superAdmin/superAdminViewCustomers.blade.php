{{-- Customers List --}}
<div class="row">
  <div class="col-lg-12 grid-margin">
    <div class="card">
      <div class="card-body text-center">
        <h3 class="card-title text-large text-primary"><b>Customers' List</b></h3>
        <div class="table-responsive">
          <table class="table table-striped table-bordered">
            <thead class="bg-primary text-light">
              <tr>
                <th> Profile Picture </th>
                <th> Name </th>
                <th> Email </th>
                <th> Phone </th>
                <th> Action </th>
              </tr>
            </thead>
            <tbody>
              @php
                  $customers = DB::table('members')
                  ->where('role','C')
                  ->paginate(10);
              @endphp
              @foreach ($customers as $customer)
                <tr>
                  @if ($customer->profileImage == NULL || $customer->profileImage == '') 
                      <td class="font-weight-medium">
                          <img src="images/userPic.png" alt="Customer Profile Picture">
                      </td>
                  @else
                      <td class="font-weight-medium">
                          <img src="images/{{$customer->profileImage}}" alt="Customer Profile Picture">
                      </td>
                  @endif
                  
                  <td>{{$customer->fname}} </td>
                  <td> {{$customer->email}} </td>
                  <td> {{$customer->mobile}} </td>
                  <td>
                      <a class="mdi mdi-email text-info" href="mailto:{{$customer->email}}"></a>
                      <a class="mdi mdi-phone text-success" href="tel:{{$customer->mobile}}"></a>
                      <a class="mdi mdi-eye text-warning" target="_blank" href="customerProfile?customerId={{$customer->id}}"></a>
                      <i value=""  data-toggle="modal" data-target="#delete_customer{{$customer->id}}" class=" mdi mdi-delete text-danger"></i>
                      <!-- <a  href="{{$customer->id}}" class="mdi mdi-delete text-danger" style="font-size:23px;" ></a> -->
                    </td>
                </tr>
                    <!-- warnin when delete user Modal -->
                    <div class="modal fade" id="delete_customer{{$customer->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel{{$customer->id}}" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel{{$customer->id}}">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            Are You Sure delete {{$customer->fname}}..
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                            <button type="button" value="{{$customer->id}}" class="delete_button btn btn-primary">Yes</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- model end  -->
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="d-flex justify-content-center">
  {!! $customers->links() !!}
</div>
{{-- Customers List  End --}}



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
$(document).ready(function(){

  $('.delete_button').click(function(){
    
    $.ajax({
              type: 'get',
              url: '/delete_customer_details',
              data: {'id':$(this).val()},
              dataType: 'json',
              success: function(data,response){
                  
                  if(data.status==200){
                      window.location.href ='superAdminViewCustomers';
                  }
              }

          })
  })
})
</script>



