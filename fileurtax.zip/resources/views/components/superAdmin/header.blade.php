<nav class="navbar default-layout col-lg-12 col-12 p-0 d-flex flex-row">
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
      <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
        <span class="mdi mdi-menu"></span>
      </button>
      <ul class="navbar-nav navbar-nav-left header-links">
        <li class="nav-item d-none d-xl-flex">
          <img src="images/logo-cmp.png" class="superAdminLogo" alt="FileUrTax Logo">
        </li>
      </ul>
      <ul class="navbar-nav navbar-nav-right">

        


        <li class="nav-item dropdown">
          @php
              $pendingOrders = DB::table('paymentes')
              ->where('status','pending')
              ->orWhere('payment_status','pending')
              ->get();
          @endphp
          <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
            <i class="mdi mdi-bell-outline"></i>
            <span class="count bg-success">{{$pendingOrders->count()}}</span>
          </a>
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0" aria-labelledby="notificationDropdown">
            <a href="{{route('superAdminSalesPage')}}" class="dropdown-item py-3 border-bottom">
              <p class="mb-0 font-weight-medium float-left">{{$pendingOrders->count()}} Pending Orders </p>
              <span class="badge badge-pill badge-primary mx-2 float-right">View all</span>
            </a>
            @php
              $pendingOrders = DB::table('paymentes')
              ->where('status','pending')
              ->orWhere('payment_status','pending')
              ->orderBy('id','desc')
              ->take(3)
              ->get();
            @endphp
            @foreach ($pendingOrders as $pendingOrder)
              <a class="dropdown-item preview-item py-3">
                <div class="preview-thumbnail">
                  <i class="mdi mdi-alert m-auto text-danger"></i>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-normal text-dark mb-1">{{$pendingOrder->name}}</h6>
                  <p class="font-weight-light small-text mb-0 mx-3">₹ {{$pendingOrder->amount}}.00 </p>
                </div>
              </a>
            @endforeach
          </div>
        </li>

        
        <li class="nav-item dropdown d-none d-xl-inline-block">
          <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
            <span class="profile-text d-none d-md-inline-flex">Super Admin</span>
            <img class="img-xs rounded-circle" src="images/superAdmin/superAdmin.png" alt="Profile image"> </a>
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
           <a href="{{route('superAdminProfile')}}" class="dropdown-item"> Change Password </a>
            <a href="{{route('superAdminLogOut')}}" class="dropdown-item"> Sign Out </a>
          </div>
        </li>
      </ul>
      <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
        <span class="mdi mdi-menu icon-menu"></span>
      </button>
    </div>
  </nav>