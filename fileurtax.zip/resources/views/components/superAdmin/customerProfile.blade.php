@php
    $customerId = request()->get('customerId');
    $customer = DB::table('members')
    ->where('id',$customerId)
    ->first();
    $customerReq = DB::table('customer_requirements')
    ->where('user_id',$customerId)
    ->first();
@endphp

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card shadow text-center p-3">
                @if ($customer->profileImage != NULL)
                    <img src="images/customer_files/{{$customer->profileImage}}" alt="Consultant Profile Picture" class="consultantProfilePic">
                @else
                    <img src="images/guest-user.png" alt="Consultant Profile Picture" class="consultantProfilePic">
                @endif
                <p class="consultantName">{{$customer->fname}}</p>
                <p class="text-mute" style="margin-top: -15px; font-size:16px;">
                    CUSTOMER
                </p>
                <p>
                    <a href="tel:{{$customer->mobile}}" class="mdi mdi-phone-in-talk text-success text-decoration-none"></a>
                    <a href="mailto:{{$customer->email}}" class="mdi mdi-email text-danger text-decoration-none"></a>
                </p>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow consultantProfileDetails">
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Personal Details</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Customer Requirements</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit" type="button" role="tab" aria-controls="edit" aria-selected="false">Edit Details</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="" data-bs-toggle="tab" data-bs-target="#takeService" type="button" role="tab" aria-controls="takeService" aria-selected="false">Take Service</button>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">
                {{-- Personal Details --}}
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <div class="row">
                        <div class="col-md-6">
                            <span class="consultantDetailsHeading badge text-light">NAME</span>
                            <p class="mx-3 consultantDetails">{{$customer->fname}}</p>
                        </div>
                        <div class="col-md-6">
                            <span class="consultantDetailsHeading badge text-light">EMAIL</span>
                            <p class="mx-3 consultantDetails">{{$customer->email}}</p>
                        </div>
                    </div>
                  
                    <div class="row">
                        <div class="col-md-6">
                        <span class="consultantDetailsHeading badge text-light">MOBILE NO.</span>
                        <p class="mx-3 consultantDetails">{{$customer->mobile}}</p>
                        </div>
                    </div>
                </div>
                {{-- Personal Details End --}}

                {{-- edit personal details --}}
                <div class="tab-pane fade show " id="edit" role="tabpanel" aria-labelledby="edit-tab">
                  <div class=" row">
                    <div class=" col-md-6">
                        <label class="" for="">NAME</label><br>
                        <input class="form-control fname" name="fname" type="text" value="{{$customer->fname}}">
                      
                     </div> 
                    <div class="col-md-6">
                        <label class="" for="">EMAIL</label><br>
                        <input class="form-control email" type="text" name="email" value="{{$customer->email}}">
                     
                    </div>
                  </div>
                  
                  <div class=" row">
                    <div class=" col-md-6">
                        <label class="" for="">MOBILE NO.</label><br>
                        <input class="form-control mobile" type="text" name="mobile" value="{{$customer->mobile}}">
                      
                    </div>
                    @if ($customerReq)
                    <div class="col-md-6">
                                <!-- <span class="consultantDetailsHeading badge text-light">CONSULTANT NEED</span> -->
                                <label for="">CONSULTANT NEED</label>
                                <select name="parent_service" required style="height:30px;border-radius:3px;" class="parent_service w-100" name="" id="">
                                    <option value="">Select Option </option>
                                @php
                                $temp_ar=['L'=>'Lawyer','CA'=>'Chartered Accountant','CS'=>'Company Secretary','CMA'=>'Cost Management Accountant'];
                                foreach($temp_ar as $key=>$val){
                                    if($customerReq->parent_service == $key){
                                        echo '<option selected value="'.$key.'">'.$val.'</option>';

                                    }else{
                                        echo '<option  value="'.$key.'">'.$val.'</option>';
                                    }
                                    
                                }
                                @endphp
                                </select>

                    </div>

                    </div>
                        <div class="row mb-3">
                            
                            <div class="col-md-6">
                                <label for="">REQUIREMENTS</label>
                                <input class="requirements form-control" type="text" name="requirements" value="{{$customerReq->requirements}}">
                                <!-- <span class="consultantDetailsHeading badge text-light">REQUIREMENTS</span>
                                <p class="mx-3 consultantDetails">{{$customerReq->requirements}}</p> -->
                            </div>
                        </div>
                        
                        <button type="button" value="{{$customerId}}" style="float:right;margin-right:10px;" class="update_btn btn btn-success">Upadae</button>
                        
                    </div>
                    @else
                <button type="button" value="{{$customerId}}" style="float:right;margin-right:10px;" class="update_btn btn btn-success">Upadae</button>
                @endif
                {{-- edit personal details End --}}

                {{-- Customer Requirments Details --}}
                @if ($customerReq)
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <span class="consultantDetailsHeading badge text-light">CONSULTANT NEED</span>
                                <p class="mx-3 consultantDetails">
                                    @if ($customerReq->parent_service == 'L')
                                        Lawyer
                                    @elseif ($customerReq->parent_service == 'CA')
                                        Chartered Accountant
                                    @elseif ($customerReq->parent_service == 'CS')
                                        Company Secretary
                                    @elseif ($customerReq->parent_service == 'CMA')
                                        Cost Management Accountant
                                    @endif
                                </p>
                            </div>
                            <div class="col-md-6">
                                <span class="consultantDetailsHeading badge text-light">REQUIREMENTS</span>
                                <p class="mx-3 consultantDetails">{{$customerReq->requirements}}</p>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <span class="consultantDetailsHeading badge text-light">FILES</span>
                                <p class="mx-3 consultantDetails">
                                    @php
                                        $files = explode(',',$customerReq->files)
                                    @endphp
                                    @foreach ($files as $file)
                                        {{$file}}
                                        <a href="customer_files/{{$file}}" class="text-primary text-decoration-none" download>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-earmark-arrow-down-fill" viewBox="0 0 16 16">
                                                <path d="M9.293 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4.707A1 1 0 0 0 13.707 4L10 .293A1 1 0 0 0 9.293 0zM9.5 3.5v-2l3 3h-2a1 1 0 0 1-1-1zm-1 4v3.793l1.146-1.147a.5.5 0 0 1 .708.708l-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 0 1 .708-.708L7.5 11.293V7.5a.5.5 0 0 1 1 0z"/>
                                            </svg>
                                        </a>
                                    @endforeach
                                </p>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="text-center">
                            <h4>Customer Requirements Not Updated Yet</h4>
                        </div>
                    </div>
                @endif
                {{-- Customer Requirments Details End --}}

                {{-- take service customer --}}
                <div class="tab-pane fade show " id="takeService" role="tabpanel" aria-labelledby="takeService">
                                @php
                                $sr_req=DB::table('services_requests')
                                ->where('customer_id',$customer->id)
                                ->first();
                                $consl_details="";
                                $status="No any Request sent.";
                                if($sr_req){
                                    if($sr_req->status==0){
                                        $status='Request Sent.';
                                    }else{
                                        $status='Request Accepted.';
                                        $consl_details=DB::table('members')
                                        ->where('id',$sr_req->service_provider_id)
                                        ->first();
                                    }
                                }
                               
                                @endphp
                        @if($customerReq)
                        <div class="card text-center">
                            <div class="card-header">
                                Consultancy  Service
                            </div>
                            <div class="row">
                                <div class="col-md-6 card-body text-center">
                                <h5 class="">Customer Details </h5>
                                    <p class=""><b>Name:</b>{{$customer->fname}}</p>
                                    <p class=""><b>Service Name:</b>
                                    @if ($customerReq->parent_service == 'L')
                                        Lawyer
                                    @elseif ($customerReq->parent_service == 'CA')
                                        Chartered Accountant
                                    @elseif ($customerReq->parent_service == 'CS')
                                        Company Secretary
                                    @elseif ($customerReq->parent_service == 'CMA')
                                        Cost Management Accountant
                                    @endif
                                    </p>
                                    <p class=""><b>Status:</b>{{$status}}</p>

                                </div>
                                <div class="col-md-6 card-body text-center">
                                <h5 class="">Consultant Details </h5>
                                @if($consl_details!="")
                                    <p class=""><b>Consultant Name:</b>{{$consl_details->fname}}</p>
                                    <p class=""><b>Email:</b>{{$consl_details->email}}</p>
                                    <p class=""><b>mobile:</b>{{$consl_details->mobile}}</p>
                                    @else
                                    <p class="">No any Consultant accept Request</p>
                                @endif    
                                </div>
                                
                                
                            </div>
                            
                            
                            <!-- <div class="card-footer text-muted">
                                2 days ago
                            </div> -->
                        </div>
                        @endif
                        
                        
                        
                        
                    
                    
                </div>
                {{-- take service customer End --}}

              </div>
              
            </div>
            
        </div>

        
    </div>
</div>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        $('.update_btn').click(function(){
            
          
            var data={
                id:$(this).val(),
                fname:$('.fname').val(),
                email:$('.email').val(),
                mobile:$('.mobile').val(),
                parent_service:$('.parent_service').val(),
                requirements:$('.requirements').val(),
                
            };
            
            $.ajax({
                type: 'get',
                url: '/update_customer_details',
                data: data,
                dataType: 'json',
                success: function(data,response){
                  
                    if(data.status==200){
                        window.location=window.location;
                    }
                }

            })
            
        })
    })
</script>