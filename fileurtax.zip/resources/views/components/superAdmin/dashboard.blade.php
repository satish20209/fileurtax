<div class="row">
    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
      {{-- Packages Card --}}
      @php
          $packagesSold = DB::table('paymentes')
          ->where('package_id','!=',NULL)
          ->whereMonth('payment_date',Carbon\Carbon::now('Asia/Kolkata')->month)
          ->get();
          $packagesSoldPrev = DB::table('paymentes')
          ->where('package_id','!=',NULL)
          ->whereMonth('payment_date',Carbon\Carbon::now('Asia/Kolkata')->subMonth()->month)
          ->get();
          if ($packagesSoldPrev->sum('amount') == 0) {
            $packagesSoldPer = ($packagesSold->sum('amount'));
          } else {
            $packagesSoldPer = (($packagesSold->sum('amount') - $packagesSoldPrev->sum('amount'))/$packagesSoldPrev->sum('amount'))* 100;
          }
          
          
          
      @endphp
      <a href="{{route('superAdminPackages')}}" class="card card-statistics text-decoration-none">
        <div class="card-body">
          <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
            <div class="float-left">
              <i class="mdi mdi-package-variant text-danger icon-lg"></i>
            </div>
            <div class="float-right">
              <p class="mb-0 text-right analyticsCardHeading">Packages</p>
              <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">{{$packagesSold->count()}}</h3>
              </div>
            </div>
          </div>
          <p class="text-muted text-small mt-3 mb-0 text-left text-md-center text-xl-left">
            Monthly Growth: <span class=" text-danger"> {{$packagesSoldPer}} %</span> <i class="mdi mdi-arrow-down text-danger"></i>
          </p>
        </div>
      </a>
      {{-- Packages Card End --}}
    </div>
    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
      {{-- Consultations Card --}}
      @php
          $ConsultationsCount = DB::table('paymentes')
          ->where('package_id',NULL)
          ->get();
      @endphp
      <a href="{{route('superAdminConsulations')}}" class="card card-statistics text-decoration-none">
        <div class="card-body">
          <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
            <div class="float-left">
              <i class="mdi mdi-help-box text-warning icon-lg"></i>
            </div>
            <div class="float-right">
              <p class="mb-0 text-right analyticsCardHeading">Consultations</p>
              <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">{{$ConsultationsCount->count()}}</h3>
              </div>
            </div>
          </div>
          <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
            Monthly Growth: <span class=" text-success"> 40 %</span> <i class="mdi mdi-arrow-up text-success"></i>
          </p>
        </div>
      </a>
      {{-- Consultations Card End --}}
    </div>
    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
      {{-- Sales Card --}}
      @php
          $totalSales = DB::table('paymentes')
          ->where('payment_status','success')
          ->orWhere('status','success')
          ->get();
      @endphp
      <a href="{{route('superAdminSales')}}" class="card card-statistics text-decoration-none">
        <div class="card-body">
          <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
            <div class="float-left">
              <i class="mdi mdi-chart-pie text-success icon-lg"></i>
            </div>
            <div class="float-right">
              <p class="mb-0 text-right analyticsCardHeading">Sales</p>
              <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">₹ {{$totalSales->sum('amount')}}.00</h3>
              </div>
            </div>
          </div>
          <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
            Monthly Growth: <span class=" text-success"> 50 %</span> <i class="mdi mdi-arrow-up text-success"></i>
          </p>
          </div>
        </a>
      {{-- Sales Card End --}}
    </div>
    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
      {{-- Leads Card --}}
      <a href="{{route('superAdminLeads')}}" class="card card-statistics text-decoration-none">
        <div class="card-body">
          <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
            <div class="float-left">
              <i class="mdi mdi-account-box-multiple text-info icon-lg"></i>
            </div>
            <div class="float-right">
              <p class="mb-0 text-right analyticsCardHeading">Leads</p>
              <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">
                  @php
                    $clientCount = DB::table('users')->count();
                  @endphp
                  {{$clientCount}}
                </h3>
              </div>
            </div>
          </div>
          <p class="text-muted mt-3 mb-0 text-left text-md-center text-xl-left">
            <i class="mdi mdi-eye mr-1" aria-hidden="true"></i> View All </p>
        </div>
      </a>
      {{-- Leads Card End --}}
    </div>
  </div>


  <div class="row">
    <div class="col-md-6 col-xl-4 grid-margin stretch-card">
      {{-- Recent Consultation Bookings --}}
      @php
            $consultations = DB::table('paymentes')
            ->where('package_id',NULL)
            ->orderBy('id','desc')
            ->take(3)
            ->get();
      @endphp
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Recent</h4>
          <div class="shedule-list d-flex align-items-center justify-content-between mb-3">
            <h3>Bookings</h3>
          </div>
          @foreach ($consultations as $consultation)
            <div class="event border-bottom py-3">
                <p class="mb-2 font-weight-medium">{{$consultation->name}}</p>
                <div class="d-flex align-items-center">
                @if ($consultation->payment_status == 'success')
                    <div class="badge badge-success">Complete</div>
                @else
                    <div class="badge badge-danger">Pending</div>
                @endif
                <small class="text-muted ml-2">₹ {{$consultation->amount}}.00</small>
                </div>
            </div>
          @endforeach
        </div>
      </div>
      {{-- Recent Consultation Bookings End --}}
    </div>
    <div class="col-md-6 col-xl-4 grid-margin stretch-card">
      {{-- Recent Package Orders --}}
      @php
            $packages = DB::table('paymentes')
            ->where('package_id','!=',NULL)
            ->orderBy('id','desc')
            ->take(3)
            ->get();
      @endphp
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Recent</h4>
          <div class="shedule-list d-flex align-items-center justify-content-between mb-3">
            <h3>Package Orders</h3>
          </div>
          @foreach ($packages as $package)
            <div class="event border-bottom py-3">
              <p class="mb-2 font-weight-medium">{{$package->name}}</p>
              <div class="d-flex align-items-center">
                @if ($package->status !== 'pending')
                    <div class="badge badge-success">Complete</div>
                @else
                    <div class="badge badge-danger">Pending</div>
                @endif
                <small class="text-muted ml-2">₹ {{$package->amount}}.00</small>
              </div>
            </div>
          @endforeach
        </div>
      </div>
      {{-- Recent Package Orders End --}}
    </div>
    <div class="col-md-12 col-xl-4 grid-margin stretch-card">
      
      <div class="row flex-grow">
        <div class="col-md-6 col-xl-12 grid-margin grid-margin-md-0 grid-margin-xl stretch-card">
          {{-- Today sales --}}
          <div class="card card-revenue">
            <div class="card-body d-flex align-items-center">
              <div class="d-flex flex-grow">
                <div class="mr-auto">
                  <p class="highlight-text mb-0 text-white"> 
                    @php
                        $todayOrder = DB::table('paymentes')
                        ->whereDate('payment_date', \Carbon\Carbon::now('Asia/Kolkata'))
                        ->sum('amount');
                        $yesterdayOrder = DB::table('paymentes')
                        ->whereDate('payment_date', \Carbon\Carbon::now('Asia/Kolkata')->subday())
                        ->sum('amount');
                        if ($todayOrder > $yesterdayOrder) {
                          $OrderDiff = ($todayOrder - $yesterdayOrder);
                          $background = 'bg-success';
                          $growth = 'up';
                        }else {
                          $OrderDiff = ($yesterdayOrder - $todayOrder);
                          $background = 'bg-danger';
                          $growth = 'down';
                        }
                        if ($yesterdayOrder === 0) {
                          $percentage = $OrderDiff;
                        }else {
                          $percentage = ($OrderDiff/$yesterdayOrder)*100;
                        }
                        
                    @endphp
                    ₹ {{$todayOrder}} .00
                  </p>
                  <p class="text-white"> Order Placed Today </p>
                  <div class="badge badge-pill {{$background}}"> {{$percentage}}% <i class="mdi mdi-arrow-{{$growth}}"></i></div>
                  <div class="text-small">From Yesteday</div>
                </div>
              </div>
            </div>
          </div>
          {{-- Today sales End --}}
        </div>
        <div class="col-md-6 col-xl-12 stretch-card">
          {{-- Monthly and Yearly sales --}}
          <div class="card card-revenue-table">
            <div class="card-body">
              <div class="revenue-item d-flex">
                <div class="revenue-desc">
                  <h6>This Month</h6>
                  <p class="font-weight-light"> Compared to Prev Month </p>
                </div>
                <div class="revenue-amount">
                  <p class="text-success">
                    @php
                        $monthlyOrder = DB::table('paymentes')
                        ->whereMonth('payment_date', \Carbon\Carbon::now('Asia/Kolkata')->month)
                        ->sum('amount');
                    @endphp
                    ₹ {{$monthlyOrder}}
                  </p>
                </div>
              </div>
              <div class="revenue-item d-flex">
                <div class="revenue-desc">
                  <h6>This Year</h6>
                  <p class="font-weight-light"> Compared to Prev Year </p>
                </div>
                <div class="revenue-amount">
                  <p class="text-success">
                    @php
                        $yearlyOrder = DB::table('paymentes')
                        ->whereYear('payment_date', \Carbon\Carbon::now('Asia/Kolkata')->year)
                        ->sum('amount');
                    @endphp
                    ₹ {{$yearlyOrder}}
                  </p>
                </div>
              </div>
            </div>
          </div>
           {{-- Monthly and Yearly sales End --}}
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-lg-12 grid-margin">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Recent Registrations</h4>
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th> Profile Picture </th>
                  <th> Name </th>
                  <th> Email </th>
                  <th> Phone </th>
                  <th> Role </th>
                </tr>
              </thead>
              <tbody>
                @php
                    $members = DB::table('members')
                    ->orderBy('id','desc')
                    ->take(10)
                    ->get();
                @endphp
                @foreach ($members as $member)
                  <tr>
                    @if ($member->profileImage == NULL || $member->profileImage == '') 
                      <td class="font-weight-medium">
                        <img src="images/userPic.png" alt="Customer Profile Picture">
                      </td>
                    @else
                      <td class="font-weight-medium">
                        <img src="https://fileurtax-jobaroundyou.s3.ap-south-1.amazonaws.com/fileurtax/serviceprovider/{{$member->email}}/{{$member->profileImage}}" alt="Customer Profile Picture">
                      </td>
                    @endif
                    {{-- <td> <img src="images/{{$member->profileImage}}" alt=""> </td> --}}
                    <td> {{$member->fname}} </td>
                    <td> {{$member->email}} </td>
                    <td> {{$member->mobile}} </td>
                    <td>
                      @if ($member->role == 'L')
                          <td>Lawyer </td>
                      @elseif ($member->role == 'CA')
                        <td>CA </td>
                      @elseif ($member->role == 'C')
                        <td>Customer </td>
                      @elseif ($member->role == 'CS')
                          <td>CS </td>
                      @elseif ($member->role == 'CMA')
                          <td>CMA </td>
                      @endif
                    </td>
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title mb-4">Recents Quotations</h5>
          <div class="fluid-container">
            @php
                    $quotations = DB::table('askquotations')
                    ->orderBy('id','desc')
                    ->take(3)
                    ->get();
                @endphp
            @foreach ($quotations as $quotation)
                <div class="row ticket-card mt-3 pb-2 border-bottom pb-3 mb-3">
                    <div class="ticket-details col-md-9">
                    <div class="d-flex">
                        <p class="text-dark font-weight-bold mr-2 mb-0 no-wrap">{{$quotation->name}} :</p>
                        <a href="mailto:{{$quotation->email}}" class="badge bg-danger text-light mb-0 ellipsis">{{$quotation->email}}</a>
                        <a href="tel:{{$quotation->mobile}}" class="mx-3 badge bg-info text-light mb-0 ellipsis">{{$quotation->mobile}}</a>
                    </div>
                    <p class="text-gray ellipsis mb-2">{{$quotation->message}} </p>
                    <span class="badge bg-success text-light">₹ {{$quotation->quotation_price}}.00</span>
                    <div class="row text-gray d-md-flex d-none">
                    </div>
                    </div>
                    <div class="ticket-actions col-md-2">
                    <div class="btn-group dropdown">
                        <span type="button" class="badge bg-primary text-light"> {{$quotation->services}} </span>
                    </div>
                    </div>
                </div>
            @endforeach
          </div>
        </div>
      </div>
    </div>
</div>