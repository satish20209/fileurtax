{{-- Admins List --}}
<div class="row">
    <div class="col-lg-12 grid-margin">
      <div class="card">
        <div class="card-body text-center">
          <h3 class="card-title text-large text-primary"><b>All Admins</b></h3>
          <div class="table-responsive">
            <table class="table table-striped table-bordered">
              <thead class="bg-primary text-light">
                <tr>
                  <th> Profile Picture </th>
                  <th> Name </th>
                  <th> Email </th>
                  <th> Delete </th>
                </tr>
              </thead>
              <tbody>
                @php
                    $admins = DB::table('admins')->paginate(10);
                @endphp
                @foreach ($admins as $admin)
                  <tr>
                    <td class="font-weight-medium">
                        <img src="{{$admin->image}}" alt="admin">
                    </td>
                    <td>{{$admin->name}} </td>
                    <td> {{$admin->admin_email}} </td>
                    <td>
                        <form action="{{route('superAdminDeleteAdmins')}}" method="POST">
                            @csrf
                            <input name="adminId" type="hidden" value="{{$admin->id}}">
                            <button type="submit" class="btn mdi mdi-delete-circle text-danger"></button>
                        </form>
                    </td>
                  </tr>
                @endforeach
              </tbody>
            </table>
            <h4><button class="btn btn-primary mt-5" onclick="addAdmin()" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="mdi mdi-card-bulleted"></i>Add Admin</button></h4>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="d-flex justify-content-center">
    {!! $admins->links() !!}
  </div>

  <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body text-center">
          <form action="{{route('superAdminAddAdmins')}}" method="POST">
            @csrf
            <input class="form-control mt-3 mb-3" type="text" name="name" placeholder="Enter Admin's Name" required autocomplete="off">
            <input class="form-control mt-3 mb-3" type="email" name="email" placeholder="Enter Admin's Email" required autocomplete="off">
            <input class="form-control mt-3 mb-3" type="password" name="password" placeholder="Enter Admin's Password" required autocomplete="off">
            <button type="submit" class="btn btn-primary">Add</button>
          </form>
        </div>
      </div>
    </div>
  </div>
{{-- Admins List  End --}}

<script>
    function addAdmin() {
        $('#exampleModal').modal('show');
    }
</script>




