<nav class="sidebar sidebar-offcanvas dynamic-active-class-disabled" id="sidebar">
    <ul class="nav">
      <li class="nav-item nav-profile not-navigation-link">
        <div class="nav-link">
          <div class="user-wrapper">
            <div class="profile-image">
              <img src="images/superAdmin/superAdmin.png" alt="profile image">
            </div>
            <div class="text-wrapper">
              <p class="profile-name">Super Admin</p>
              <div class="dropdown" data-display="static">
                <a href="#" class="nav-link d-flex user-switch-dropdown-toggler" id="UsersettingsDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                  <small class="designation text-muted">Online</small>
                  <span class="status-indicator online"></span>
                </a>
              </div>
            </div>
          </div>
          {{-- <a class="btn btn-primary btn-md" href="{{route('superAdminLogOut')}}">LOG OUT 
            <i class="mdi mdi-logout-variant"></i>
          </a> --}}
        </div>
      </li>
     
      <li class="nav-item">
        <a href="{{route('superAdminDashboard')}}" class="nav-link text-success" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-view-dashboard"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="{{route('superAdminViewAdmins')}}" class="nav-link text-danger" aria-expanded="" aria-controls="basic-ui">
           <i class="mdi mdi-shield-key"></i>
          <span class="menu-title">Admins</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="{{route('superAdminViewCustomers')}}" class="nav-link text-primary" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-cart-arrow-right"></i>
          <span class="menu-title">Customers</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="{{route('superAdminViewConsultants')}}" class="nav-link text-info" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-account-supervisor"></i>
          <span class="menu-title">Consultants</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="{{route('superAdminSalesPage')}}" class="nav-link text-warning" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-podium-silver"></i>
          <span class="menu-title">Sales</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="{{route('superAdminViewQuotations')}}" class="nav-link" style="color: #855b00;" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-newspaper"></i>
          <span class="menu-title">Quotations</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="{{route('superAdminLogOut')}}" class="nav-link text-orange" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-logout-variant"></i>
          <span class="menu-title">LogOut</span>
        </a>
      </li>
      
 </ul>
</nav>