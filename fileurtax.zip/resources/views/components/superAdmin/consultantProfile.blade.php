@php
    $consultantId = request()->get('consultantId');
    $consultant = DB::table('members')
    ->where('id',$consultantId)
    ->first();
    if ($consultant->role == 'L') {
      $consultantDetails = DB::table('serviceprovider_lawyers')
      ->where('userId',$consultantId)
      ->first();
    }elseif ($consultant->role == 'CMA') {
      $consultantDetails = DB::table('serviceprovidercmas')
      ->where('userId',$consultantId)
      ->first();
    }elseif ($consultant->role == 'CA') {
      $consultantDetails = DB::table('serviceprovidercas')
      ->where('userId',$consultantId)
      ->first();
    }elseif ($consultant->role == 'CS') {
      $consultantDetails = DB::table('serviceprovidercs')
      ->where('userId',$consultantId)
      ->first();
    }
@endphp
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card shadow text-center p-3">
              @if ($consultant->profileImage == NULL)
              <img class="img-xs rounded-circle" src="images/userPic.png" alt="Profile image"> </a>
              @else
              <img class="consultantProfilePic" src="https://fileurtax-jobaroundyou.s3.ap-south-1.amazonaws.com/fileurtax/serviceprovider/{{$consultant->email}}/{{$consultant->profileImage}}" alt="Profile image"> </a>
              @endif
                
                <p class="consultantName">{{$consultant->fname}}</p>
                <p class="text-mute" style="margin-top: -15px; font-size:16px;">
                    @if ($consultant->role == 'L')
                        Lawyer
                      @elseif ($consultant->role == 'CA')
                        CA 
                      @elseif ($consultant->role == 'C')
                        Customer
                      @elseif ($consultant->role == 'CS')
                        CS 
                      @elseif ($consultant->role == 'CMA')
                        CMA 
                      @endif
                </p>
                <p>
                    <a href="" class="mdi mdi-facebook text-primary text-decoration-none"></a>
                    <a href="" class="mdi mdi-twitter text-info text-decoration-none"></a>
                    <a href="" class="mdi mdi-linkedin text-warning text-decoration-none"></a>
                    <a href="" class="mdi mdi-phone-in-talk text-success text-decoration-none"></a>
                    <a href="" class="mdi mdi-email text-danger text-decoration-none"></a>
                </p>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card shadow consultantProfileDetails">
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Personal Details</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Professional Details</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Schedule</button>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">
                {{-- Personal Details --}}
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                  <div class="row">
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">NAME</span>
                      <p class="mx-3 consultantDetails">{{$consultant->fname}}</p>
                    </div>
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">EMAIL</span>
                      <p class="mx-3 consultantDetails">{{$consultant->email}}</p>
                    </div>
                  </div>
                  <div class="row">
                    @if($consultantDetails)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">PAN CARD</span>
                      <p class="mx-3 consultantDetails">{{$consultantDetails->pancard}}</p>
                    </div>
                   
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">AADHAR CARD</span>
                      <p class="mx-3 consultantDetails">{{$consultantDetails->aadhaarcard}}</p>
                    </div>
                    @endif
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">MOBILE NO.</span>
                      <p class="mx-3 consultantDetails">{{$consultant->mobile}}</p>
                    </div>
                    @if($consultant->gender)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">GENDER</span>
                      <p class="mx-3 consultantDetails">{{$consultant->gender}}</p>
                    </div>
                    @endif
                  </div>
                </div>
                {{-- Personal Details End --}}
                {{-- Professional Details --}}
                
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                @if($consultantDetails)  
                  @if ($consultant->role == 'L')
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">PRACTICING SINCE</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->practincingSince}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">FEES AMOUNT</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->amount}}</p>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">BAR ENROLMENT NUMBER</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->barEnrollmentNumber}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">BAR ENROLMENT STATE</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->enrollment_state}}</p>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">LANGUAGE</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->language}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">PRACTICE COURT</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->practice_courts}}</p>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">PRIMARY PRACTICE AREA</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->practice_Areas_primary}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">SECONDARY PRACTICE AREA</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->secondary_practice_area}}</p>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">PRACTICE STATE</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->practice_state}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">COUNTRY</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->country}}</p>
                        </div >
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">STATE</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->practice_state}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">CITY</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->country}}</p>
                        </div>
                      </div>
                    @elseif ($consultant->role == 'CMA' || $consultant->role == 'CA' || $consultant->role == 'CS')
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">AWARDS</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->recognitions}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">FIRM REG. NUM.</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->registrationNumber}}</p>
                        </div>
                      </div> 
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">INDUSTRY</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->experience}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">COUNTRY</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->country}}</p>
                        </div>
                      </div> 
                      <div class="row mb-3">
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">STATE</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->state}}</p>
                        </div>
                        <div class="col-md-6">
                          <span class="consultantDetailsHeading badge text-light">CITY</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->city}}</p>
                        </div>
                      </div> 
                    @endif
                  
                  
                  
                  
                  
                  <div class="row mb-3">
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">ADDRESS</span>
                      <p class="mx-3 consultantDetails">{{$consultantDetails->address}}</p>
                    </div>
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">PIN CODE</span>
                      <p class="mx-3 consultantDetails">{{$consultantDetails->pincode}}</p>
                    </div>
                  </div>
                
                
                  @endif
                </div>
                {{-- Professional Details End --}}
                {{-- Schedule --}}
                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                @if($consultantDetails) 
                <div class="row mb-3">
                   @if ($consultantDetails->monday !== NULL)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">MONDAY</span>
                      @php
                          $monDays = explode('-',$consultantDetails->monday);
                      @endphp
                      @foreach ($monDays as $monDay)
                       @if ($monDay != '')
                       <p class="mx-3 consultantDetails">{{str_replace('_',' - ',$monDay)}}</p>
                       @endif
                      @endforeach
                    </div>
                   @endif
                   @if ($consultantDetails->tuesday !== NULL)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">TUESDAY</span>
                      @php
                          $tuesDays = explode('-',$consultantDetails->tuesday);
                      @endphp
                      @foreach ($tuesDays as $tuesDay)
                        @if ($tuesDay != '')
                          <p class="mx-3 consultantDetails">{{str_replace('_',' - ',$tuesDay)}}</p>
                        @endif
                      @endforeach
                    </div>
                    @endif
                  </div>
                  <div class="row mb-3">
                    @if ($consultantDetails->wednesday !== NULL)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">WEDNESDAY</span>
                      @php
                          $wednesDays = explode('-',$consultantDetails->wednesday);
                      @endphp
                      @foreach ($wednesDays as $wednesDay)
                      @if ($wednesDay != '')
                        <p class="mx-3 consultantDetails">{{str_replace('_',' - ',$wednesDay)}}</p>
                      @endif
                      @endforeach
                    </div>
                    @endif
                    @if ($consultantDetails->thursday !== NULL)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">THURSDAY</span>
                      @php
                          $thursDays = explode('-',$consultantDetails->thursday);
                      @endphp
                      @foreach ($thursDays as $thursDay)
                      @if ($thursDay != '')
                        <p class="mx-3 consultantDetails">{{str_replace('_',' - ',$thursDay)}}</p>
                      @endif
                      @endforeach
                    </div>
                    @endif
                  </div>
                  <div class="row mb-3">
                    @if ($consultantDetails->friday !== NULL)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">FRIDAY</span>
                      @php
                          $friDays = explode('-',$consultantDetails->friday);
                      @endphp
                      @foreach ($friDays as $friDay)
                      @if ($friDay != '')
                        <p class="mx-3 consultantDetails">{{str_replace('_',' - ',$friDay)}}</p>
                      @endif
                      @endforeach
                    </div>
                    @endif
                    @if ($consultantDetails->saturday !== NULL)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">SATURDAY</span>
                      @php
                          $saturDays = explode('-',$consultantDetails->saturDay);
                      @endphp
                      @foreach ($saturDays as $saturDay)
                      @if ($saturDay != '')
                        <p class="mx-3 consultantDetails">{{str_replace('_',' - ',$saturDay)}}</p>
                      @endif
                      @endforeach
                    </div>
                    @endif
                  </div>
                  <div class="row mb-3">
                    @if ($consultantDetails->sunday !== NULL)
                    <div class="col-md-6">
                      <span class="consultantDetailsHeading badge text-light">SUNDAY</span>
                      @php
                          $sunDays = explode('-',$consultantDetails->sunday);
                      @endphp
                      @foreach ($sunDays as $sunDay)
                      @if ($sunDay != '')
                        <p class="mx-3 consultantDetails">{{str_replace('_',' - ',$sunDay)}}</p>
                      @endif
                      @endforeach
                    </div>
                    @endif
                  </div>
                </div>
                @endif
                {{-- Schedule End --}}
              </div>
            </div>
        </div>
    </div>
</div>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>