{{-- Bids List --}}
@php
    $quotationId = request()->get('quotationId');
    $bids = DB::table('bids')
    ->where('quotationid',$quotationId)
    ->get();
@endphp
@if ($bids->count() > 0)
<div class="row">
    <div class="col-lg-12 grid-margin">
      <div class="card">
        <div class="card-body text-center">
          <div class="table-responsive">
            <table class="table table-striped table-bordered">
              <thead class="bg-primary text-light">
                <tr>
                  <th> Consultant Name </th>
                  <th> Consultant Email </th>
                  <th> Consultant Mobile </th>
                  <th> Consultant Profession </th>
                  <th> Quotation Price </th>
                </tr>
              </thead>
              <tbody>
                @foreach ($bids as $bid)
                @php
                    $consultant = DB::table('members')
                    ->where('id',$bid->consultantId)
                    ->first();
                @endphp
                  <tr>
                    <td>{{$consultant->fname}}</td>
                    <td>{{$consultant->email}}</td>
                    <td>{{$consultant->mobile}}</td>
                    <td>
                        @if ($consultant->role == 'L')
                            Lawyer
                        @elseif ($consultant->role == 'CA')
                            CA
                        @elseif ($consultant->role == 'CS')
                            CS 
                        @elseif ($consultant->role == 'CMA')  
                            CMA
                        @endif 
                    </td>
                    <td>₹ {{$bid->amount}}.00</td>
                  </tr>
                @endforeach
              </tbody>
            </table>
           </div>
        </div>
      </div>
    </div>
  </div>
@else
  <div class="text-center mt-5">
    <p>No Bids Submited For This Quotation</p>
  </div>
@endif
{{-- Bids List  End --}}





