<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../css/jquery-ui.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/materialize.min.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/responsive.css?cache=<?php echo time(); ?>">
    <script src="js/lawyer_cities.js"></script>
@php
if(session()->has('layerAuth')){
    $consultantId = DB::table("members")->where('email',session('layerAuth'))->first('id')->id;
    $consultant = DB::table('members')
    ->where('id',$consultantId)
    ->first();
    $consultantDetails = DB::table('serviceprovider_lawyers')
      ->where('userId',$consultantId)
      ->first();  
}
$profile_pic = Storage::disk('fileurtax')->url('fileurtax/serviceprovider/'.session('layerAuth').'/'.$consultant->profileImage);
@endphp
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card shadow text-center p-3">
            
              @if ($consultant->profileImage == NULL)
              <img class="img-account-profile img-xs rounded-circle" src="images/userPic.png" alt="Profile image"> </a>
              @else
              <img class="img-account-profile consultantProfilePic" src="{{$profile_pic}}" alt="Profile image"> </a>
              @endif
              <button style="margin-left:25%"; class="mt-2  w-50  buttonProfile btn btn-primary" type="button">Upload new image</button>
               
            </div>
        </div>
        <div class="col-md-8">
            <div class="card shadow consultantProfileDetails">
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active bg-light" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Personal Details</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link bg-light" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Professional Details</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link bg-light" id="documents-tab" data-bs-toggle="tab" data-bs-target="#documents" type="button" role="tab" aria-controls="documents" aria-selected="false">Documents</button>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">
                {{-- Personal Details --}}
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                  <form action="update_lyr_PD" method="post" enctype="multipart/form-data">
                    @csrf
                    <input hidden  type="file" name="picture" id="layerProfile">
                    <div class="row">
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input name="fname" class="fname input__field" type="text" value="{{$consultant->fname}}" placeholder=" " />
                          <span class="input__label">Full Name </span>
                      </label>
                        
                        <!-- <span class="consultantDetailsHeading badge text-light">NAME</span>
                        <p class="mx-3 consultantDetails">{{$consultant->fname}}</p> -->
                      </div>
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input disabled  class="email input__field" type="text" value="{{$consultant->email}}" placeholder=" " />
                          <span class="input__label">EMAIL </span>
                      </label>
                        <!-- <span class="consultantDetailsHeading badge text-light">EMAIL</span>
                        <p class="mx-3 consultantDetails">{{$consultant->email}}</p> -->
                      </div>
                    </div>
                    <div class="row">
                      @if($consultantDetails)
                      <div class="col-md-6">
                      <label class="input pancardlabel field w-100 mt-4">
                          <input name="pancard"  class="pan_card input__field" type="text" value="{{$consultantDetails->pancard}}" placeholder=" " />
                          <span class="input__label">PAN CARD</span>
                      </label>
                        <!-- <span class="consultantDetailsHeading badge text-light">PAN CARD</span>
                        <p class="mx-3 consultantDetails">{{$consultantDetails->pancard}}</p> -->
                      </div>
                    
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input name="aadhar_card" class="aadhar_card input__field" type="text" value="{{$consultantDetails->aadhaarcard}}" placeholder=" " />
                          <span class="input__label">AADHAR CARD</span>
                      </label>
                        <!-- <span class="consultantDetailsHeading badge text-light">AADHAR CARD</span>
                        <p class="mx-3 consultantDetails">{{$consultantDetails->aadhaarcard}}</p> -->
                      </div>
                      @endif
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input disabled name="mobile"  class="mobile input__field" type="text" value="{{$consultant->mobile}}" placeholder=" " />
                          <span class="input__label">MOBILE NO.</span>
                      </label>
                       
                      </div>
                      @if($consultant->gender)
                      <div class="col-md-6">
                      <label class="input practincingSincelabel field w-100 mt-5">
                            <select name="gender" class="gender input__field" type="text"  placeholder=" ">
                                <option value="">Select Gender</option>
                            @php
                                $temp=["male","female"];
                                foreach($temp as $val){
                                    if($consultant->gender==$val){
                                        echo '<option selected="selected" value="'.$val.'">'.$val.'</option>';
                                    }else{
                                        echo '<option value="'.$val.'">'.$val.'</option>';
                                    }

                                }
                                
                            @endphp
                        </select>  
                        <span class="input__label">Gender.</span>

                      </label>
                      
                        
                      </div>
                      @endif
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                      <label class="input practincingSincelabel field w-100 mt-5">
                            <select name="salary" class="gender input__field" type="text"  placeholder=" ">
                                <option value="">Select Option</option>
                            @php
                                $temp=["Fixed salary","Hiring","Part Time","Full Time"];
                                foreach($temp as $val){
                                    if($consultant->salary==$val){
                                        echo '<option selected="selected" value="'.$val.'">'.$val.'</option>';
                                    }else{
                                        echo '<option value="'.$val.'">'.$val.'</option>';
                                    }

                                }
                                
                            @endphp
                        </select>  
                        <span class="input__label">Salary Range.</span>
                      </label>                       
                      </div>  

                      <div class="col-md-6">
                        <label class="input practincingSincelabel field w-100 mt-5">
                              <select name="experience" class="gender input__field" type="text"  placeholder=" ">
                                  <option value="">Select Option</option>
                              @php
                                  
                                  for($i = 1;$i<=40; $i++){
                                      if($consultant->experience==$i){
                                          echo '<option selected="selected" value="'.$i.'">'.$i.'</option>';
                                      }else{
                                          echo '<option value="'.$i.'">'.$i.'</option>';
                                      }

                                  }
                                  
                              @endphp
                          </select>  
                          <span class="input__label">Experience.</span>

                        </label>
                      </div>
                      
                    </div>
                    <button style="float:right;" type="submit" class="mt-3 btn btn-success">Update</button>
                  </form>
                </div>
                {{-- Personal Details End --}}
                {{-- Professional Details --}}
                
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                  @if($consultantDetails)  

                    <form action="update_Ltab_2" method='post'>
                      @csrf
                        <div class="row mb-3">
                          <div class="col-md-6">

                          
                          <label class="input practincingSincelabel field w-100 mt-4">
                              <select name="practincingSince" class="practincingSince input__field" type="text"  placeholder=" ">
                                  <option value="">Practicing Since</option>
                                  @php
                                  for($i=1943;$i<=2022;$i++){
                                      if($i==$consultantDetails->practincingSince){
                                          echo '<option selected="selected" value="'.$i.'">'.$i.'</option>';
                                      }else{
                                          echo '<option value="'.$i.'">'.$i.'</option>';
                                      }
                                      
                                  }

                                  @endphp
                                  
                              </select>
                              <span class="input__label">Practincing Since </span>
                          </label>
                            <!-- <span class="consultantDetailsHeading badge text-light">PRACTICING SINCE</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->practincingSince}}</p> -->
                          </div>
                          <div class="col-md-6">
                          <label class="input fnamelabel field w-100 mt-4">
                              <input name="fee_amt"  class="fee_amt input__field" type="text" value="{{$consultantDetails->amount}}" placeholder=" " />
                              <span class="input__label">FEES AMOUNT</span>
                          </label>
                            <!-- <span class="consultantDetailsHeading badge text-light">FEES AMOUNT</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->amount}}</p> -->
                          </div>
                        </div>
                        <div class="row mb-3">
                          <div class="col-md-6">
                          <label class="input fnamelabel field w-100 mt-4">
                              <input name="bar_number" name="bar_number"  class="fee_amt input__field" type="text" value="{{$consultantDetails->barEnrollmentNumber}}" placeholder=" " />
                              <span class="input__label">Bar Number</span>
                              
                          </label>
                            <!-- <span class="consultantDetailsHeading badge text-light">BAR ENROLMENT NUMBER</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->barEnrollmentNumber}}</p> -->
                          </div>
                          <div class="col-md-6">
                            <input hidden  type="text" id="bar_ENROLMENT_state" value="{{$consultantDetails->enrollment_state}}">
                          <label class="input practice_statelabel field w-100 mt-5">
                                      
                              <select name="bar_state" id="bar_sts" class="practice_state input__field" type="text" placeholder=" ">
                                  <option value="">SELECT STATE</option>
                                  
                              </select>
                              <span class="input__label">BAR ENROLMENT STATE</span>
                          </label>


                          <!-- <label class="input fnamelabel field w-100 mt-4">
                              <input name="bar_state"  class="fee_amt input__field" type="text" value="{{$consultantDetails->enrollment_state}}" placeholder=" " />
                              <span class="input__label">BAR ENROLMENT STATE</span>
                          </label> -->

                          
                            <!-- <span class="consultantDetailsHeading badge text-light">BAR ENROLMENT STATE</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->enrollment_state}}</p> -->
                          </div>
                        </div>
                        <div class="row mb-3">
                          <div class="col-md-6">
                              @php 
                              $lang=['english','hindi','urdu','assamese','gujarati','kannada','malayalam','marathi','odia','punjabi','tamil','telgu',]
                              @endphp
                              
                              
                              <label class="input languagelabel field w-100 mt-5">
                                  <select name="language" class="language input__field" type="text" placeholder=" ">
                                      
                                      <option value="">Select languages</option>
                                      @foreach($lang as $lng)
                                          @if($lng==$consultantDetails->language)
                                          <option selected="selected" value="{{$lng}}">{{ucfirst($lng)}}</option>
                                          @else
                                          <option value="{{$lng}}">{{ucfirst($lng)}}</option>
                                          @endif

                                      @endforeach
                                      
                                      
                                  </select>
                                  <span class="input__label">Select languages</span>
                                  </label>
                          <!--                         
                            <span class="consultantDetailsHeading badge text-light">LANGUAGE</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->language}}</p> -->
                          </div>
                          <div class="col-md-6">
                          
                          <label name="practice_courtslabel" class="input practice_courtslabel field w-100 mt-5">
                                      <select name="practice_courts" class="practice_courts input__field" type="text" placeholder=" ">
                                          <option value="">Select Practice Courts</option>
                                          @php
                                          $temp_vr=["District Court","Supreme Court","High Court","Subordinate Courts"];
                                          
                                          foreach($temp_vr as $val){
                                            if(str_starts_with($consultantDetails->practice_courts ,$val)){
                                              
                                            echo '<option selected="selected"  value="'.$val.'">'.$val.'</option>';
                                            }else{
                                              echo '<option value="'.$val.'">'.$val.'</option>';
                                            }
                                          }

                                          @endphp
                                          <!-- <option value="District Court">District Court</option>
                                          <option value="High Court">High Court</option>
                                          <option value="Subordinate Courts">Subordinate Courts</option>
                                          <option value="Supreme Court">Supreme Court</option> -->
                                      </select>
                                      <span class="input__label">Select Practice Courts</span>
                                  </label>
                            <!-- <span class="consultantDetailsHeading badge text-light">PRACTICE COURT</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->practice_courts}}</p> -->
                          </div>
                        </div>
                        <div class="row mb-3">
                          <div class="col-md-6">
                          <label class="input practice_Areas_primarylabel field w-100 mt-5">
                                      <select name="practice_Areas_primary" class="practice_Areas_primary input__field" type="text"
                                          placeholder=" ">
                                          <!-- <option value="">Select Practice Areas (primary)</option> -->
                                          <option value="Arbitration">Arbitration</option>
                                          <option value="Aviation Laws">Aviation Laws</option>
                                          <option value="Banking">Banking</option>
                                          <option value="Civil">Civil</option>
                                          <option value="Company - Registration Compliance">Company - Registration &amp;
                                              Compliance
                                          </option>
                                          <option value="Constitutional">Constitutional</option>
                                          <option value="Consumer">Consumer</option>
                                          <option value="Corporate">Corporate</option>
                                          <option value="Criminal">Criminal</option>
                                          <option value="Cyber Crime">Cyber Crime</option>
                                          <option value="Environment">Environment</option>
                                          <option value="Family">Family</option>
                                          <option value="Immigration">Immigration</option>
                                          <option value="Industrial Relations">Industrial Relations</option>
                                          <option value="International Laws">International Laws</option>
                                          <option value="IPR">IPR</option>
                                          <option value=" Legal Documents - Drafting Vetting"> Legal Documents - Drafting
                                              &amp;
                                              Vetting</option>
                                          <option value="Media Laws">Media Laws</option>
                                          <option value="PIL/RTI/NGO">PIL/RTI/NGO</option>
                                          <option value="Property">Property</option>
                                          <option value="Sports Law">Sports Law</option>
                                          <option value="Taxation">Taxation</option>
                                      </select>
                                      <span class="input__label">Select Practice Areas (primary)</span>
                                  </label>

                            <!-- <span class="consultantDetailsHeading badge text-light">PRIMARY PRACTICE AREA</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->practice_Areas_primary}}</p> -->
                          </div>
                          <div class="col-md-6">
                                  <label class="input secondary_practice_arealabel field w-100 mt-5">
                                      <select name="secondary_practice_area" class="secondary_practice_area input__field" type="text"
                                          placeholder=" ">
                                          <!-- <option value="">Select Practice Areas (Secondary)</option> -->
                                          <option value="Arbitration">Arbitration</option>
                                          <option value="Aviation Laws">Aviation Laws</option>
                                          <option value="Banking">Banking</option>
                                          <option value="Civil">Civil</option>
                                          <option value="Company - Registration Compliance">Company - Registration &amp;
                                              Compliance
                                          </option>
                                          <option value="Constitutional">Constitutional</option>
                                          <option value="Consumer">Consumer</option>
                                          <option value="Corporate">Corporate</option>
                                          <option value="Criminal">Criminal</option>
                                          <option value="Cyber Crime">Cyber Crime</option>
                                          <option value="Environment">Environment</option>
                                          <option value="Family">Family</option>
                                          <option value="Immigration">Immigration</option>
                                          <option value="Industrial Relations">Industrial Relations</option>
                                          <option value="International Laws">International Laws</option>
                                          <option value="IPR">IPR</option>
                                          <option value=" Legal Documents - Drafting Vetting"> Legal Documents - Drafting
                                              &amp;
                                              Vetting</option>
                                          <option value="Media Laws">Media Laws</option>
                                          <option value="PIL/RTI/NGO">PIL/RTI/NGO</option>
                                          <option value="Property">Property</option>
                                          <option value="Sports Law">Sports Law</option>
                                          <option value="Taxation">Taxation</option>
                                      </select>
                                      <span class="input__label">Select Practice Areas (Secondary) </span>
                                  </label>
                            <!-- <span class="consultantDetailsHeading badge text-light">SECONDARY PRACTICE AREA</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->secondary_practice_area}}</p> -->
                          </div>
                        </div>
                        <div class="row mb-3">
                          <div class="col-md-6">
                              <input hidden  type="text" id="temp_practice_sts" value="{{$consultantDetails->practice_state}}">
                              <label class="input practice_statelabel field w-100 mt-5">
                                      
                                      <select name="practice_state" id="practice_sts" class="practice_state input__field" type="text" placeholder=" ">
                                          <option value="">Practice State</option>
                                        
                                      </select>
                                      <span class="input__label">Practice State<span class="red">*</span></span>
                                  </label>
                              
                          
                            <!-- <span class="consultantDetailsHeading badge text-light">PRACTICE STATE</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->practice_state}}</p> -->
                          </div>
                          <div class="col-md-6">
                          <label class="input field w-100 mt-5">
                              <select name="country" disabled class="country input__field" type="text" placeholder=" ">
                                  <option  value="India">India</option>
                              </select>
                              <span class="input__label">Country<span class="red">*</span></span>
                          </label>
                            <!-- <span class="consultantDetailsHeading badge text-light">COUNTRY</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->country}}</p> -->
                          </div >
                        </div>
                        <div class="row mb-3">
                          <div class="col-md-6">
                          <input   type="text" hidden id="temp_sts" value="{{$consultantDetails->state}}">
                          <label class="input practice_statelabel field w-100 mt-5">
                              <select name="state" id="sts" class="practice_state input__field" type="text" placeholder=" ">
                                  <option value="">STATE</option>
                                  
                              </select>
                              <span class="input__label">State</span>
                          </label>
                            <!-- <span class="consultantDetailsHeading badge text-light">STATE</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->practice_state}}</p> -->
                          </div>
                          <div class="col-md-6">
                              <input type="text" id="temp_city"  hidden  value=" {{$consultantDetails->city}} ">
                          <label  class="input citylabel field w-100 mt-5">
                              <select name="city" id="city_names" class="city input__field" type="text" placeholder=" ">
                                  <option value="">Select City</option>
                              </select>
                              <span class="input__label">Select City<span class="red">*</span></span>
                          </label>
                            <!-- <span class="consultantDetailsHeading badge text-light">CITY</span>
                            <p class="mx-3 consultantDetails">{{$consultantDetails->city}}</p> -->
                          </div>
                        </div>


                      <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="input pincodelabel field w-100 mt-5">
                                <input name="address" class="address input__field" type="text" value="{{$consultantDetails->address}}" placeholder=" " />
                                <span class="input__label">Address</span>
                            </label>
                          <!-- <span class="consultantDetailsHeading badge text-light">ADDRESS</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->address}}</p> -->
                        </div>
                        <div class="col-md-6">
                            <label class="input pincodelabel field w-100 mt-5">
                                <input name="pincode" class="pincode input__field" type="number" value="{{$consultantDetails->pincode}}" placeholder=" " />
                                <span class="input__label">Pincode </span>
                            </label>
                          <!-- <span class="consultantDetailsHeading badge text-light">PIN CODE</span>
                          <p class="mx-3 consultantDetails">{{$consultantDetails->pincode}}</p> -->
                        </div>
                      </div>
                      <button style="float:right;" type="submit" class="mt-3 btn btn-success">Update</button>

                    </form>
                  
                  
                  @endif
                </div>
                {{-- Professional Details End --}}
                <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="profile-tab">
                  @if($consultantDetails)  

                    <form action="update_Ltab_3" method='post' enctype="multipart/form-data">
                      @csrf
                        <div class="row mb-3">
                          <div class="col-md-6">

                          <label class="input  field w-100 mt-5">
                            <input  name="bar_council" class="input__field"  type="file" >
                            <span class="input__label"> Upload Bar Council Id</span>
                          </label>

                          </div>
                          <div class="col-md-6">
                          <label class="input  field w-100 mt-5">
                            <input  name="aadhar" class="input__field"  type="file" >
                            <span class="input__label"> Upload Aadhar</span>
                          </label>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <div class="col-md-6">

                          <label class="input  field w-100 mt-5">
                            <input  name="pancard" class="input__field"  type="file" >
                            <span class="input__label"> Upload Pancard</span>
                          </label>
                           
                            
                          </div>
                          
                        </div>
                        
                      <button style="float:right;" type="submit" class="mt-3 btn btn-success">Update</button>

                    </form>
                  
                  
                  @endif
                </div>
              </div>
            </div>
        </div>
    </div>
</div>
<!-- JavaScript Bundle with Popper -->
<script>
    $(document).ready(function(){
        $('.buttonProfile').click(function(){
            $('#layerProfile').click()
            
        })
        function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('.img-account-profile').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $("#layerProfile").change(function(){
        readURL(this);
    });
    })

    $('.pan_card').on('input', function(e) {
           var pancard_val = $('.pan_card').val();
            var regex = /([A-Z]){5}([0-9]){4}([A-Z]){1}$/;
        if (regex.test(pancard_val.toUpperCase())) {
            
            $(".required-notice-pancard").html("");
        } else {
            $(".required-notice-pancard").html("");
            $('<small class="text-danger required-notice-pancard mb-2"> <i class="fa fa-warning"></i>Please Enter Valid PAN Card</small>').insertAfter($(".pancardlabel"))
        }
        });
        
        $('.aadhar_card').on('keypress', function(e) {
            var $this = $(this);
            var regex = new RegExp("^[0-9\b]+$");
            var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
            // for 10 digit number only
            if ($this.val().length > 11) {
                e.preventDefault();
                return false;
            } 
        });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>