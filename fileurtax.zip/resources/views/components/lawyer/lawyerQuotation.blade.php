<div class="container">
    <div class="card">
        @php
            $quotations = DB::table('askquotations')
            ->where('services','L')
            ->first();
        @endphp
        @if ($quotations)
            <div class="text-center">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th>Customer Name</th>
                            <th>Quotation Amount</th>
                            <th>Message</th>
                            <th>Bid Status</th>
                            
                        </tr>
                        @php
                            $allQuoatations = DB::table('askquotations')
                            ->where('services','L')
                            ->get();
                      @endphp
                        @foreach ($allQuoatations as $allQuoatation)
                            @php
                                $customer = DB::table('members')
                                ->where('email',$allQuoatation->email)
                                ->first();
                            @endphp
                            <tr>
                                <td>{{$customer->fname}}</td>
                                <td>₹ {{$allQuoatation->quotation_price}}.00</td>
                                <td>{{$allQuoatation->message}}</td>
                                <td>
                                    @php
                                        $lawyer = DB::table('members')
                                        ->where('email',session('layerAuth'))
                                        ->first();
                                        $bid = DB::table('bids')
                                        ->where('consultantId',$lawyer->id)
                                        ->first();
                                    @endphp
                                    @if (!$bid)
                                        <div>
                                            <form action="bidSubmit" method="POST">
                                                @csrf
                                                <input type="hidden" name="quotationid" value="{{$allQuoatation->id}}">
                                                <input type="hidden" name="consultantId" value="{{$lawyer->id}}">
                                                <input name="amount" type="text" class="form-control d-inline" style="width: 150px" placeholder="Bid Amount" required>
                                                <button type="submit" class="btn btn-primary btn-sm">Bid</button>
                                            </form>
                                        </div>
                                    @else
                                        <div>
                                            <input type="text" value="₹ {{$bid->amount}}.00" class="form-control d-inline" style="width: 150px" disabled readonly>
                                        </div>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        @else
            <div class="text-center mt-5 mb-5">
                <h5 class="text-danger">No Quotation Submitted Yett</h5>
            </div>
        @endif
    </div>
</div>