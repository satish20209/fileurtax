@php
    $laywerDetails =DB::table('members')
    ->where('email',session('layerAuth'))
    ->first();

    $ary=[];
    $ar1=[];
    $totel_req=DB::table('services_requests')->where([['accept',NULL],['status',1]])->get();
    foreach($totel_req as $t_req){
      array_push($ary,$t_req);
    }
    foreach($ary as $t_req){
      array_push($ar1,DB::table('members')->where('id',$t_req->service_provider_id)->first('role'));
    }
    foreach($ar1 as $t_req){
    }
@endphp 

<div class="row">
    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
      {{-- Packages Card --}}
      <div href="superAdminPackages" class="card card-statistics text-decoration-none">
        <div class="card-body">
          <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
            <div class="float-left">
              <i class="mdi mdi-package-variant text-danger icon-lg"></i>
            </div>
            <div class="float-right">
              <p class="mb-0 text-right analyticsCardHeading">Service Request</p>
              <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">5</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      {{-- Packages Card End --}}
    </div>
    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
      {{-- Consultations Card --}}
      <div href="superAdminConsulations" class="card card-statistics text-decoration-none">
        <div class="card-body">
          <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
            <div class="float-left">
              <i class="mdi mdi-help-box text-warning icon-lg"></i>
            </div>
            <div class="float-right">
              <p class="mb-0 text-right analyticsCardHeading">Running Services</p>
              <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">12</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      {{-- Consultations Card End --}}
    </div>
    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
      {{-- Sales Card --}}
      <div href="superAdminSales" class="card card-statistics text-decoration-none">
        <div class="card-body">
          <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
            <div class="float-left">
              <i class="mdi mdi-chart-pie text-success icon-lg"></i>
            </div>
            <div class="float-right">
              <p class="mb-0 text-right analyticsCardHeading">demo</p>
              <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">500</h3>
              </div>
            </div>
          </div>
          </div>
        </div>
      {{-- Sales Card End --}}
    </div>
    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
      {{-- Leads Card --}}
      <div href="superAdminLeads" class="card card-statistics text-decoration-none">
        <div class="card-body">
          <div class="d-flex flex-md-column flex-xl-row flex-wrap justify-content-between align-items-md-center justify-content-xl-between">
            <div class="float-left">
              <i class="mdi mdi-account-box-multiple text-info icon-lg"></i>
            </div>
            <div class="float-right">
              <p class="mb-0 text-right analyticsCardHeading">demo</p>
              <div class="fluid-container">
                <h3 class="font-weight-medium text-right mb-0">
                  200
                </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      {{-- Leads Card End --}}
    </div>
  </div>


  <div class="row">
    <div class="col-md-6 col-xl-6 grid-margin stretch-card">
      {{-- Recent Consultation Bookings --}}
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Recent</h4>
          <div class="shedule-list d-flex align-items-center justify-content-between mb-3">
            <h3>Requests</h3>
          </div>
          @php
              $serviceRequests = DB::table('services_requests')
              ->where(
                [
                  'service_provider_id' => $laywerDetails->id,
                  'status' => '0',
                ]
              )
              ->orderBy('id','desc')
              ->take(3)
              ->get();
              $serviceRequestsExists = DB::table('services_requests')
              ->where(
                  [
                      'service_provider_id' => $laywerDetails->id,
                      'status' => '0',
                  ]
                      )
              ->exists();
          @endphp
          @if ($serviceRequestsExists)
            @foreach ($serviceRequests as $serviceRequest)
            @php
                $customers = DB::table('members')->where('id',$serviceRequest->customer_id)->first();
                $requirement = DB::table('customer_requirements')->where('user_id',$serviceRequest->customer_id)->first();
            @endphp

              <div class="event border-bottom py-3">
                
                <p class="mb-2 font-weight-medium">Name : {{$customers->fname}}</p>
                <p class="mb-2 font-weight-medium">Requirements : {{$requirement->requirements}}</p>
                <div class="d-flex align-items-center">
                  <form action="lawyerAcceptRequest" method="POST">
                    @csrf
                    <input type="hidden" name="service_provider_id" value="{{$laywerDetails->id}}">
                    <input type="hidden" name="customer_id" value="{{$customers->id}}">
                    <button type="submit" class="btn btn-success text-light mr-3">Accept</button>
                  </form>
                  <form action="lawyerDenyRequest" method="POST">
                    @csrf
                    <input type="hidden" name="service_provider_id" value="{{$laywerDetails->id}}">
                    <input type="hidden" name="customer_id" value="{{$customers->id}}">
                    <button type="submit" class="btn btn-danger text-light mr-3">Deny</button>
                </form>
                </div>
              </div>
            @endforeach
          @else
              <p class="text-mute">No Service Request Recieved</p>
          @endif
         
          
        </div>
      </div>
      {{-- Recent Consultation Bookings End --}}
    </div>
    <div class="col-md-6 col-xl-6 grid-margin stretch-card">
      {{-- Recent Package Orders --}}

      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Running</h4>
          <div class="shedule-list d-flex align-items-center justify-content-between mb-3">
            <h3>Services</h3>
          </div>
          @php
              $serviceRequests = DB::table('services_requests')
              ->where(
                [
                  'service_provider_id' => $laywerDetails->id,
                  'status' => '1',
                ]
              )
              ->orderBy('id','desc')
              ->take(3)
              ->get();
              $serviceRequestsExists = DB::table('services_requests')
                                ->where(
                                    [
                                        'service_provider_id' => $laywerDetails->id,
                                        'status' => '1',
                                    ]
                                        )
                                ->exists();
          @endphp
          @if ($serviceRequestsExists)
            @foreach ($serviceRequests as $serviceRequest)
              @php
                  $customers = DB::table('members')->where('id',$serviceRequest->customer_id)->first();
                  $requirement = DB::table('customer_requirements')->where('user_id',$serviceRequest->customer_id)->first();
              @endphp
              @php
              if ($serviceRequest->accept == NULL) {
              $disable = 'disabled';
              }else {
              $disable = '';
              }
              @endphp
              <div class="event border-bottom py-3">
                <p class="mb-2 font-weight-medium">Name : {{$customers->fname}}</p>
                <p class="mb-2 font-weight-medium">Requirements : {{$requirement->requirements}}</p>
                <div class="d-flex align-items-center">
                  <form action="customerDetails" method="POST">
                    @csrf
                    <input type="hidden" name="customer_id" value="{{$customers->id}}">
                    <button type="submit" {{$disable}} class="btn btn-primary text-light mr-3">View Details</button>
                  </form>
                </div>
              </div>
            @endforeach
          @else
              <p class="text-mute">No Service Services Accepted</p>
          @endif
        </div>
      </div>
      
      {{-- Recent Package Orders End --}}
    </div>
    <div class="col-md-12 col-xl-6 grid-margin stretch-card">
      
     


    </div>
  </div>