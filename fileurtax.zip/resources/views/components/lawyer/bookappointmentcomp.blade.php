@php
    $serviceProviders = DB::table('members')->where('email',session('layerAuth'))->first();
    
    $servicerequest = DB::table('services_requests')->where('service_provider_id',$serviceProviders->id)->get();         
@endphp
@if($servicerequest != "")
<div>
    <h3 class="m-3 mb-5">Appointment Details</h3>
<div class="row p-3">
    @foreach($servicerequest as $data)
    @if ($data->appdate != "" && $data->appdate != "" && $data->timeperiod != "" )
            @php
            $custid = $data->customer_id;
             $customerDetails = DB::table('members')->where('id',$custid)->first();
             @endphp
                <div class="col-12 col-md-6 col-sm-12 col-lg-4 mb-3 ml-3">
                    <div class="card  p-3 w-100" >  
                        <h5 class="text-center">Customer Appointment Details</h5>
                        <table class="table table-striped table-bordered mb-3">
                            
                            <tr>
                                <th class="bg-primary text-light">Name</th>
                                <td class="srprovider"> {{$customerDetails->fname}}</td>
                            </tr>
                            <tr>
                                <th class="bg-primary text-light">Mobile</th>
                                <td class="srprovider"> {{$customerDetails->mobile}}</td>
                            </tr>
                            <tr>
                                <th class="bg-primary text-light">Email ID</th>
                                <td class="srprovider">{{$customerDetails->email}}</td>
                            </tr>
                            <tr>
                                <th class="bg-primary text-light">Date</th>
                                <td class="srprovider">{{$data->appdate}}</td>
                            </tr>
                            <tr>
                                <th class="bg-primary text-light">Time</th>
                                <td class="srprovider">{{$data->apptime}}</td>
                            </tr>
                            <tr>
                                <th class="bg-primary text-light">Time Period</th>
                                <td class="srprovider">{{$data->timeperiod}}</td>
                            </tr>
                            <tr>
                                <th class="bg-primary text-light">Charge</th>
                                <td class="srprovider">{{$data->fee}}</td>
                            </tr>
                        </table>
                        <button type="button" atime="{{$data->apptime}}" tperiod="{{$data->timeperiod}}" fee="{{$data->fee}}" adate="{{$data->appdate}}" custid="{{$customerDetails->id}}" lid="{{$data->service_provider_id}}" cname="{{$customerDetails->fname}}" lname="{{$serviceProviders->fname}}"   class="btn btn-primary bookAppointmenteditbtn">Edit Appointment</button>
                    </div>
                </div>
            @else
            <div>
               
                <p>No Appointment Booked </p>
            </div>
            @php
            exit;
            @endphp
            @endif
    @endforeach
</div>
</div>
@else
<div>
    <h3>Appointment Details</h3>
    <p>No Appointment Booked </p>
</div>  
@endif
<div class="modal fade" id="bookAppointmenteditmodel" tabindex="-1" aria-labelledby="bookAppointmentmodelLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background: #fc0765">
                <h5 class="modal-title text-white"><b>Book Appointment</b></h5>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="layername">lawyer Name</label>
                    <input type="text" disabled name="layer" id="layername" class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Customer Name</label>
                    <input type="text" disabled name="customer" id="customername" class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Select Appointment Date</label>
                    <input type="date" required name="customer" id="appdate" class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Select Appointment Time</label>
                    <input type="time" required name="customer" id="apptime" class="form-control">
                </div>

                <div class="form-group">
                    <label for="customername">Select Time Period </label>
                    <select required name="appointmenttime" id="appointmenttime" style="color: black;width:100%;border-radius:5px;padding:5px;">
                        <option value="15" selected>15 Minutes</option>
                        <option value="30">30 Minutes</option>
                        <option value="60">60 Minutes</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="customername"> Appointment Charge</label>
                    <input type="text" disabled name="feecharge" id="feecharge" class="form-control" value="300">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger bookAppointmentmodelclose" >Cancel</button>
                <button type="button" class="btn btn-primary booknowbtn"  >Update</button>
            </div>
        </div>
    </div>
</div>




<script>

    $(document).ready(function(){
        $(".bookAppointmentmodelclose").click(function(){
            $("#bookAppointmenteditmodel").modal('hide');
        });

        $("#appointmenttime").on("change",function(){
            if($("#appointmenttime").val() == "15"){
            $("#feecharge").val("300");
            }
            else if($("#appointmenttime").val() == "30"){
                $("#feecharge").val("600");
            }
            else if($("#appointmenttime").val() == "60"){
                $("#feecharge").val("900");
            }
        })
        
        $(".bookAppointmenteditbtn").each(function(){
            $(this).click(function(){
                var  lid = $(this).attr("lid");
                var  custid = $(this).attr("custid");
                $("#layername").val($(this).attr("lname"));
                $("#customername").val($(this).attr("cname"));
                var  atime = $(this).attr("atime");
                var  tperiod = $(this).attr("tperiod");
                var  fee = $(this).attr("tperiod");
                var  adate = $(this).attr("adate");
                $("#bookAppointmenteditmodel").modal('show');
                $(".booknowbtn").click(function(){ 
                    if($("#appdate").val() == "" && $("#apptime").val() == ""){
                alert("please fill app filed")
            }
            else{
                        $.ajax({
                            url: 'bookappointment',
                            type: 'get',
                            data: {
                                '_token': '{{csrf_token()}}',
                                lid:lid,
                                custid:custid,
                                appdate:$("#appdate").val(),
                                apptime:$("#apptime").val(),
                                timeperiod:$("#appointmenttime").val(),
                                fee:$("#feecharge").val()
                            },
                            success: function(response) {
                                alert(response.response);
                                $("#bookAppointmenteditmodel").modal('hide');
                                window.location.href = '/viewbookedappointment';
                            },
                            error: function(error) {
                            },
                        });
                    }
                    })
            })
        })


    
    })
</script>