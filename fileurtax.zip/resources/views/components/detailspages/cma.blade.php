<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css?cache=<?php echo time(); ?>">
<link rel="stylesheet" href="css/materialize.min.css?cache=<?php echo time(); ?>">
<link rel="stylesheet" href="css/responsive.css?cache=<?php echo time(); ?>">

<!-- Page Title -->
<section class="page-title" style="background-image:url(images/background/1.jpg)">
    <div class="auto-container">
        <h1>CMA Personal Details</h1>
        <ul class="page-breadcrumb">
            <li><a href="/">Home</a></li>
            <li>CMA Personal Details</li>
        </ul>
    </div>
</section>
<!-- End Page Title -->

<div>
@if(session()->has('cmaAuth'))
<input value={{session('cmaAuth')}} type="text" class="get_email d-none">
@endif
    <div class=" mb-4 m-3">
        <div class="custom-d-flex mt-4 mb-4">
            <div class=" row w-75 ">
                <div class="col d-flex">
                    <div class="me-3">
                        <span class="box-fafa">
                            <i class="fa fa-user-circle-o fafa-custom"></i>
                        </span>
                    </div>

                    <div class="">
                        {{-- <div class="">Step 1</div> --}}
                        <h4 class="hedding mt-2">Personal Details</h4>
                    </div>
                </div>

                {{-- <div class="col d-flex">
                <div class="me-3">
                    <span class="box-fafa">
                        <i class="fa fa-check-circle fafa-custom"></i>
                    </span>
                </div>

                <div class="">
                    <div class="">Step 2 </div>
                    <div class="">Self Assessment </div>
                </div>
            </div> --}}

                <div class="col d-flex d-none">
                    <div class="me-3">
                        <span class="box-fafa">
                            <i class="fa fa-check-circle fafa-custom"></i>
                        </span>
                    </div>

                    <div class="">
                        <div class="">Step 2</div>
                        <div class="">OTP Verification </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="step-one-conn ">
                <div class=" row shadow m-2 mt-5 p-3" style="background: #ddd">
                    <input type="hidden" name="lat" id="" class="lat">
                    <input type="hidden" name="lat" id="" class="longt">

                    <div class="row">
                        <div class="col-md-3 mb-4 ">
                        <img class="profileImage" src="" alt="user profile">
                            <!-- <input type="file" name="" class="profileImage" id="">
                            <p class="text-center display-6 mt-1">Upload Photo</p> -->
                        </div>
                        <div class="col-md-8 bg-white p-5  ">
                            <div class="row">
                                <div class="col-12">
                                    <h4>Personal Details</h4>
                                    <p>Share your personal details with us </p>
                                </div>
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="input fnamelabel field w-100 mt-4">
                                                <input class="fname input__field" type="text" placeholder=" " />
                                                <span class="input__label">Full Name <span class="red">*</span></span>
                                            </label>
                                        </div>
                                        <div class="col-md-6">
                                            <label  class="input emaillabel field w-100 mt-4">
                                                <input disabled class="email input__field" type="email" placeholder=" " />
                                                <span class="input__label">Email <span class="red">*</span></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="input pancardlabel field w-100 mt-4">
                                                <input class="pancard text-uppercase input__field" type="text"
                                                    placeholder=" " />
                                                <span class="input__label">PAN Card <span class="red">*</span></span>
                                            </label>  
                                        </div>
                                        <div class="col-md-6">
                                            <label class="input aadhaarcardlabel field w-100 mt-4">
                                                <input class="aadhaarcard input__field" id="aadhaarcard" type="number"
                                                    placeholder=" " />
                                                <span class="input__label">Aadhaar Card <span class="red">*</span></span>
                                            </label>
                                        </div>
                                        
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="input mobilelabel field w-100 mt-4">
                                                    <input class="mobile input__field" type="number" placeholder=" " />
                                                    <span class="input__label">Mobile Number <span class="red">*</span></span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label class=" w-100 mt-4">
                                                    <div class="form-group gender-group">
                                                        <label class="input__field  w-100">Gender<span
                                                                class="red">*</span></label>
                                                        <div class="display-flex genderlabel mb-2 gender-flex" id="gender">
                                                            <div class="custom-radio  display-inline mb-2">
                                                                <input type="radio" name="gender" value="male"
                                                                    class="styled-radio gender" id="male">
                                                                <label for="male">Male</label>
                                                            </div>
                                            
                                                            <div class="custom-radio display-inline mb-2 ml-auto">
                                                                <input type="radio" name="gender" value="female"
                                                                    class="styled-radio gender" id="female">
                                                                <label for="female">Female</label>
                                                            </div>
                                            
                                                            <div class="custom-radio display-inline mb-2 ml-auto">
                                                                <input type="radio" name="gender" value="other"
                                                                    class="styled-radio gender" id="other">
                                                           <label for="other">Other</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                
                            </div>
                        </div>
                        <div class="col-12 d-flex justify-content-end p-3">
                            <button type="button" class="step-one-next btn btn-primary">Next</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="step-two-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Professional Details</h4>
                        <p>Fill in your professional details below</p>
                    </div>

                    <div class="col-12">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="input practincingSincelabel field w-100 mt-5">
                                    <input class="recognitions awardsandrecognitions input__field" type="text" placeholder=" " />
                                    <span class=" input__label">Awards and Recognitions <span class="red">*</span></span>
                                </label>
                            </div>

                            <div class="col-md-4">
                                <label class="input barEnrollmentNumberlabel field w-100 mt-5">
                                    <input class="barEnrollmentNumber input__field" type="number"  placeholder=" " />
                                    <span class="input__label">Firm Registration Number <span
                                            class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input enrollment_statelabel field w-100 mt-5">
                                    <select class="enrollment_state input__field" type="text" placeholder=" ">
                                        <option value="Industry Experience">Industry Experience</option>
                                        <option value="Agriculture">Agriculture</option>
                                        <option value="Automobiles">Automobiles</option>
                                        <option value="Aviation">Aviation</option>
                                        <option value="Banking">Banking</option>
                                        <option value="Biotechnology">Biotechnology</option>
                                        <option value="Cement">Cement</option>
                                        <option value="Consumer Markets">Consumer Markets</option>
                                        <option value="Education and Traning">Education and Traning</option>
                                        <option value="">Engineering</option>
                                        <option value="Engineering">Financial Services</option>
                                        <option value="">Gems and Jewellery</option>
                                        <option value="Gems and Jewellery">Healthcare</option>
                                        <option value="">Infrastructure</option>
                                        <option value="Infrastructure">Insurance</option>
                                        <option value="IT & ITeS">IT & ITeS</option>
                                        <option value="Manufacturing">Manufacturing</option>
                                        <option value="Media and Entertainment">Media and Entertainment</option>
                                        <option value="Oil and Gas">Oil and Gas</option>
                                        <option value="Pharmaceuticals">Pharmaceuticals</option>
                                        <option value="Real Estate">Real Estate</option>
                                        <option value="Research and Development Retail">Research and Development Retail</option>
                                        <option value="Science and Technology">Science and Technology</option>
                                        <option value="Services">Services</option>
                                        <option value="Steel">Steel</option>
                                        <option value="Telecommunications">Telecommunications</option>
                                        <option value="Textiles">Textiles</option>
                                        <option value="Tourism and Hospitality">Tourism and Hospitality</option>
                                        <option value="Urban Market">Urban Market</option>
                                        <option value="Other">Other</option>
                                        
                                    </select>
                                    <span class="input__label">Industry Experience<span
                                            class="red">*</span></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <input type="text" id="token" hidden  value="@yield('token')">
                    <div class="col-12">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="input field w-100 mt-5">
                                    <select disabled class="country input__field" type="text" placeholder=" ">
                                        <option value="India">India</option>
                                    </select>
                                    <span class="input__label">Country<span class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input statelabel field w-100 mt-5">
                                    <select class="state input__field" type="text" placeholder=" ">
                                        <option value="">Select State</option>
                                        @yield('country')
                                    </select>
                                    <span class="input__label">Select State<span class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input citylabel field w-100 mt-5">
                                    <select class="city input__field" type="text" placeholder=" ">
                                        <option value="">Select City</option>
                                    </select>
                                    <span class="input__label">Select City<span class="red">*</span></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <label class=" input addresslabel field w-100 mt-5">
                                <input class="address input__field" type="text" placeholder=" " />
                                <span class="input__label">Address <span class="red">*</span></span>
                            </label>
                        </div>
                        <div class="col-md-3">
                            <label class="input pincodelabel field w-100 mt-5">
                                <input class="pincode input__field" type="number" placeholder=" " />
                                <span class="input__label">Pincode <span class="red">*</span></span>
                            </label>
                        </div>

                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <label for=""><b>Services Offered By Yourself</b></label>
                        </div>
                        <div class="col-12">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input serviceselect" type="checkbox" id="one" value="Feasibility Studies and Concept Estimates">
                                <label class="form-check-label" for="one">Feasibility Studies and Concept Estimates</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input serviceselect" type="checkbox" id="one" value="Cost Planning">
                                <label class="form-check-label" for="one">Cost Planning</label>
                            </div>
                            
                            <div class="form-check form-check-inline">
                                <input class="form-check-input serviceselect" type="checkbox" id="one" value="Budget Planning">
                                <label class="form-check-label" for="one">Budget Planning</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input serviceselect" type="checkbox" id="one" value="Cost Estimating">
                                <label class="form-check-label" for="one">Cost Estimating</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input serviceselect" type="checkbox" id="one" value="Project Cost Management">
                                <label class="form-check-label" for="one">Project Cost Management</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input serviceselect" type="checkbox" id="one" value="Procurement Bid Evaluation and Reconciliation">
                                <label class="form-check-label" for="one">Procurement Bid Evaluation and Reconciliation</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input serviceselect" type="checkbox" id="one" value="Final Account Negotiation Cost Auditing">
                                <label class="form-check-label" for="one">Final Account Negotiation Cost Auditing</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-one-back btn btn-primary">Back</button>
                        <button class="step-two-next btn btn-primary">Next</button>
                    </div>
                </div>
            </div>

            <div class="step-three-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Description</h4>
                        <p>Tell us something about yourself</p>
                    </div>
                    <textarea class="abouts" name="" id="" rows="10"></textarea>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-two-back btn btn-primary">Back</button>
                        <button class="step-three-next btn btn-primary">Next</button>
                    </div>
                </div>
            </div>

            <div class="step-for-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Upload Documents</h4>
                        <p>Add your Documents here</p>
                    </div>
                    {{-- <div class="d-flex justify-content-center">
                        <div style="margin-right:20px;" class="d-flex flex-column justify-content-center">
                            <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i>
                            <label class="input field mb-4">
                                <input class="barCouncildD input__field d-none" type="file" placeholder=" " />
                                <span class="input__label"
                                    style="background: red;width:120px;padding:10px;color:white;font-size:18px;border-radius:5px;">Browse
                                    File</span>
                            </label>
                        </div>
                        <div style="margin-right:20px;" class="d-flex flex-column justify-content-center mr-5">
                            <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i>
                            <label class="input field mb-4">
                                <input class="aadhar_file input__field d-none" type="file" placeholder=" "  accept="image/png, image/jpg, image/jpeg"/>
                                <span class="input__label"
                                    style="background: red;width:120px;padding:10px;color:white;font-size:18px;border-radius:5px;">Aadhar Card</span>
                            </label>
                        </div>
                        <div style="margin-right:20px;" class="d-flex flex-column justify-content-center">
                            <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i>
                            <label class="input field mb-4">
                                <input class="pancard_file input__field d-none" type="file" placeholder=" "  accept="image/png, image/jpg, image/jpeg"/>
                                <span class="input__label"
                                    style="background: red;width:120px;padding:10px;color:white;font-size:18px;border-radius:5px;">Pan card</span>
                            
                             </label>
                        </div>
                    </div> --}}
                    <div class="row d-flex justify-content-center">
                        <div style="margin-right:20px;" class="col d-flex flex-column justify-content-center ">
                            {{-- <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i> --}}
                            {{-- <label class=" mb-4"> --}}
                                <input class="barCouncildD" type="file" placeholder=" "  accept="image/png, image/jpg, image/jpeg"/>
                                <span class=""
                                    style="margin-top:13px;background: #0d6efd;width:149px;margin-bottom:13px;padding:10px;color:white;font-size:18px;border-radius:5px;">Firm Certificate</span>
                            {{-- </label> --}}

                            
                        </div>
                        <div style="margin-right:20px;" class="col d-flex flex-column justify-content-center mr-5">
                            {{-- <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i> --}}
                            {{-- <label class="input field mb-4"> --}}
                                <input class="aadhar_file " type="file" placeholder=" "  accept="image/png, image/jpg, image/jpeg"/>
                                <span class=""
                                    style="background: #0d6efd;width:137px;margin-top:13px;margin-bottom:13px;padding:10px;color:white;font-size:18px;border-radius:5px;">Aadhar Card</span>
                            {{-- </label> --}}
                        </div>
                        <div style="margin-right:20px;" class="col d-flex flex-column justify-content-center">
                            {{-- <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i> --}}
                            {{-- <label class=" mb-4"> --}}
                                <input class="pancard_file " type="file" placeholder=" "  accept="image/png, image/jpg, image/jpeg"/>
                                <span class="" style="margin-top:13px;margin-bottom:13px;background: #0d6efd;width:120px;padding:10px;color:white;font-size:18px;border-radius:5px;">Pan card</span>
                            
                             {{-- </label> --}}
                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-three-back btn btn-primary">Back</button>
                        <button class="step-for-next btn btn-primary">Next</button>
                    </div>
                    
                </div>
            </div>

            <div class="step-five-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Publication Areas</h4>
                        <p>Add your publication links here to showcase your work</p>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="publication_areas_1 input__field" type="text" placeholder=" " />
                            <span class="input__label">Publication Areas 1 </span>
                        </label>
                        <small>Enter URL with https:// or http://</small>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="publication_areas_2 input__field" type="text" placeholder=" " />
                            <span class="input__label">Publication Areas 2 </span>
                        </label>
                        <small>Enter URL with https:// or http://</small>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="publication_areas_3 input__field" type="text" placeholder=" " />
                            </span><span class="input__label">Publication Areas 3 </span>

                        </label>
                        <small>Enter URL with https:// or http://</small>
                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-for-back btn btn-primary">Back</button>
                        <button class="step-five-next btn btn-primary">Next</button>
                    </div>
                </div>
            </div>

            <div class="step-six-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Social Media Links</h4>
                        <p>Add your social media details here so we can reach out to you</p>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="facebook input__field" type="text" placeholder=" " />
                            <span class="input__label"><span> <i class="fa fa-facebook"
                                        style="color: #4267B2"></i></span>
                                Facebook </span>
                        </label>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="twitter input__field" type="text" placeholder=" " />
                            <span class="input__label"><span> <i class="fa fa-twitter"
                                        style="color: #00acee"></i></span>
                                Twitter </span>
                        </label>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="linkedin input__field" type="text" placeholder=" " />
                            </span><span class="input__label"><span> <i class="fa fa-linkedin"
                                        style="color:#0077b5"></i></span> Linkedin </span>
                        </label>
                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-five-back btn btn-primary">Back</button>
                        <button class="step-six-next btn btn-primary">Next</button>
                    </div>
                    
                </div>
            </div>

            <div class="step-seven-conn d-none">
                <div class="row shadow m-2 m-sm-3 m-md-3 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Weekly Plan</h4>
                        <p>The customer will have the option to book 30 mins for the consultancy out of slot 1 or slot 2
                        </p>
                    </div>
                    <div class="plan-list weeklyPlanAll">
                        <ul class="row d-flex flex-row">
                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_mon" value="mon"
                                            class="monday styled-checkbox weeklyPlan" id="mondayPlan">
                                        <label for="mondayPlan">Monday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="mon_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[mon][]" disabled="disabled"
                                                    value="" day="mon" autocomplete="off">
                                                -
                                                <input
                                                    class=" mon_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[mon][]" disabled="disabled"
                                                    value="" day="mon" id="jq_first_half_mon"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="mon_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[mon][]" disabled="disabled"
                                                    value="" day="mon" autocomplete="off">
                                                -
                                                <input
                                                    class="mon_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[mon][]" disabled="disabled"
                                                    value="" day="mon" id="jq_second_half_mon"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_tue" value="tue"
                                            class="tuesday styled-checkbox weeklyPlan" id="tuesdayPlan">
                                        <label for="tuesdayPlan">Tuesday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="tue_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[tue][]" disabled="disabled"
                                                    value="" day="tue" autocomplete="off">
                                                -
                                                <input
                                                    class="tue_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[tue][]" disabled="disabled"
                                                    value="" day="tue" id="jq_first_half_tue"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="tue_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[tue][]" disabled="disabled"
                                                    value="" day="tue" autocomplete="off">
                                                -
                                                <input
                                                    class="tue_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[tue][]" disabled="disabled"
                                                    value="" day="tue" id="jq_second_half_tue"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_wed" value="wed"
                                            class="wednesday styled-checkbox weeklyPlan" id="wednesdayPlan">
                                        <label for="wednesdayPlan">Wednesday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="wed_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[wed][]" disabled="disabled"
                                                    value="" day="wed" autocomplete="off">
                                                -
                                                <input
                                                    class="wed_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[wed][]" disabled="disabled"
                                                    value="" day="wed" id="jq_first_half_wed"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="wed_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[wed][]" disabled="disabled"
                                                    value="" day="wed" autocomplete="off">
                                                -
                                                <input
                                                    class="wed_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[wed][]" disabled="disabled"
                                                    value="" day="wed" id="jq_second_half_wed"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_thu" value="thu"
                                            class="thursday styled-checkbox weeklyPlan" id="thursdayPlan">
                                        <label for="thursdayPlan">Thursday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="thu_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[thu][]" disabled="disabled"
                                                    value="" day="thu" autocomplete="off">
                                                -
                                                <input
                                                    class="thu_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[thu][]" disabled="disabled"
                                                    value="" day="thu" id="jq_first_half_thu"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="thu_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[thu][]" disabled="disabled"
                                                    value="" day="thu" autocomplete="off">
                                                -
                                                <input
                                                    class="thu_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[thu][]" disabled="disabled"
                                                    value="" day="thu" id="jq_second_half_thu"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_fri" value="fri"
                                            class="friday styled-checkbox weeklyPlan" id="fridayPlan">
                                        <label for="fridayPlan">Friday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="fri_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[fri][]" disabled="disabled"
                                                    value="" day="fri" autocomplete="off">
                                                -
                                                <input
                                                    class="fri_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[fri][]" disabled="disabled"
                                                    value="" day="fri" id="jq_first_half_fri"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="fri_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[fri][]" disabled="disabled"
                                                    value="" day="fri" autocomplete="off">
                                                -
                                                <input
                                                    class="fri_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[fri][]" disabled="disabled"
                                                    value="" day="fri" id="jq_second_half_fri"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_sat" value="sat"
                                            class="saturday styled-checkbox weeklyPlan" id="saturdayPlan">
                                        <label for="saturdayPlan">Saturday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="sat_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sat][]" disabled="disabled"
                                                    value="" day="sat" autocomplete="off">
                                                -
                                                <input
                                                    class="sat_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sat][]" disabled="disabled"
                                                    value="" day="sat" id="jq_first_half_sat"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="sat_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sat][]" disabled="disabled"
                                                    value="" day="sat" autocomplete="off">
                                                -
                                                <input
                                                    class="sat_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sat][]" disabled="disabled"
                                                    value="" day="sat" id="jq_second_half_sat"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_sun" value="sun"
                                            class="sunday styled-checkbox weeklyPlan" id="sundayPlan">
                                        <label for="sundayPlan">Sunday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="sun_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sun][]" disabled="disabled"
                                                    value="" day="sun" autocomplete="off">
                                                -
                                                <input
                                                    class="sun_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sun][]" disabled="disabled"
                                                    value="" day="sun" id="jq_first_half_sun"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="sun_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sun][]" disabled="disabled"
                                                    value="" day="sun" autocomplete="off">
                                                -
                                                <input
                                                    class="sun_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sun][]" disabled="disabled"
                                                    value="" day="sun" id="jq_second_half_sun"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>

                    </div>
                    <div class="col-12 d-flex justify-content-between p-5">
                        <div>
                            <input type="checkbox" name="accept_terms_conditions" class="styled-checkbox"
                                id="accept_terms_conditions">
                            <label for="accept_terms_conditions">Accept Terms Conditions
                            </label>
                        </div>

                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-six-back btn btn-primary">Back</button>
                        <button class="form_submit btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript" src="../js/jquery-ui.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/moment.min.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/jquery.timepicker.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/jquery.multiselect.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/jquery.multiselect.filter.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/jquery-ui.multidatespicker.js?cache=<?php echo time(); ?>"></script>
<script src="js/registerprovidercms.js?cache=<?php echo time(); ?>"></script>
