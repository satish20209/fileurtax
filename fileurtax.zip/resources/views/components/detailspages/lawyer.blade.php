<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../css/jquery-ui.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/materialize.min.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/responsive.css?cache=<?php echo time(); ?>">

    <!-- Page Title -->
    <section class="page-title" style="background-image:url(images/background/1.jpg)">
    	<div class="auto-container">
			<h1>Lawyer Personal Details</h1>
			<ul class="page-breadcrumb">
				<li><a href="/">Home</a></li>
				<li>Lawyer Personal Details</li>
			</ul>
        </div>
    </section>
    <!-- End Page Title -->


<div>
    @if(session()->has('layerAuth'))
<input value={{session('layerAuth')}} type="text" class="get_email d-none">
@endif
    <div class=" mb-4 m-3">
        <div class="custom-d-flex mt-4 mb-4">
            <div class=" row w-75 ">
                <div class="col d-flex">
                    <div class="me-3">
                        <span class="box-fafa">
                            <i class="fa fa-user-circle-o fafa-custom"></i>
                        </span>
                    </div>

                    <div class="">
                        {{-- <div class="">Step 1</div> --}}
                        <h4 class="hedding mt-2">Personal Details</h4>
                    </div>
                </div>

                {{-- <div class="col d-flex">
                    <div class="me-3">
                        <span class="box-fafa">
                            <i class="fa fa-check-circle fafa-custom"></i>
                        </span>
                    </div>

                    <div class="">
                        <div class="">Step 2 </div>
                        <div class="">Self Assessment </div>
                    </div>
                </div> --}}

                <div class="col d-flex d-none">
                    <div class="me-3">
                        <span class="box-fafa">
                            <i class="fa fa-check-circle fafa-custom"></i>
                        </span>
                    </div>

                    <div class="">
                        <div class="">Step 2</div>
                        <div class="">OTP Verification </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="step-one-conn">
                <div class=" row shadow m-2 mt-5 p-3" style="background: #ddd">
                    <input type="hidden" name="lat" id="" class="lat">
                    <input type="hidden" name="lat" id="" class="longt">

                    <div class="row">
                        <div class="col-md-3 mb-4 ">
                            <img class="profileImage" src="" alt="user profile">
                            
                        </div>
                        <div class="col-md-8 bg-white p-5  ">
                            <div class="row">
                                <div class="col-12">
                                    <h4>Personal Details</h4>
                                    <p>Share your personal details with us </p>
                                </div>
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="input fnamelabel field w-100 mt-4">
                                                <input  class="fname input__field" type="text" placeholder=" " />
                                                <span class="input__label">Full Name <span class="red">*</span></span>
                                            </label>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="input emaillabel field w-100 mt-4">
                                                <input disabled class="email input__field" type="email" placeholder=" " />
                                                <span class="input__label">Email <span class="red">*</span></span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="input pancardlabel w-100 mt-4">
                                                <input class="pancard text-uppercase input__field" type="text"
                                                    placeholder=" " />
                                                <span class="input__label">PAN Card <span class="red">*</span></span>
                                            </label>  
                                        </div>
                                        <div class="col-md-6">
                                            <label class="input aadhaarcardlabel field w-100 mt-4">
                                                <input class="aadhaarcard input__field" id="aadhaarcard" type="number"
                                                    placeholder=" " />
                                                <span class="input__label">Aadhaar Card <span class="red">*</span></span>
                                            </label>
                                        </div>
                                        
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="input mobilelabel field w-100 mt-4">
                                                    <input class="mobile input__field" type="number" placeholder=" " />
                                                    <span class="input__label">Mobile Number <span class="red">*</span></span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label class=" w-100 mt-4">
                                                    <div class="form-group gender-group">
                                                        <label class="input__field  w-100">Gender<span
                                                                class="red">*</span></label>
                                                        <div class="display-flex genderlabel mb-2 gender-flex" id="gender">
                                                            <div class="custom-radio  display-inline mb-2">
                                                                <input type="radio" name="gender" value="male"
                                                                    class="styled-radio gender" id="male">
                                                                <label for="male">Male</label>
                                                            </div>
                                            
                                                            <div class="custom-radio display-inline mb-2 ml-auto">
                                                                <input type="radio" name="gender" value="female"
                                                                    class="styled-radio gender" id="female">
                                                                <label for="female">Female</label>
                                                            </div>
                                            
                                                            <div class="custom-radio display-inline mb-2 ml-auto">
                                                                <input type="radio" name="gender" value="other"
                                                                    class="styled-radio gender" id="other">
                                                                <label for="other">Other</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                
                            </div>
                        </div>
                        <div class="col-12 d-flex justify-content-end p-3">
                            <button type="button" class="step-one-next btn btn-primary">Next</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="step-two-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Professional Details</h4>
                        <p>Fill in your professional details below</p>
                    </div>

                    <div class="col-12">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="input practincingSincelabel field w-100 mt-5">
                                    <select class="practincingSince input__field" type="text" placeholder=" ">
                                        <option value="">Practicing Since</option>
                                        <option value="2022">2022</option>
                                        <option value="2021">2021</option>
                                        <option value="2020">2020</option>
                                        <option value="2019">2019</option>
                                        <option value="2018">2018</option>
                                        <option value="2017">2017</option>
                                        <option value="2016">2016</option>
                                        <option value="2015">2015</option>
                                        <option value="2014">2014</option>
                                        <option value="2013">2013</option>
                                        <option value="2012">2012</option>
                                        <option value="2011">2011</option>
                                        <option value="2010">2010</option>
                                        <option value="2009">2009</option>
                                        <option value="2008">2008</option>
                                        <option value="2007">2007</option>
                                        <option value="2006">2006</option>
                                        <option value="2005">2005</option>
                                        <option value="2004">2004</option>
                                        <option value="2003">2003</option>
                                        <option value="2002">2002</option>
                                        <option value="2001">2001</option>
                                        <option value="2000">2000</option>
                                        <option value="1999">1999</option>
                                        <option value="1998">1998</option>
                                        <option value="1997">1997</option>
                                        <option value="1996">1996</option>
                                        <option value="1995">1995</option>
                                        <option value="1994">1994</option>
                                        <option value="1993">1993</option>
                                        <option value="1992">1992</option>
                                        <option value="1991">1991</option>
                                        <option value="1990">1990</option>
                                        <option value="1989">1989</option>
                                        <option value="1988">1988</option>
                                        <option value="1987">1987</option>
                                        <option value="1986">1986</option>
                                        <option value="1985">1985</option>
                                        <option value="1984">1984</option>
                                        <option value="1983">1983</option>
                                        <option value="1982">1982</option>
                                        <option value="1981">1981</option>
                                        <option value="1980">1980</option>
                                        <option value="1979">1979</option>
                                        <option value="1978">1978</option>
                                        <option value="1977">1977</option>
                                        <option value="1976">1976</option>
                                        <option value="1975">1975</option>
                                        <option value="1974">1974</option>
                                        <option value="1973">1973</option>
                                        <option value="1972">1972</option>
                                        <option value="1971">1971</option>
                                        <option value="1970">1970</option>
                                        <option value="1969">1969</option>
                                        <option value="1968">1968</option>
                                        <option value="1967">1967</option>
                                        <option value="1966">1966</option>
                                        <option value="1965">1965</option>
                                        <option value="1964">1964</option>
                                        <option value="1963">1963</option>
                                        <option value="1962">1962</option>
                                        <option value="1961">1961</option>
                                        <option value="1960">1960</option>
                                        <option value="1959">1959</option>
                                        <option value="1958">1958</option>
                                        <option value="1957">1957</option>
                                        <option value="1956">1956</option>
                                        <option value="1955">1955</option>
                                        <option value="1954">1954</option>
                                        <option value="1953">1953</option>
                                        <option value="1952">1952</option>
                                        <option value="1951">1951</option>
                                        <option value="1950">1950</option>
                                        <option value="1949">1949</option>
                                        <option value="1948">1948</option>
                                        <option value="1947">1947</option>
                                        <option value="1946">1946</option>
                                        <option value="1945">1945</option>
                                        <option value="1944">1944</option>
                                        <option value="1943">1943</option>
                                    </select>
                                    <span class="input__label">Practincing Since <span class="red">*</span></span>
                                </label>
                            </div>

                            <div class="col-md-4">
                                <label class="input barEnrollmentNumberlabel field w-100 mt-5">
                                    <input class="barEnrollmentNumber input__field" type="number"  placeholder=" " />
                                    <span class="input__label">Bar Enrollment Number <span
                                            class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input enrollment_statelabel field w-100 mt-5">
                                    <select class="enrollment_state input__field" type="text" placeholder=" ">
                                        <option value="">Bar Enrolment State</option>
                                        <option value="Andhra Pradesh">Bar Council of Andhra Pradesh</option>
                                        <option value="Assam, Nagaland, Meghalaya, Manipur, Tripura, Mizoram">Bar
                                            Council of Assam,
                                            Nagaland, Meghalaya, Manipur, Tripura, Mizoram</option>
                                        <option value=" Bihar"> Bar Council of Bihar</option>
                                        <option value="Delhi">Bar Council of Delhi</option>
                                        <option value="Gujarat">Bar Council of Gujarat</option>
                                        <option value="Himachal Pradesh">Bar Council of Himachal Pradesh</option>
                                        <option value="Jharkhand">Bar Council of Jharkhand</option>
                                        <option value="Karnataka">Bar Council of Karnataka</option>
                                        <option value="Kerala">Bar Council of Kerala</option>
                                        <option value="Madhya Pradesh">Bar Council of Madhya Pradesh</option>
                                        <option value="Maharashtra  Goa9">Bar Council of Maharashtra Goa</option>
                                        <option value="Orissa"> Bar Council of Orissa</option>
                                        <option value="Punjab  Haryana">Bar Council of Punjab Haryana</option>
                                        <option value="Rajasthan">Bar Council of Rajasthan</option>
                                        <option value="Tamil Nadu">Bar Council of Tamil Nadu</option>
                                        <option value="Telangana">Bar Council of Telangana</option>
                                        <option value="Uttar Pradesh">Bar Council of Uttar Pradesh</option>
                                        <option value="Uttrakhand">Bar Council of Uttrakhand</option>
                                        <option value="West Bengal">Bar Council of West Bengal</option>
                                        <option value="Jammu and Kashmir High Court">Jammu Kashmir High Court Bar
                                            Association
                                        </option>
                                        <option value="Chhattisgarh">State Bar Council of Chhattisgarh</option>
                                    </select>
                                    <span class="input__label">Bar Enrollment State<span
                                            class="red">*</span></span>
                                </label>
                            </div>
                        </div>
                    </div>


                    <div class="col-12">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="input amountlabel  field w-100 mt-5">
                                    <input class="amount input__field" type="number" placeholder=" " />
                                    <span class="input__label">Fees Amount <span class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input languagelabel field w-100 mt-5">
                                    <select class="language input__field" type="text" placeholder=" ">
                                        <option value="">Select languages</option>
                                        <option value="english">English</option>
                                        <option value="hindi">Hindi</option>
                                        <option value="urdu">Urdu</option>
                                        <option value="urdu">Assamese</option>
                                        <option value="urdu">Gujarati</option>
                                        <option value="urdu">Kannada</option>
                                        <option value="urdu">Malayalam</option>
                                        <option value="urdu">Marathi</option>
                                        <option value="urdu">Odia</option>
                                        <option value="urdu">Punjabi</option>
                                        <option value="urdu">Tamil</option>
                                        <option value="urdu">telgu</option>
                                    </select>
                                    <span class="input__label">Select languages<span class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input practice_Areas_primarylabel field w-100 mt-5">
                                    <select class="practice_Areas_primary input__field" type="text"
                                        placeholder=" ">
                                        <option value="">Select Practice Areas (primary)</option>
                                        <option value="Arbitration">Arbitration</option>
                                        <option value="Aviation Laws">Aviation Laws</option>
                                        <option value="Banking">Banking</option>
                                        <option value="Civil">Civil</option>
                                        <option value="Company - Registration Compliance">Company - Registration &amp;
                                            Compliance
                                        </option>
                                        <option value="Constitutional">Constitutional</option>
                                        <option value="Consumer">Consumer</option>
                                        <option value="Corporate">Corporate</option>
                                        <option value="Criminal">Criminal</option>
                                        <option value="Cyber Crime">Cyber Crime</option>
                                        <option value="Environment">Environment</option>
                                        <option value="Family">Family</option>
                                        <option value="Immigration">Immigration</option>
                                        <option value="Industrial Relations">Industrial Relations</option>
                                        <option value="International Laws">International Laws</option>
                                        <option value="IPR">IPR</option>
                                        <option value=" Legal Documents - Drafting Vetting"> Legal Documents - Drafting
                                            &amp;
                                            Vetting</option>
                                        <option value="Media Laws">Media Laws</option>
                                        <option value="PIL/RTI/NGO">PIL/RTI/NGO</option>
                                        <option value="Property">Property</option>
                                        <option value="Sports Law">Sports Law</option>
                                        <option value="Taxation">Taxation</option>
                                    </select>
                                    <span class="input__label">Select Practice Areas (primary)<span
                                            class="red">*</span></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="input secondary_practice_arealabel field w-100 mt-5">
                                    <select class="secondary_practice_area input__field" type="text"
                                        placeholder=" ">
                                        <option value="">Select Practice Areas (Secondary)</option>
                                        <option value="Arbitration">Arbitration</option>
                                        <option value="Aviation Laws">Aviation Laws</option>
                                        <option value="Banking">Banking</option>
                                        <option value="Civil">Civil</option>
                                        <option value="Company - Registration Compliance">Company - Registration &amp;
                                            Compliance
                                        </option>
                                        <option value="Constitutional">Constitutional</option>
                                        <option value="Consumer">Consumer</option>
                                        <option value="Corporate">Corporate</option>
                                        <option value="Criminal">Criminal</option>
                                        <option value="Cyber Crime">Cyber Crime</option>
                                        <option value="Environment">Environment</option>
                                        <option value="Family">Family</option>
                                        <option value="Immigration">Immigration</option>
                                        <option value="Industrial Relations">Industrial Relations</option>
                                        <option value="International Laws">International Laws</option>
                                        <option value="IPR">IPR</option>
                                        <option value=" Legal Documents - Drafting Vetting"> Legal Documents - Drafting
                                            &amp;
                                            Vetting</option>
                                        <option value="Media Laws">Media Laws</option>
                                        <option value="PIL/RTI/NGO">PIL/RTI/NGO</option>
                                        <option value="Property">Property</option>
                                        <option value="Sports Law">Sports Law</option>
                                        <option value="Taxation">Taxation</option>
                                    </select>
                                    <span class="input__label">Select Practice Areas (Secondary) <span
                                            class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input practice_statelabel field w-100 mt-5">
                                    <input type="text" id="token" hidden value="@yield('token')">
                                    <select class="practice_state input__field" type="text" placeholder=" ">
                                        <option value="">Practice State</option>
                                        @yield('country')
                                    </select>
                                    <span class="input__label">Practice State<span class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input practice_courtslabel field w-100 mt-5">
                                    <select class="practice_courts input__field" type="text" placeholder=" ">
                                        <option value="">Select Practice Courts</option>
                                        <option value="District Court">District Court</option>
                                        <option value="High Court">High Court</option>
                                        <option value="Subordinate Courts">Subordinate Courts</option>
                                        <option value="Supreme Court">Supreme Court</option>
                                    </select>
                                    <span class="input__label">Select Practice Courts<span
                                            class="red">*</span></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="input field w-100 mt-5">
                                    <select disabled class="country input__field" type="text" placeholder=" ">
                                        <option value="India">India</option>
                                    </select>
                                    <span class="input__label">Country<span class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input statelabel field w-100 mt-5">
                                    <select class="state input__field" type="text" placeholder=" ">
                                        <option value="">Select State</option>
                                        @yield('country')
                                    </select>
                                    <span class="input__label">Select State<span class="red">*</span></span>
                                </label>
                            </div>
                            <div class="col-md-4">
                                <label class="input citylabel field w-100 mt-5">
                                    <select class="city input__field" type="text" placeholder=" ">
                                        <option value="">Select City</option>
                                    </select>
                                    <span class="input__label">Select City<span class="red">*</span></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <label class=" input addresslabel field w-100 mt-5">
                                <input class="address input__field" type="text" placeholder=" " />
                                <span class="input__label">Address <span class="red">*</span></span>
                            </label>
                        </div>
                        <div class="col-md-3">
                            <label class="input pincodelabel field w-100 mt-5">
                                <input class="pincode input__field" type="number" placeholder=" " />
                                <span class="input__label">Pincode <span class="red">*</span></span>
                            </label>
                        </div>

                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-one-back btn btn-primary">Back</button>
                        <button class="step-two-next btn btn-primary">Next</button>
                    </div>
                </div>
            </div>

            <div class="step-three-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>About</h4>
                        <p>Tell us something about yourself</p>
                    </div>
                    <textarea class="abouts" name="" id="" rows="10"></textarea>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-two-back btn btn-primary">Back</button>
                        <button class="step-three-next btn btn-primary">Next</button>
                    </div>
                </div>
            </div>

            <div class="step-for-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Social Media Links</h4>
                        <p>Add your social media details here so we can reach out to you</p>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="facebook input__field" type="text" placeholder=" " />
                            <span class="input__label"><span> <i class="fa fa-facebook"
                                        style="color: #4267B2"></i></span>
                                Facebook </span>
                        </label>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="twitter input__field" type="text" placeholder=" " />
                            <span class="input__label"><span> <i class="fa fa-twitter"
                                        style="color: #00acee"></i></span>
                                Twitter </span>
                        </label>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="linkedin input__field" type="text" placeholder=" " />
                            </span><span class="input__label"><span> <i class="fa fa-linkedin"
                                        style="color:#0077b5"></i></span> Linkedin </span>
                        </label>
                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-three-back btn btn-primary">Back</button>
                        <button class="step-for-next btn btn-primary">Next</button>
                    </div>
                </div>
            </div>

            <div class="step-five-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Publication Areas</h4>
                        <p>Add your publication links here to showcase your work</p>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="publication_areas_1 input__field" type="text" placeholder=" " />
                            <span class="input__label">Publication Areas 1 </span>
                        </label>
                        <small>Enter URL with https:// or http://</small>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="publication_areas_2 input__field" type="text" placeholder=" " />
                            <span class="input__label">Publication Areas 2 </span>
                        </label>
                        <small>Enter URL with https:// or http://</small>
                    </div>
                    <div class="col-md-4">
                        <label class="input field w-100 mb-4">
                            <input class="publication_areas_3 input__field" type="text" placeholder=" " />
                            </span><span class="input__label">Publication Areas 3 </span>

                        </label>
                        <small>Enter URL with https:// or http://</small>
                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-for-back btn btn-primary">Back</button>
                        <button class="step-five-next btn btn-primary">Next</button>
                    </div>
                </div>
            </div>

            <div class="step-six-conn d-none">
                <div class="row shadow m-2 mt-5 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Upload Files</h4>
                        <p>Add your bar council ID Aadhar and Pan Card photo here for us to review</p>
                    </div>
                    <div class="row d-flex justify-content-center">
                        <div style="margin-right:20px;" class="col d-flex flex-column justify-content-center ">
                            {{-- <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i> --}}
                            {{-- <label class=" mb-4"> --}}
                                <input class="barCouncildD" type="file" placeholder=" "  accept="image/png, image/jpg, image/jpeg"/>
                                <span class=""
                                    style="margin-top:13px;background: #0d6efd;width:120px;margin-bottom:13px;padding:10px;color:white;font-size:18px;border-radius:5px;">Counsil Id</span>
                            {{-- </label> --}}
                        </div>
                        <div style="margin-right:20px;" class="col d-flex flex-column justify-content-center mr-5">
                            {{-- <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i> --}}
                            {{-- <label class="input field mb-4"> --}}
                                <input class="aadhar_file " type="file" placeholder=" "  accept="image/png, image/jpg, image/jpeg"/>
                                <span class=""
                                    style="background: #0d6efd;width:137px;margin-top:13px;margin-bottom:13px;padding:10px;color:white;font-size:18px;border-radius:5px;">Aadhar Card</span>
                            {{-- </label> --}}
                        </div>
                        <div style="margin-right:20px;" class="col d-flex flex-column justify-content-center">
                            {{-- <i class="fa fa-download mb-5" style="font-size:100px;margin-left:10px;"></i> --}}
                            {{-- <label class=" mb-4"> --}}
                                <input class="pancard_file " type="file" placeholder=" "  accept="image/png, image/jpg, image/jpeg"/>
                                <span class="" style="margin-top:13px;margin-bottom:13px;background: #0d6efd;width:120px;padding:10px;color:white;font-size:18px;border-radius:5px;">Pan card</span>
                            
                             {{-- </label> --}}
                        </div>
                    </div>
                    
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-five-back btn btn-primary">Back</button>
                        <button class="step-six-next btn btn-primary">Next</button>
                    </div>
                </div>
            </div>

            <div class="step-seven-conn d-none">
                <div class="row shadow m-2 m-sm-3 m-md-3 p-3" style="background: rgb(255, 255, 255)">
                    <div class="col-md-12">
                        <h4>Weekly Plan</h4>
                        <p>The customer will have the option to book 30 mins for the consultancy out of slot 1 or slot 2
                        </p>
                    </div>
                    <div class="plan-list weeklyPlanAll">
                        <ul class="row d-flex flex-row">
                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_mon" value="mon"
                                            class="monday styled-checkbox weeklyPlan" id="mondayPlan">
                                        <label for="mondayPlan">Monday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="mon_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[mon][]" disabled="disabled"
                                                    value="" day="mon" autocomplete="off">
                                                -
                                                <input
                                                    class=" mon_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[mon][]" disabled="disabled"
                                                    value="" day="mon" id="jq_first_half_mon"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="mon_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[mon][]" disabled="disabled"
                                                    value="" day="mon" autocomplete="off">
                                                -
                                                <input
                                                    class="mon_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[mon][]" disabled="disabled"
                                                    value="" day="mon" id="jq_second_half_mon"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_tue" value="tue"
                                            class="tuesday styled-checkbox weeklyPlan" id="tuesdayPlan">
                                        <label for="tuesdayPlan">Tuesday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="tue_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[tue][]" disabled="disabled"
                                                    value="" day="tue" autocomplete="off">

                                                <input
                                                    class="tue_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[tue][]" disabled="disabled"
                                                    value="" day="tue" id="jq_first_half_tue"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="tue_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[tue][]" disabled="disabled"
                                                    value="" day="tue" autocomplete="off">
                                                -
                                                <input
                                                    class="tue_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[tue][]" disabled="disabled"
                                                    value="" day="tue" id="jq_second_half_tue"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_wed" value="wed"
                                            class="wednesday styled-checkbox weeklyPlan" id="wednesdayPlan">
                                        <label for="wednesdayPlan">Wednesday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="wed_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[wed][]" disabled="disabled"
                                                    value="" day="wed" autocomplete="off">
                                                -
                                                <input
                                                    class="wed_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[wed][]" disabled="disabled"
                                                    value="" day="wed" id="jq_first_half_wed"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="wed_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[wed][]" disabled="disabled"
                                                    value="" day="wed" autocomplete="off">
                                                -
                                                <input
                                                    class="wed_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[wed][]" disabled="disabled"
                                                    value="" day="wed" id="jq_second_half_wed"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_thu" value="thu"
                                            class="thursday styled-checkbox weeklyPlan" id="thursdayPlan">
                                        <label for="thursdayPlan">Thursday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="thu_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[thu][]" disabled="disabled"
                                                    value="" day="thu" autocomplete="off">
                                                -
                                                <input
                                                    class="thu_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[thu][]" disabled="disabled"
                                                    value="" day="thu" id="jq_first_half_thu"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="thu_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[thu][]" disabled="disabled"
                                                    value="" day="thu" autocomplete="off">
                                                -
                                                <input
                                                    class="thu_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[thu][]" disabled="disabled"
                                                    value="" day="thu" id="jq_second_half_thu"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_fri" value="fri"
                                            class="friday styled-checkbox weeklyPlan" id="fridayPlan">
                                        <label for="fridayPlan">Friday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="fri_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[fri][]" disabled="disabled"
                                                    value="" day="fri" autocomplete="off">
                                                -
                                                <input
                                                    class="fri_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[fri][]" disabled="disabled"
                                                    value="" day="fri" id="jq_first_half_fri"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="fri_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[fri][]" disabled="disabled"
                                                    value="" day="fri" autocomplete="off">
                                                -
                                                <input
                                                    class="fri_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[fri][]" disabled="disabled"
                                                    value="" day="fri" id="jq_second_half_fri"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_sat" value="sat"
                                            class="saturday styled-checkbox weeklyPlan" id="saturdayPlan">
                                        <label for="saturdayPlan">Saturday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="sat_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sat][]" disabled="disabled"
                                                    value="" day="sat" autocomplete="off">
                                                -
                                                <input
                                                    class="sat_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sat][]" disabled="disabled"
                                                    value="" day="sat" id="jq_first_half_sat"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="sat_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sat][]" disabled="disabled"
                                                    value="" day="sat" autocomplete="off">
                                                -
                                                <input
                                                    class="sat_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sat][]" disabled="disabled"
                                                    value="" day="sat" id="jq_second_half_sat"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="col">
                                <div class="white-box">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="wp_sun" value="sun"
                                            class="sunday styled-checkbox weeklyPlan" id="sundayPlan">
                                        <label for="sundayPlan">Sunday</label>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 1</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="sun_slot_1 form-control suggestion-in-time jq_first_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sun][]" disabled="disabled"
                                                    value="" day="sun" autocomplete="off">
                                                -
                                                <input
                                                    class="sun_slot_1 form-control suggestion-out-time jq_first_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sun][]" disabled="disabled"
                                                    value="" day="sun" id="jq_first_half_sun"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mt-15">
                                        <label>Slot 2</label>

                                        <div class="custom-radio">
                                            <label class="d-flex">
                                                <input
                                                    class="sun_slot_2 form-control suggestion-in-time jq_second_half_from weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sun][]" disabled="disabled"
                                                    value="" day="sun" autocomplete="off">
                                                -
                                                <input
                                                    class="sun_slot_2 form-control suggestion-out-time jq_second_half_to weeklyPlan ui-timepicker-input"
                                                    type="text" name="wp[sun][]" disabled="disabled"
                                                    value="" day="sun" id="jq_second_half_sun"
                                                    autocomplete="off">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>

                    </div>
                    <div class="col-12 d-flex justify-content-between p-5">
                        <div>
                            <input type="checkbox" name="accept_terms_conditions" class="styled-checkbox"
                                id="accept_terms_conditions">
                            <label for="accept_terms_conditions">Accept Terms Conditions
                            </label>
                        </div>

                    </div>
                    <div class="col-12 d-flex justify-content-between p-3">
                        <button class="step-six-back btn btn-primary">Back</button>
                        <button class="form_submit btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>

        </div>

        <div class="d-none row shadow m-2 mt-5 p-3" style="background: #ddd">
            <div>
                <label for="">Enter OTP</label> 
                <input type="number" class="form-control otpveryfy">
            </div>
            <div>
                <button>Submit</button>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript" src="../js/jquery-ui.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/moment.min.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/jquery.timepicker.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/jquery.multiselect.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/jquery.multiselect.filter.js?cache=<?php echo time(); ?>"></script>
<script type="text/javascript" src="../js/jquery-ui.multidatespicker.js?cache=<?php echo time(); ?>"></script>
<script src="js/registerprovider.js?cache=<?php echo time(); ?>"></script>

