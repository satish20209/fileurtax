@php
$res = DB::table('blogs')->where('id', request()->get('id'))->first();
@endphp
<div class="page-wrapper">
    <!-- Page Title -->
    <section class="page-title style-two" style="background-image:url(images/background/1.jpg)">
        <div class="auto-container">
            <h1>Blog Detail</h1>
            <ul class="page-breadcrumb">
                <li><a href="/">home</a></li>
                <li>Blog Detail</li>
            </ul>
        </div>
    </section>
    <!-- End Page Title -->

    <!-- Sidebar Page Container -->
    <div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">

                <!-- Content Side -->
                <div class="content-side col-lg-8 col-md-12 col-sm-12">
                    <!-- Block Detail -->
                    <div class="blog-detail">
                        <div class="inner-box">
                            <div class="image">
                                <img src="/fileurtax/blogs/{{$res->thumbnail}}" alt="blog" />
                                <div class="category">Business</div>
                                <ul class="post-meta">
                                    <li><span class="icon flaticon-timetable"></span>{{$res->created_at}}</li>
                                    <li><span class="icon flaticon-email"></span>Comments</li>
                                    <li><span class="icon flaticon-user-2"></span>Admin</li>
                                </ul>
                            </div>
                            <div class="lower-content">
                                <h3>{{ $res->blogName }}</h3>
                                <?php echo $res->content?>
                                {{-- <div class="two-column">
                                    <div class="row clearfix">
                                        <!-- Column -->
                                        <div class="column col-lg-6 col-md-6 col-sm-12">
                                            <div class="image">
                                                <img src="images/resource/news-19.jpg" alt="" />
                                            </div>
                                        </div>
                                        <!-- Column -->
                                        <div class="column col-lg-6 col-md-6 col-sm-12">
                                            <p>It is a long established fact that a reader will be distracted by the
                                                readable content of a page when looking at its layout. The point of
                                                using Lorem Ipsum is that it has a more-or-less normal distribution of
                                                letters, as opposed to using 'Content here, content here', making it
                                                look like readable English.</p>
                                            <p>Many desktop publishing packages and web page editors now use Lorem Ipsum
                                                as their default model text, and a search for 'lorem ipsum' will uncover
                                                many web sites still in their infancy. Various versions have evolved
                                                over the years, sometimes by accident.</p>
                                        </div>
                                    </div>
                                </div> --}}

                                <!-- Post Share Options-->
                                <div class="post-share-options">
                                    <div class="post-share-inner clearfix">
                                        <div class="pull-left tags">TAGS: <a href="#">Business,</a> <a href="#">Law,</a><a href="#">Technology</a></div>
                                        <div class="tags pull-right">
                                            <div class="business">Category: <a href="#">Business,</a> <a href="#">Online Law</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Blog Author Box -->
                            <div class="blog-author-box">
                                <div class="author-inner">
                                    <div class="thumb"><img src="images/logo-cmp.png" alt=""></div>
                                    <h4 class="name">FILEURTAX</h4>
                                    <div class="text">We provide services to help the budding entrepreneurs get the legal and regulatory support that they need so that their business remains compliant and grows exponentially.</div>
                                    <ul class="social-icon clearfix">
                                        <li><a href="https://www.facebook.com/Fileurtax-106473432117319" target="_blank"><i class="fa fa-facebook-f"></i></a></li>
                                        <li><a href="https://www.youtube.com/channel/UCxthofo_PTYSelm-Gwju4pA/about"><i class="fa fa-youtube"></i></a></li>
                                        <li><a href="https://twitter.com/fileurtax" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="https://www.instagram.com/fileurtax/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="https://www.linkedin.com/company/fileurtax/"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="comments-area">
                            @php
                                $coomets = DB::table('blogcoments')->where('blogId',request()->get('id'))->get();
                                $tmp = "";
                                if (count($coomets) > 0) {
                                    $tmp = count($coomets);
                                }
                            @endphp
                            
                            <div class="group-title">
                                <h5>{{ $tmp }} Comments</h5>
                            </div>
                            @foreach ($coomets as $comt)
                            <div class="comment-box">
                                <div class="comment">
                                    <div class="author-thumb"><img src="images/guest-user.png" alt="guest user" style="width: 100px">
                                    </div>
                                    <div class="comment-info clearfix"><strong>{{$comt->fname}}</strong>

                                        <div class="comment-time">{{$comt->created_at}}</div>
                                    </div>
                                    <div class="text">{{$comt->message}}</div>
                                </div>
                            </div>
                            @endforeach
                            
                        </div>


                        <!-- Comment Form -->
                        <div class="comment-form">

                            <div class="group-title">
                                <h5>LEAVE A COMMENT</h5>
                            </div>

                            <!--Comment Form-->
                            <form method="post" action="comments">
                                @csrf
                                <div class="row clearfix">
                                    <input type="hidden" name="blogId" value="{{request()->get('id')}}">
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input type="text" name="fname" placeholder="Full Name" required="">
                                    </div>
                                    




                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                                        <input type="email" name="email" placeholder="Email" required="">
                                    </div>

                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <textarea class="" name="message" placeholder="Your Message"></textarea>
                                    </div>

                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        <button class="theme-btn btn-style-three" type="submit"
                                            name="submit-form"><span class="txt">Send now</span></button>
                                    </div>

                                </div>
                            </form>

                        </div>


                    </div>
                </div>

                <!-- Sidebar Side -->
                <div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
                    <aside class="sidebar sticky-top">
                        <div class="sidebar-inner">

                            <!-- Search -->
                            <div class="sidebar-widget search-box">
                                <form>
                                    <div class="form-group">
                                        <input type="search" name="search-field" value=""
                                            placeholder="Search ....." required>
                                        <button type="button"><span class="icon fa fa-search"></span></button>
                                    </div>
                                </form>
                            </div>

                            <!--Blog Category Widget-->
                            <div class="sidebar-widget sidebar-blog-category">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>Categories</h5>
                                    </div>
                                    <ul class="cat-list-two">
                                        <li><a href="#">Consulting <span>(0)</span></a></li>
                                        <li><a href="#">Life Style<span>(0)</span></a></li>
                                        <li><a href="#">Technology<span>(0)</span></a></li>
                                    </ul>
                                </div>
                            </div>

                            <!-- Popular Post Widget -->
                            <div class="sidebar-widget popular-posts">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>latest posts</h5>
                                    </div>
                                    @php
                                    $latest = DB::table('blogs')->orderBy('id','desc')->limit(3)->get();
                                    
                                    @endphp
                                    @foreach ( $latest as $lts)
                                    <article class="post">
                                        <figure class="post-thumb"><img src="/fileurtax/blogs/{{$lts->thumbnail}}" alt=""><a href="read_blog?id={{$lts->id}}" class="overlay-box"></a>
                                        </figure>
                                        <div class="text"><a href="read_blog?id={{$lts->id}}">{{$lts->title}}</a></div>
                                        <div class="post-info">{{$lts->created_at}}</div>
                                    </article>
                                    @endforeach
                                    

                                    
                                </div>
                            </div>

                            <!-- Tags Widget -->
                            {{-- <div class="sidebar-widget popular-tags">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>Tags</h5>
                                    </div>
                                    <a href="#">Cloud</a>
                                    <a href="#">Life style</a>
                                    <a href="#">Hosting</a>
                                    <a href="#">Business</a>
                                </div>
                            </div> --}}

                        </div>
                    </aside>
                </div>

            </div>
        </div>
    </div>
</div>
<!--End pagewrapper-->
