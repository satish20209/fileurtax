<div>
    <section class="page-title" style="background-image:url(images/background/1.jpg)">
        <div class="auto-container">
            <h1>WHY CHOOSE US</h1>
            <ul class="page-breadcrumb">
                <li><a href="/">Home</a></li>
                <li>WHY CHOOSE US</li>
            </ul>
        </div>
    </section>
    <div class="sec-title centered mt-5">
        <h2>WHY CHOOSE US</h2>
    </div>
    <div class="p-3">
        <div class="row">
            <div class="col-1"> </div>
            <div class="col-md-5 col-12">
                <img src="images/ourprocess/whychooseus.png" alt="">
            </div>
            <div class="col-md-5 col-12">
                <p>We are a company who take cares of your fillings and legal part. When you are doing business you
                    focus on that as when you are linked with us then nothing to worry about accounting and legality
                    part .it will be manage by us. We provide services to client who was not even aware how much
                    government schemes can help them which we make them understand and implement for them as well in
                    there file. All legal cases we manage for the company so that they do not face any challenges in
                    there business. We always make sure that client gets all benefits of taxation and we should pass
                    them whenever required. Are services and unique which are all covered under one roof so client don't
                    have to deal with different vendors as all services are provided by us to door step. We have high
                    technology which can always keep client updated for their company tax , audit ,compliance and legal
                    part. We implement all client requirements so that he can do their business easily without
                    hesitation and freely.we always focus on delivery on time so no penalty is imposed.we always try to
                    understand clients need and requirements and according to that we give them the best suggestion with
                    easy price..</p>
            </div>
            <div class="col-1"> </div>
        </div>
    </div>
</div>
