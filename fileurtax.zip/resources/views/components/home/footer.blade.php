<div>
  <!-- Main Footer -->
  <footer class="main-footer">
   <div class="auto-container">
        <!-- Widgets Section -->
         <div class="widgets-section">
         <!-- Scroll To Top -->
         <div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>
            <div class="row clearfix">
                
                 <!-- Big Column -->
                 <div class="big-column col-lg-6 col-md-12 col-sm-12">
                     <div class="row clearfix">
                  
                  <!--Footer Column-->
                         <div class="footer-column col-lg-7 col-md-6 col-sm-12">
                             <div class="footer-widget logo-widget">
                        <div class="logo">
                                    <a href="/"><img src="images/logo.png" alt="fileurtax logo" style="width: 150px;" /></a>
                                 </div>
                        <div class="text">FileUrTax is an all-in-1 solution for Individuals or Entrepreneurs or Businesses looking for Lawyers, Cost Management Accountants (CMA), Company Secretaries (CS), or Chartered Accountants for their various needs.</div>
                        <!-- Social Nav -->
                        <ul class="social-nav">
                           <li class="facebook "><a href="https://www.facebook.com/Fileurtax-106473432117319" class="bg-white" target="_blank"><span class="fa fa-facebook-f  text-primary"></span></a></li>
                           <li class="twitter"><a href="https://twitter.com/fileurtax" target="_blank" class="bg-white" ><span class="fa fa-twitter text-primary"></span></a></li>
                           <li class="linkedin"><a href="https://www.linkedin.com/company/fileurtax/" class="bg-white" target="_blank"><span class="fa fa-linkedin text-primary"></span></a></li>
                           <li class="linkedin"><a href="https://www.youtube.com/channel/UCxthofo_PTYSelm-Gwju4pA/about" class="bg-white" target="_blank"><span class="fa fa-youtube text-danger"></span></a></li>
                           <li class="linkedin"><a href="https://www.instagram.com/fileurtax/" target="_blank" class="bg-white"><span class="fa fa-instagram text-danger"></span></a></li>
                        </ul>
                     </div>
                  </div>
                  
                  <!--Footer Column-->
                         <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                             <div class="footer-widget links-widget">
                        <h5>Services</h5>
                        <ul class="footer-list">
                           <li><a href="charteredaccountant">Chartered Accountant</a></li>
                           <li><a href="costmanagementaccountant">Cost Management Accountant</a></li>
                           <li><a href="companysecretary">Company Secretary</a></li>
                           <li><a href="legalservices">Legal Services</a></li>
                           <li><a href="investment">Investment</a></li>
                           <li><a href="loan">Loan</a></li>
                           <li><a href="personalfinance">Personal Finance</a></li>
                        </ul>
                     </div>
                  </div>
                  
               </div>
            </div>
            
            <!-- Big Column -->
                 <div class="big-column col-lg-6 col-md-12 col-sm-12">
                     <div class="row clearfix">
                  
                  <!-- Footer Column -->
                  <div class="footer-column col-lg-5 col-md-6 col-sm-12">
                     <div class="footer-widget links-widget">
                        <h5>NAVIGATION</h5>
                        <ul class="footer-list">
                           <li><a href="/">Home</a></li>
                           <li><a href="aboutus">About Us</a></li>
                           <li><a href="contact">Contact Us</a></li>
                           <li><a href="quotation">Quotation</a></li>
                           <li><a href="packages">Packages</a></li>
                           <li><a href="disclaimer">Disclaimer</a></li>
                           <li><a href="termsandconditions">Terms and Conditions</a></li>
                           <li><a href="privacypolicy">Privacy Policy</a></li>
                        </ul>
             </div>
          </div>
                  
                  <!-- Footer Column -->
                  <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                     <div class="footer-widget contact-widget">
                        <h5>CONTACT US</h5>
                        <ul>
                           <li>
                              <span class="icon flaticon-call-1"></span>
                              <a href="tel:+9183359 35735">(+91) 8335935735</a>
                           </li>
                           <li>
                              <span class="icon flaticon-email-2"></span>
                              <a href="mailto:info@fileurtax.com">info@fileurtax.com</a>
                           </li>
                           <li>
                              <span class="icon flaticon-maps-and-flags"></span>
                              24/8A Manujendra Dutta Road, Kolkata 700 028 West Bengal , India
                           </li>
                           <li>
                              <span class="icon fa fa-card"></span>
                              <img src="images/card.png" alt="">
                           </li>
                        </ul>
                     </div>
                  </div> 
               </div>
            </div>
            
         </div>
      </div>
   </div>
   <div class="footer-bottom m-0 p-0">
      
         <footer class=" text-light p-0 m-0" style="background: #0644a1">
            <div class="p-3">
                <h5 class="firstRow mb-3 text-center">All Right Reserved. Developed by <span><a href="https://shivila.com/" style="color:rgb(240, 161, 3)" target="_blank"><b></b>Shivila Technologies</b></a></span></h5>
        
                <h6 class="secondRow text-center">Copyright © 2022 Shivila Technologies Private Limited. Use of our Products/Services is
                    governed by our Privacy Policy.</h6>
            </div>
        </footer>
      
   </div>
</footer>
</div>

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
    integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
<!-- JS -->


<script src="js/jquery.mCustomScrollbar.concat.min.js?cache=<?php echo time(); ?>"></script>
<script src="js/jquery.fancybox.js?cache=<?php echo time(); ?>"></script>
<script src="js/appear.js?cache=<?php echo time(); ?>"></script>
<script src="js/parallax.min.js?cache=<?php echo time(); ?>"></script>
<script src="js/tilt.jquery.min.js?cache=<?php echo time(); ?>"></script>
<script src="js/jquery.paroller.min.js?cache=<?php echo time(); ?>"></script>
<script src="js/owl.js?cache=<?php echo time(); ?>"></script>
<script src="js/wow.js?cache=<?php echo time(); ?>"></script>
<script src="js/nav-tool.js?cache=<?php echo time(); ?>"></script>
{{-- <script src="js/jquery-ui.js?cache="></script> --}}
<script src="js/script.js?cache=<?php echo time(); ?>"></script>
<script src="js/blog.js?cache=<?php echo time(); ?>"></script>
<script src="js/custom.js?cache=<?php echo time(); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
@yield('customjs')

<script>
   
$(document).ready(function(){
   toastr.options.timeOut = 10000;
   @if (Session::has('error'))
         toastr.error('{{ Session::get('error') }}');
   @elseif(Session::has('success'))
         toastr.success('{{ Session::get('success') }}');
   @endif
});
</script>
</body>
</html>