<div class="">

    <!-- Page Title -->
    <section class="page-title" style="background-image:url(images/background/1.jpg)">
        <div class="auto-container">
            <h1>MESSAGE FROM THE CEO</h1>
            <ul class="page-breadcrumb">
                <li><a href="/">Home</a></li>
                <li>MESSAGE FROM THE CEO</li>
            </ul>
        </div>
    </section>

    <div class="text-center p-3 container">
        <img src="images/ceo.jpg" alt="" class="border border-2 border-primary rounded-circle">
        <h3 class="text-primary mt-2" style="font-weight: 600">AMIT DUBEY</h3>
        <h6 style="font-weight: 600;color:black">Global Group Director</h6>
        <h2 class="mt-5" style="font-weight: 600;color:black"> MESSAGE <span class="text-primary">FROM THE CEO</span> </h2>
        <p class="p-3">
            2021 has come to an end. The year has been a roller-coaster ride for many of us, as we have witnessed the
            second wave of the Coronavirus and in the early phase of the year. It took us time to recover from the shock
            and return to our everyday lives. But as said, “All is well that ends well.” The end of 2021 has signaled
            that maybe everything will return to normal in few months, if not days, and we will be able to lead our
            lives just as we used to. Technology has been one of our most trusted allies in these challenging times. It
            has brought us closer and made it possible to continue with our work while taking precautions. It has acted
            as a bridge that connects different people and devices worldwide, giving us the notion that we are all
            together in these difficult times. It has kept the world up and functioning. At Fileurtax, we
            have tried our best to incorporate new and comprehensive technologies that are simple and easy to understand
            and can help our employees and partners to remain safe and work from the safety of their homes. We want that
            the services provided by us should not only help our partners to grow but also assist them in exploring new
            avenues of opportunities. With these thoughts in mind, we wish each one of you a happy and prosperous year
            2022.
        </p>
    </div>
</div>
