

<div>
   	<!-- Page Title -->
       <section class="page-title" style="background-image:url(images/background/1.jpg)">
    	<div class="auto-container">
			<h1>About Us</h1>
			<ul class="page-breadcrumb">
				<li><a href="/">Home</a></li>
				<li>About</li>
			</ul>
        </div>
    </section>
    <!-- End Page Title -->
	
	<!-- Case Section -->
	<section class="case-section">
		<div class="auto-container">
			<div class="inner-container">
				<div class="clearfix">
					
					<!-- Image Column -->
					<div class="image-column col-lg-6 col-md-12 col-sm-12">
						<div class="inner-column">
							<div class="image wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
								<img src="images/resource/case-1.jpg" alt="case" />
							</div>
						</div>
					</div>
					
					<!-- Content Column -->
					<div class="content-column col-lg-6 col-md-12 col-sm-12">
						<div class="inner-column">
							<!-- Sec Title -->
							<div class="sec-title">
								<h2>Providing curated services at an affordable rate</h2>
								<h3>Get legal solutions for a wide range of issues at affordable rates.</h3>
							</div>
							<div class="text-box">
									<p>FileUrTax is an all-in-1 solution for Individuals or Entrepreneurs or Businesses looking for Lawyers, Cost Management Accountants (CMA), Company Secretaries (CS), or Chartered Accountants for their various needs. We try to ensure that the startups are fully compliant with India’s legal system. We are an internet based compliance services platform dedicated to helping people file tax, start and grow their businesses etc, by consulting Experts at an affordable pricing.</p>
									<p>We provide services to help the budding entrepreneurs get the legal and regulatory support that they need so that their business remains compliant and grows exponentially.</p>
									<p>The depth of our offerings coupled with reliable connections at affordable prices makes us one of the most trusted partners for an emerging business.</p>
									<p>Please note that we are a facilitating platform and not a law firm and we do not provide legal / other services ourselves.</p>
								
								
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<!-- End Welcome Section -->
	
	<!-- Services Section Two -->
	<section class="services-section-two style-two">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<h2>What Make Us Unique</h2>
			</div>
			<div class="row clearfix">
				
				<!-- Services Block Two -->
				<div class="services-block-two col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-auction"></div>
						<h5><a href="/">Legal Services</a></h5>
						<div class="text">A legal content writer will be able to explain complex legal matters to readers, which will help strengthen the connection between.</div>
						<a class="arrow flaticon-right-arrow-3" href="/"></a>
					</div>
				</div>
				
				<!-- Services Block Two -->
				<div class="services-block-two col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-law"></div>
						<h5><a href="/">Great Results</a></h5>
						<div class="text">Our Bankruptcy Case Expert Lawyer Helped Many Client from Long term Legal Processes.</div>
						<a class="arrow flaticon-right-arrow-3" href="/"></a>
					</div>
				</div>
				
				<!-- Services Block Two -->
				<div class="services-block-two col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-marketing"></div>
						<h5><a href="/">Passionate People</a></h5>
						<div class="text">We Have Huge Number of Success Stories of Wining Against Large Numbers of Banking Fraud Cases.</div>
						<a class="arrow flaticon-right-arrow-3" href="/"></a>
					</div>
				</div>
				
			</div>
		</div>
	</section>
	<!-- End Services Section Two -->	
</div>