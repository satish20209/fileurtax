@php
    if(!session('customerAuth')){
        echo "<script>alert('Please login first'); window.location.href = '/login'; </script>";
        if (!session()->has('check_quotation')) {
            $session=session()->put('check_quotation',time());
        }
    }
@endphp


<div>
    <!-- Page Title -->
  <section class="page-title" style="background-image:url(images/background/1.jpg)">
    <div class="auto-container">
        <h1>QUOTATION</h1>
        <ul class="page-breadcrumb">
        <li><a href="/">Home</a></li>
        <li>Quotation</li>
        </ul>
      </div>
  </section>
  <!-- End Page Title -->

  <link rel="icon" type="image/x-icon" href="{{ asset('images/favicon.ico') }}">
<div class="p-2 p-md-5">
    <div class="text-center mt-4 mb-5">{{--hedding-all--}}
        <h1 class="hedding-all-page">Place your request for a service quotation with us.</h1>
        <h5>Ask or request for service quotation and get answers to your query</h5>
    </div>
    <div class="d-flex justify-content-center ">
        <div class="main-con-ask ">
            <div class="p-2 p-md-5 shadow mb-4 text-white shadow shadow-lg contact-form-section">
                <form action="/quotation_form" method="POST">
                    @if (session('successMessage'))
                        <div class="alert alert-success close">
                            {{ session('successMessage') }}
                        </div>
                    @elseif(session('faildMessae'))
                        <div class="alert alert-danger">
                            {{ session('faildMessae') }}
                        </div>
                    @endif
                    @php
                        Session::forget('successMessage');
                        Session::forget('faildMessae');
                    @endphp
                    @csrf
                    @php
                        $customer = DB::table('members')
                        ->where('email',session('customerAuth'))
                        ->first();
                        if (session()->has('customerAuth')) {
                            $fname = $customer->fname;
                            $email = $customer->email;
                            $mobile = $customer->mobile;
                            $disabled = 'disabled';
                        }else {
                            $fname = '';
                            $email = '';
                            $mobile = '';
                            $disabled = '';
                        }

                    @endphp
                    <div class="col-12  mb-3">
                        <label for="name">Name</label>
                        <input type="text"  {{$disabled}} name="name" placeholder="Enter Name"
                            id="name" value="{{$fname}}">
                    </div>
                    <div class="col-12  mb-3">
                        <label for="mobile">Mobile Phone Number</label>
                        <input type="text"  required name="mobile" placeholder="Mobile Phone Number"
                            id="mobile" value="{{$mobile}}" {{$disabled}}>
                    </div>
                    <div class="col-12  mb-3">
                        <label for="email">Email Id</label>
                        <input type="email"  required name="email" placeholder="Enter Email Id"
                            id="email" value="{{$email}}" {{$disabled}}>
                    </div>
                    <div class="col-12  mb-3">
                        <label for="mobile">Services</label>
                        <select  required name="services">
                            @php
                            $CheckRole=DB::table('members')->where('email',session('customerAuth'))->first('id');
                            if(!$CheckRole==NULL){
                                $chk_service=DB::table('customer_requirements')->where('user_id',$CheckRole->id)->first('parent_service');
                            
                            
                                $temparr=['L'=>'Lawyer','CA'=>'Chartered Accountant','CS'=>'Company Secretary',
                                'CMA'=>'Cost Management Accountant']; 
                                foreach($temparr as $key=>$val)
                                    if($key==$chk_service->parent_service){
                                        echo '<option selected="selected" value="'.$key.'">'.$val.'</option>';
                                    } 
                            }
                            @endphp
                        </select>
                    </div>
                    <div class="col-12 mb-3">
                        <label for="mobile">Expected Quotation Amount</label>
                        <select name="" id="quotation_price" id="price">
                            <option value="99">99</option>
                            <option value="999">999</option>
                            <option value="1999">1999</option>
                            <option value="2999">2999</option>
                            <option value="9999">9999</option>
                        </select>
                        {{-- <input type="number"  required name="" placeholder="Expected Quotation Amount" > --}}
                    </div>
                    <div class="col-12 mb-3">
                        <label for="pwd">Message</label>
                        <textarea rows="3" name="message" required maxlength="150" minlength="20"> </textarea>
                    </div>
                    <div class="col-12 mb-3">
                        @if (session()->has('customerAuth'))
                        <button type="submit" class="theme-btn btn-style-two mt-3 text-white">Submit</button>
                    @else
                        {{-- <p class="text-danger">To Make A Quotation Please <a href="signup" class="btn btn-primary btn-sm">Register</a> First</p> --}}
                        <a href="signin" class="text-white"><button type="button" class="theme-btn btn-style-two mt-3 ">SUBMIT</button></a>
                    @endif
                    </div>
                   
                    
                </form>
            </div>
        </div>


    </div>
</div>
</div>

<script>
    $("#price").on("keypress",function(e){
        var $this = $(this);
        var regex = new RegExp("^[0-9\b]+$");
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        // for 10 digit number only
        if ($this.val().length > 5) {
        
        return false;
        }
        else if (e.charCode < 54 && e.charCode > 47) {
        if ($this.val().length == 0) {
            // warning for validate mobile number
            e.preventDefault();
            return false;

        } else {
            return true;
        }

        }
        else if (regex.test(str)) {
        return true;
        }
        e.preventDefault();
        return false;
    })
</script>