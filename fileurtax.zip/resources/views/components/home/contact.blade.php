
<div>
    	<!-- Page Title -->
        <section class="page-title" style="background-image:url(images/background/1.jpg)">
            <div class="auto-container">
                <h1>Contact Us</h1>
                <ul class="page-breadcrumb">
                    <li><a href="/">home</a></li>
                    <li>Contact Us</li>
                </ul>
            </div>
        </section>
        <!-- End Page Title -->
        
        <!-- Map Section -->
        <section class="map-section mb-5">
            <div class="auto-container">
                <div class="inner-container">
                    <!-- Map Boxed -->
                    <div class="map-boxed">
                        <!-- Map Outer -->
                        <div class="map-outer">
                                    <!-- Contact Form Section -->
                            <section class="contact-form-section ">
                                <div class="auto-container">
                                    <!-- Sec Title -->
                                    <div class="sec-title centered">
                                        <h2>Send us a message</h2>
                                    </div>
                                    <!-- Contact Form -->
                                    <div class="contact-form">
                                        
                                        <!--Contact Form-->
                                        <form action="/contactus_form" id="contact-form" name="forms">
                                            <div class="row clearfix">
                                                <div class="col-lg-12 col-md-12 col-sm-12 form-group text-center">
                                                    @if (session('successMessage'))
                                                        <div class="alert alert-success">
                                                            {{ session('successMessage')}}
                                                        </div>
                                                        @elseif (session("faildMessae"))
                                                    <div class="alert alert-danger">
                                                        {{ session('faildMessae') }}
                                                    </div>
                                                        @endif
                                                        
                                                        @php
                                                            Session::forget('successMessage');
                                                            Session::forget('faildMessae');
                                                        @endphp
                                                </div>
                                                <div class="col-lg-4 col-md-6 col-sm-12 form-group">
                                                    <input type="text" required name="name" onkeypress="return onlyAlphabetstwo()" placeholder="Enter Name" id="name">
                                                </div>
                                                
                                                <div class="col-lg-4 col-md-12 col-sm-12 form-group">
                                                    <input type="text" required name="mobile" placeholder="Enter Mobile Number Without +91" id="mobile" class="mobile">
                                                </div>

                                                <div class="col-lg-4 col-md-6 col-sm-12 form-group">
                                                    <input type="email" required name="email" placeholder="Enter email" id="email">
                                                </div>
                                                
                                                
                                                
                                                <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                                    <textarea name="message" required placeholder="Message" maxlength="200" minlength="20"></textarea>
                                                </div>
                                                
                                                <div class="col-lg-12 col-md-12 col-sm-12 form-group text-center">
                                                    <button class="theme-btn btn-style-two" type="submit"><span class="txt">Send Message<i class="arrow flaticon-right"></i></span></button>
                                                </div>
                                                
                                                
                                            </div>
                                        </form>
                                        
                                        <!--End Contact Form -->
                                    </div>
                                </div>
                            </section>
                            <!-- End Contact Form Section -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Map Section -->
        

        
        <!-- Contact Info Section -->
        <section class="contact-info-section">
            <div class="auto-container">
                <!-- Sec Title -->
                <div class="sec-title centered">
                    <h2>Our Infromation</h2>
                </div>
                <div class="row clearfix">
                
                    <!-- Info Block -->
                    <div class="info-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon flaticon-location-pin"></div>
                            <h5>Location</h5>
                            <div class="text">24/8A Manujendra Dutta Road, Kolkata700 028 West Bengal , India</div>
                        </div>
                    </div>
                    
                    <!-- Info Block -->
                    <div class="info-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon flaticon-smartphone"></div>
                            <h5>Phone</h5>
                            <ul class="info-list">
                                <li><a href="tel:+9183359 35735">(+91) 8335935735</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    
                    <!-- Info Block -->
                    <div class="info-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="icon flaticon-email-3"></div>
                            <h5>Email</h5>
                            <ul class="info-list">
                                <li><a href="mailto:info@fileurtax.com">info@fileurtax.com</a></li>
                                
                            </ul>
                        </div>
                    </div>
                
                </div>
            </div>
        </section>
</div>

<script>
    $('.mobile').on('keypress', function(e) {
        var $this = $(this);
        var regex = new RegExp("^[0-9\b]+$");
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        // for 10 digit number only
        if ($this.val().length > 9) {
            e.preventDefault();
            return false;
        }
        if (e.charCode < 54 && e.charCode > 47) {
            if ($this.val().length == 0) {
                // warning for validate mobile number
                e.preventDefault();
                return false;
            } else {
                return true;
            }

        }
        if (regex.test(str)) {
            return true;
        }
        e.preventDefault();
        return false;
    });

    $("#email").on("change",function(){
        var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        if(!this.value.match(regex)){
            alert("enter valid email id")
            $("#email").val("");
        }
        });
        function onlyAlphabetstwo() {
            var regex = /^[a-zA-Z]*$/;
            if (regex.test(document.forms.name.value)) {

                //document.getElementById("notification").innerHTML = "Watching.. Everything is Alphabet now";
                return true;
            } else {
                alert("only Text allowed")
                return false;
            }
            } 

            $("#mobile").on("keypress",function(e){
                var $this = $(this);
                var regex = new RegExp("^[0-9\b]+$");
                var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
                // for 10 digit number only
                if ($this.val().length > 9) {
                
                return false;
                }
                else if (e.charCode < 54 && e.charCode > 47) {
                if ($this.val().length == 0) {
                    // warning for validate mobile number
                    e.preventDefault();
                    return false;
                } else {
                    return true;
                }

                }
                else if (regex.test(str)) {
                return true;
                }
                e.preventDefault();
                return false;
            })
</script>