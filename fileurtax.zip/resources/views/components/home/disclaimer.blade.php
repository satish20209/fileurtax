
<div>

    <!-- Page Title -->
  <section class="page-title" style="background-image:url(images/background/1.jpg)">
    <div class="auto-container">
    <h1>DISCLAIMER</h1>
    <ul class="page-breadcrumb">
      <li><a href="/">Home</a></li>
      <li>Disclaimer</li>
    </ul>
      </div>
  </section>
  <!-- End Page Title -->
  
  <div class="p-5 mb-2 mt-2">
    <h1>Disclaimer</h1>
  <p>The Information available on this Website by Fileurtax is subject to this Disclaimer and Terms and Conditions. This Disclaimer governs the usage of this Website. When accessing this Website, you agree to the Terms and Conditions and this Disclaimer. If you disagree, please do not access this Website. We reserve the right to modify the Terms and Conditions and Disclaimer as our preference without prior notice. When required, we post the revised version on both the Terms and Conditions and Disclaimer on this Website. If you use the Website after those changes, you agree to accept those changes irrespective of whether you have reviewed those modifications.</p>
  </div>
</div>
