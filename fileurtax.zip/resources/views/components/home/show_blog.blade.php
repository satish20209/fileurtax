
<div class="page-wrapper">	
	<!-- Page Title -->
    <section class="page-title style-two" style="background-image:url(images/background/1.jpg)">
    	<div class="auto-container">
			<h1>Our Blog</h1>
			<ul class="page-breadcrumb">
				<li><a href="/">Home</a></li>
				<li>Blog</li>
			</ul>
        </div>
    </section>
    <!-- End Page Title -->
	
	<!-- Sidebar Page Container -->
    <div class="sidebar-page-container">
    	<div class="auto-container">
        	<div class="row clearfix">
				
				<!-- Content Side -->
                <div class="content-side col-lg-8 col-md-12 col-sm-12">
                	<div class="blog-classic">
						@php
						$blogs=DB::table('blogs')->paginate(2);
						// print_r($blogs);
						@endphp
						@foreach($blogs as $blog)					
						<!-- News Block -->
						<div class="news-block"  blogId="{{$blog->id}}">
							<div class="inner-box">
								<div class="image">
									<a href="read_blog?id={{$blog->id}}" target="_blank"><img src="/fileurtax/blogs/{{$blog->thumbnail}}" alt="blog image" /></a>
									<div class="category">Business</div>
									<ul class="post-meta">
										<li><a href="read_blog?id={{$blog->id}}"><span class="icon flaticon-timetable"></span>{{$blog->created_at}}</a></li>
										<li><a href="read_blog?id={{$blog->id}}"><span class="icon flaticon-email"></span>Comments 03</a></li>
										<li><a href="read_blog?id={{$blog->id}}"><span class="icon flaticon-user-2"></span>Admin</a></li>
									</ul>
								</div>
								<div class="lower-content">
									<h3><a href="read_blog?id={{$blog->id}}">{{$blog->blogName}}</a></h3>
									<div class="text"></div>
									<div class="btn-box">
										<a href="read_blog?id={{$blog->id}}" class="theme-btn btn-style-two"><span class="txt">Learn More</span></a>
									</div>
								</div>
							</div>
						</div>

						
						@endforeach
						<!--end News Block -->
					</div>
					
					<!--Post Share Options-->
					<div class="text-center">
						<div class="d-flex justify-content-center">
							{{ $blogs->links() }}
						</div>
						
					</div>
					
				</div>
				
				<!-- Sidebar Side -->
                <div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
                	<aside class="sidebar sticky-top">
						<div class="sidebar-inner">
						
							<!-- Search -->
							<div class="sidebar-widget search-box">
								<form method="post">
									<div class="form-group">
										<input type="search" name="search-field" value="" placeholder="Search ....." required>
										<button type="button"><span class="icon fa fa-search"></span></button>
									</div>
								</form>
							</div>
							
							<!--Blog Category Widget-->
							<div class="sidebar-widget sidebar-blog-category">
								<div class="widget-content">
									<div class="sidebar-title">
										<h5>Categories</h5>
									</div>
									<ul class="cat-list-two">
										<li><a href="#">Consulting <span>(0)</span></a></li>
										<li><a href="#">Life Style<span>(0)</span></a></li>
										<li><a href="#">Technology<span>(0)</span></a></li>
									</ul>
								</div>
							</div>
							
							<!-- Popular Post Widget -->
							<div class="sidebar-widget popular-posts">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>latest posts</h5>
                                    </div>
                                    @php
                                    $latest = DB::table('blogs')->orderBy('id','desc')->limit(3)->get();
                                    
                                    @endphp
                                    @foreach ( $latest as $lts)
                                    <article class="post">
                                        <figure class="post-thumb"><img src="/fileurtax/blogs/{{$lts->thumbnail}}" alt=""><a href="read_blog?id={{$lts->id}}" class="overlay-box"></a>
                                        </figure>
                                        <div class="text"><a href="read_blog?id={{$lts->id}}">{{$lts->title}}</a></div>
                                        <div class="post-info">{{$lts->created_at}}</div>
                                    </article>
                                    @endforeach
                                </div>
                            </div>
							
							<!-- Tags Widget -->
							{{-- <div class="sidebar-widget popular-tags">
								<div class="widget-content">
									<div class="sidebar-title">
										<h5>Tags</h5>
									</div>
									<a href="#">Cloud</a>
									<a href="#">Life style</a>
									<a href="#">Hosting</a>
									<a href="#">Business</a>
								</div>
							</div> --}}
							
						</div>
					</aside>
				</div>
				
			</div>
		</div>
	</div>
</div>
<!--End pagewrapper-->