<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="csrf-token" content="{{ csrf_token() }}" >
    <meta name="description" content="@yield('description')">
    <meta name="keywords" content="@yield('keywords')" >
    
    <link rel="icon" type="image/x-icon" href="{{ asset('images/favicon.ico') }}">
    <title>@yield('title')</title>
    <!-- Stylesheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
        integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="css/style.css?cache=<?php echo time(); ?>" rel="stylesheet">
    <link href="css/responsive.css?cache=<?php echo time(); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Bellefair&amp;family=Open+Sans:wght@300;400;700;800&amp;family=Oswald:wght@400;500;600;700&amp;display=swap"
        rel="stylesheet">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
    <!-- Responsive -->
     @yield('customcss')
    <!-- Meta Pixel Code -->
<script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '1738239533216680');
    fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=1738239533216680&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Meta Pixel Code -->
   
</head>

<style>
    .loader{
    width: 128px;
    height: 128px;
    line-height: 128px;
    border-radius: 50%;
    border-top: 5px solid #eb6c18;
    text-align: center;
    position: relative;
    margin: 30px auto;
    -webkit-animation: 2s loading1 ease-in-out infinite;
    animation: 2s loading1 ease-in-out infinite;
}
.loader:before,
.loader:after{
    content: "";
    display: block;
    width: 128px;
    height: 128px;
    border-radius: 50%;
    position: absolute;
    top: -5px;
    left: 0;
}
.loader:before{
    border-top: 5px solid #000000;
    -webkit-transform: rotate(120deg);
    transform: rotate(120deg)
}
.loader:after{
    border-top: 5px solid #1be64a;
    -webkit-transform: rotate(240deg);
    transform: rotate(240deg)
}
.loader .loader-inner{
    display: block;
    width: 128px;
    height: 128px;
    position: absolute;
    top: -5px;
    left: 0;
    -webkit-animation: 2s loading2 linear infinite;
    animation: 2s loading2 linear infinite;
}
@-webkit-keyframes loading1{
    50% {
        -webkit-transform: rotate(180deg)
    }
    100% {
        -webkit-transform: rotate(360deg)
    }
}
@keyframes loading1{
    50% {
        -webkit-transform: rotate(180deg);
        transform: rotate(180deg)
    }
    100% {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg)
    }
}
@-webkit-keyframes loading2{
    50% {
        -webkit-transform: rotate(-180deg)
    }
    100% {
        -webkit-transform: rotate(-360deg)
    }
}
@keyframes loading2{
    50% {
        -webkit-transform: rotate(-180deg);
        transform: rotate(-180deg)
    }
    100% {
        -webkit-transform: rotate(-360deg);
        transform: rotate(-360deg)
    }
}


</style>

{{-- chat style --}}
<style>
    @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css');

    /* Chatbot */
    .botIcon {bottom: 20px;right: 26px;position: fixed;z-index: 9999;}
    .iconInner {-webkit-align-items: center;-ms-align-items: center;align-items: center;background: #a64bf4;background: -webkit-linear-gradient(to left, #00dbde, #fc00ff, #00dbde, #fc00ff);background: -o-linear-gradient(to left, #00dbde, #fc00ff, #00dbde, #fc00ff);background: -moz-linear-gradient(to left,#00dbde, #fc00ff, #00dbde,#fc00ff);background: linear-gradient(to left, #00dbde, #fc00ff, #00dbde, #fc00ff);background-position: 50%;background-size: 300%;border-radius: 50%;color: #fff;cursor: pointer;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-flex-wrap: wrap;-ms-flex-wrap: wrap;flex-wrap: wrap;font-size: 1.7em;height: 2em;justify-content: center;width: 2em;}
    .botSubject, .messages, .showBotSubject .botIconContainer, .showMessenger .botIconContainer {display: none;}
    .botIcon .Messages, .botIcon .Messages_list {-webkit-box-flex: 1;-webkit-flex-grow: 1;-ms-flex-positive: 1;flex-grow: 1;}
    .chat_close_icon {color: #fff;cursor: pointer;font-size: 16px;position: absolute;right: 12px;z-index: 99999;}
    .chat_on {background-color: #8a57cf;bottom: 20px;border-radius: 50%;box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12) !important;color: #fff;cursor: pointer;display: block;height: 45px;padding: 9px;position: fixed;right: 15px;text-align: center;width: 45px;z-index: 9999;}
    .chat_on_icon {color: #fff;font-size: 25px;text-align: center;}
    .botIcon .Layout {-webkit-animation: appear .15s cubic-bezier(.25, .25, .5, 1.1);-ms-animation: appear .15s cubic-bezier(.25, .25, .5, 1.1);animation: appear .15s cubic-bezier(.25, .25, .5, 1.1);-webkit-animation-fill-mode: forwards;-ms-animation-fill-mode: forwards;animation-fill-mode: forwards;background-color: rgb(63, 81, 181);bottom: 20px;border-radius: 10px;box-shadow: 5px 0 20px 5px rgba(0, 0, 0, .1);box-sizing: content-box !important;color: rgb(255, 255, 255);display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-webkit-flex-direction: column;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: end;-webkit-justify-content: flex-end;-ms-flex-pack: end;justify-content: flex-end;max-height: 30px;max-width: 300px;min-width: 50px;opacity: 0;pointer-events: auto;position: fixed;-webkit-transition: right .1s cubic-bezier(.25, .25, .5, 1), bottom .1s cubic-bezier(.25, .25, .5, 1), min-width .2s cubic-bezier(.25, .25, .5, 1), max-width .2s cubic-bezier(.25, .25, .5, 1), min-height .2s cubic-bezier(.25, .25, .5, 1), max-height .2s cubic-bezier(.25, .25, .5, 1), border-radius 50ms cubic-bezier(.25, .25, .5, 1) .15s, background-color 50ms cubic-bezier(.25, .25, .5, 1) .15s, color 50ms cubic-bezier(.25, .25, .5, 1) .15s;-ms-transition: right .1s cubic-bezier(.25, .25, .5, 1), bottom .1s cubic-bezier(.25, .25, .5, 1), min-width .2s cubic-bezier(.25, .25, .5, 1), max-width .2s cubic-bezier(.25, .25, .5, 1), min-height .2s cubic-bezier(.25, .25, .5, 1), max-height .2s cubic-bezier(.25, .25, .5, 1), border-radius 50ms cubic-bezier(.25, .25, .5, 1) .15s, background-color 50ms cubic-bezier(.25, .25, .5, 1) .15s, color 50ms cubic-bezier(.25, .25, .5, 1) .15s;transition: right .1s cubic-bezier(.25, .25, .5, 1), bottom .1s cubic-bezier(.25, .25, .5, 1), min-width .2s cubic-bezier(.25, .25, .5, 1), max-width .2s cubic-bezier(.25, .25, .5, 1), min-height .2s cubic-bezier(.25, .25, .5, 1), max-height .2s cubic-bezier(.25, .25, .5, 1), border-radius 50ms cubic-bezier(.25, .25, .5, 1) .15s, background-color 50ms cubic-bezier(.25, .25, .5, 1) .15s, color 50ms cubic-bezier(.25, .25, .5, 1) .15s;z-index: 9999999999;}
    .botIcon .Layout-open {border-radius: 10px;color: #fff;height: 500px;max-height: 500px;max-width: 300px;overflow: hidden;-webkit-transition: right .1s cubic-bezier(.25, .25, .5, 1), bottom .1s cubic-bezier(.25, .25, .5, 1.1), min-width .2s cubic-bezier(.25, .25, .5, 1.1), max-width .2s cubic-bezier(.25, .25, .5, 1.1), max-height .2s cubic-bezier(.25, .25, .5, 1.1), min-height .2s cubic-bezier(.25, .25, .5, 1.1), border-radius 0ms cubic-bezier(.25, .25, .5, 1.1), background-color 0ms cubic-bezier(.25, .25, .5, 1.1), color 0ms cubic-bezier(.25, .25, .5, 1.1);-ms-transition: right .1s cubic-bezier(.25, .25, .5, 1), bottom .1s cubic-bezier(.25, .25, .5, 1.1), min-width .2s cubic-bezier(.25, .25, .5, 1.1), max-width .2s cubic-bezier(.25, .25, .5, 1.1), max-height .2s cubic-bezier(.25, .25, .5, 1.1), min-height .2s cubic-bezier(.25, .25, .5, 1.1), border-radius 0ms cubic-bezier(.25, .25, .5, 1.1), background-color 0ms cubic-bezier(.25, .25, .5, 1.1), color 0ms cubic-bezier(.25, .25, .5, 1.1);transition: right .1s cubic-bezier(.25, .25, .5, 1), bottom .1s cubic-bezier(.25, .25, .5, 1.1), min-width .2s cubic-bezier(.25, .25, .5, 1.1), max-width .2s cubic-bezier(.25, .25, .5, 1.1), max-height .2s cubic-bezier(.25, .25, .5, 1.1), min-height .2s cubic-bezier(.25, .25, .5, 1.1), border-radius 0ms cubic-bezier(.25, .25, .5, 1.1), background-color 0ms cubic-bezier(.25, .25, .5, 1.1), color 0ms cubic-bezier(.25, .25, .5, 1.1);width: 100%;}
    .botIcon .Layout-expand {display: none;height: 400px;max-height: 100vh;min-height: 300px;right:15px}
    .showBotSubject.botIcon .Layout-expand {display: block;}
    .botIcon .Layout-mobile {bottom: 10px}
    .botIcon .Layout-mobile.Layout-open {min-width: calc(100% - 20px);width: calc(100% - 20px);}
    .botIcon .Layout-mobile.Layout-expand {border-radius: 0 !important;bottom: 0;height: 100%;min-height: 100%;min-width: 100%;width: 100%;}
    .botIcon .Messenger_messenger {height: 100%;-webkit-box-orient: vertical;-webkit-box-direction: normal;-webkit-flex-direction: column;-ms-flex-direction: column;flex-direction: column;position: relative;width: 100%;}
    .botIcon .Messenger_header, .botIcon .Messenger_messenger {display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;}
    .botIcon .Messenger_header {-webkit-box-align: center;-webkit-align-items: center;-ms-flex-align: center;align-items: center;background-color: rgb(22, 46, 98);color: rgb(255, 255, 255);-webkit-flex-shrink: 0;-ms-flex-negative: 0;flex-shrink: 0;height: 40px;padding-left: 10px;padding-right: 40px;}

    .botIcon .Messenger_header h4 {-webkit-animation: slidein .15s .3s;-ms-animation: slidein .15s .3s;animation: slidein .15s .3s;-webkit-animation-fill-mode: forwards;-ms-animation-fill-mode: forwards;animation-fill-mode: forwards;font-size: 16px;opacity: 0;}
    .botIcon .Messenger_prompt {font-size: 16px;font-weight: 400;line-height: 18px;margin: 0;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
    .botIcon .Messenger_content {background-color: #fff;display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-webkit-flex-direction: column;-ms-flex-direction: column;flex-direction: column;-webkit-box-flex: 1;-webkit-flex-grow: 1;-ms-flex-positive: 1;flex-grow: 1;height: 80px;}
    .botIcon .Messages {background-color: #fff;display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;-webkit-flex-direction: column;-ms-flex-direction: column;flex-direction: column;-webkit-box-orient: vertical;-webkit-box-direction: normal;-webkit-flex-shrink: 1;-ms-flex-negative: 1;flex-shrink: 1;overflow-x: hidden;overflow-y: auto;padding: 10px;position: relative;-webkit-overflow-scrolling: touch;}
    .botIcon .Input {background-color: #fff;border-top: 1px solid #e6ebea;color: #96aab4;-webkit-box-flex: 0;-webkit-flex-grow: 0;-ms-flex-positive: 0;flex-grow: 0;-webkit-flex-shrink: 0;-ms-flex-negative: 0;flex-shrink: 0;padding-bottom: 15px;padding-top: 17px;position: relative;width: 100%;}
    .botIcon .Input-blank .Input_field {max-height: 20px;}
    .botIcon .Input_field {background-color: transparent;border: none;outline: none;padding-left: 20px;padding-right: 45px;resize: none;width: 100%;font-size: 14px;line-height: 20px;min-height: 20px !important;}
    .botIcon .Input_button-emoji {right: 45px;}
    .botIcon .Input_button {background-color: transparent;border: none;bottom: 15px;cursor: pointer;height: 25px;outline: none;padding: 0;position: absolute;width: 25px;}
    .botIcon .Input_button-send {right: 15px;}
    .botIcon .Input-emoji .Input_button-emoji .Icon, .botIcon .Input_button:hover .Icon {-webkit-transform: scale(1.1);-ms-transform: scale(1.1);transform: scale(1.1);-webkit-transition: all .1s ease-in-out;-ms-transition: all .1s ease-in-out;transition: all .1s ease-in-out;}
    .botIcon .Input-emoji .Input_button-emoji .Icon path, .botIcon .Input_button:hover .Icon path {fill: #2c2c46;}
    .Icon svg {height: auto;width: 100%;}

    .msg {display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;}
    .msg.user {-webkit-box-direction: row-reverse;-webkit-flex-direction: row-reverse;-ms-flex-direction: row-reverse;flex-direction: row-reverse;}
    .msg + .msg {margin-top: 15px;}
    span.responsText {color: #000;display: inline-block;margin-left: 10px;vertical-align: top;max-width: calc(100% - 50px);}
    .msg.user span.responsText {margin-left: 0;margin-right: 10px;}
    span.avtr {display: inline-block;width: 30px;}
    span.avtr figure {background-color: #ccc;background-position: center;background-repeat: no-repeat;background-size: cover;border-radius: 50%;display: block;margin: 0;padding-bottom: 100%;}

    @-webkit-keyframes appear {
        0% {opacity: 0;-webkit-transform: scale(0);transform: scale(0);}
        100% {opacity: 1;-webkit-transform: scale(1);transform: scale(1);}
    }
    @-ms-keyframes appear {
        0% {opacity: 0;-ms-transform: scale(0);transform: scale(0);}
        100% {opacity: 1;-ms-transform: scale(1);transform: scale(1);}
    }
    @keyframes appear {
        0% {opacity: 0;-webkit-transform: scale(0);transform: scale(0);}
        100% {opacity: 1;-webkit-transform: scale(1);transform: scale(1);}
    }
    @-webkit-keyframes slidein {
        0% {opacity: 0;-webkit-transform: translateX(10px);transform: translateX(10px);}
        100% {opacity: 1;-webkit-transform: translateX(0);transform: translateX(0);}
    }
    @-ms-keyframes slidein {
        0% {opacity: 0;-ms-transform: translateX(10px);transform: translateX(10px);}
        100% {opacity: 1;-ms-transform: translateX(0);transform: translateX(0);}
    }
    @keyframes slidein {
        0% {opacity: 0;-webkit-transform: translateX(10px);transform: translateX(10px);}
        100% {opacity: 1;-webkit-transform: translateX(0);transform: translateX(0);}
    }

    @media only screen and (max-width: 412px) {
        .botIcon .Layout-open {width: 250px;}
    }

    .responsText button{
        background: #1f82f3;
        color: white;
        padding: 0px 11px;
        border-radius: 10px;
        margin-left: 27px;

    }

    
</style>
{{-- end chat style --}}

<body token="{{ csrf_token() }}">
    
    <div class="preloader">
        <div class="main-box-div">
            <div class="row">
            <div class="col-md-12">
                <div class="loader">
                    <span class="loader-inner text-dark"><b><span style="color: #eb6c18">FILE</span><span>UR</span><span style="color: green">TAX</span> </b></span>
                </div>
            </div>
        </div>
        </div>
    </div>



{{-- chat coding --}}
    <div class="botIcon">
        <div class="botIconContainer">
            <div class="iconInner">
                <i class="fa fa-commenting" aria-hidden="true"></i>
            </div>
        </div>
        <div class="Layout Layout-open Layout-expand Layout-right">
            <div class="Messenger_messenger">
                <div class="Messenger_header">
                    <h4 class="Messenger_prompt">Welcome To FILEURTAX</h4> <span class="chat_close_icon"><i class="fa fa-window-close" aria-hidden="true"></i></span>
                </div>
                <div class="Messenger_content">
                    <div class="Messages">
                        <div class="Messages_list"></div>
                    </div>
                    <form id="messenger">
                        <div class="Input Input-blank">
    <!--<textarea name="msg" class="Input_field" placeholder="Send a message..."></textarea> -->
                            <input name="msg" class="Input_field" placeholder="Send a message..." autocomplete="off">
                            <button type="submit" class="Input_button Input_button-send">
                                <div class="Icon">
                                    <svg viewBox="1496 193 57 54" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <g id="Group-9-Copy-3" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(1523.000000, 220.000000) rotate(-270.000000) translate(-1523.000000, -220.000000) translate(1499.000000, 193.000000)">
                                            <path d="M5.42994667,44.5306122 L16.5955554,44.5306122 L21.049938,20.423658 C21.6518463,17.1661523 26.3121212,17.1441362 26.9447801,20.3958097 L31.6405465,44.5306122 L42.5313185,44.5306122 L23.9806326,7.0871633 L5.42994667,44.5306122 Z M22.0420732,48.0757124 C21.779222,49.4982538 20.5386331,50.5306122 19.0920112,50.5306122 L1.59009899,50.5306122 C-1.20169244,50.5306122 -2.87079654,47.7697069 -1.64625638,45.2980459 L20.8461928,-0.101616237 C22.1967178,-2.8275701 25.7710778,-2.81438868 27.1150723,-0.101616237 L49.6075215,45.2980459 C5.08414042,47.7885641 49.1422456,50.5306122 46.3613062,50.5306122 L29.1679835,50.5306122 C27.7320366,50.5306122 26.4974445,49.5130766 26.2232033,48.1035608 L24.0760553,37.0678766 L22.0420732,48.0757124 Z" id="sendicon" fill="#96AAB4" fill-rule="nonzero"></path>
                                        </g>
                                    </svg>
                                </div>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{-- edn chat codding --}}


    {{-- chat script --}}
    <script>
        jQuery(document).ready(function($) {
            jQuery(document).on('click', '.iconInner', function(e) {
                jQuery(this).parents('.botIcon').addClass('showBotSubject');
                $("[name='msg']").focus();
                $(".Input_field").val("welcome msg");
                $(".Input_button ").click();
                
            });

            jQuery(document).on('click', '.closeBtn, .chat_close_icon', function(e) {
                jQuery(this).parents('.botIcon').removeClass('showBotSubject');
                jQuery(this).parents('.botIcon').removeClass('showMessenger');
            });

            jQuery(document).on('submit', '#botSubject', function(e) {
                e.preventDefault();

                jQuery(this).parents('.botIcon').removeClass('showBotSubject');
                jQuery(this).parents('.botIcon').addClass('showMessenger');
               
            });
            
            /* Chatboat Code */
            $(document).on("submit", "#messenger", function(e) {
                e.preventDefault();

                var val = $("[name=msg]").val().toLowerCase();
                var mainval = $("[name=msg]").val();
                name = '';
                nowtime = new Date();
                nowhoue = nowtime.getHours();

                function userMsg(msg) {
                    if(!msg.startsWith("welcome msg")){
                        $('.Messages_list').append('<div class="msg user"><span class="avtr"><figure style="background-image: url(https://mrseankumar25.github.io/Sandeep-Kumar-Frontend-Developer-UI-Specialist/images/avatar.png)"></figure></span><span class="responsText">' + mainval + '</span></div>');
                    }
                    
                    
                };
                function appendMsg(msg) {
                    if(msg.startsWith("<button")){
                        $('.Messages_list').append('<div class="msg"><span class="responsText">' + msg + '</span></div>');
                    }
                    else{
                        $('.Messages_list').append('<div class="msg"><span class="avtr"><figure style="background-image: url(https://mrseankumar25.github.io/Sandeep-Kumar-Frontend-Developer-UI-Specialist/images/avatar.png)"></figure></span><span class="responsText">' + msg + '</span></div>');
                    }
                    
                    
                    $("[name='msg']").val("");
                };

                


                userMsg(mainval);

                

                if( val.indexOf("hello") > -1 || val.indexOf("hi") > -1 ||val.indexOf("hy") > -1 || val.indexOf("good morning") > -1 || val.indexOf("good afternoon") > -1 || val.indexOf("good evening") > -1 || val.indexOf("good night") > -1 ) {
                    if(nowhoue >= 12 && nowhoue <= 16) {
                        appendMsg('good afternoon');
                    } else if(nowhoue >= 10 && nowhoue <= 12) {
                        appendMsg('hi');
                    } else if(nowhoue >= 0 && nowhoue <= 10) {
                        appendMsg('good morning');
                    } else {
                        appendMsg('good evening');
                    }

                    appendMsg("What is Your Name?");

                } else if( val.indexOf("i have problem with") > -1) {
                    if (val.indexOf("girlfriend") > -1 || val.indexOf("gf") > -1) {

                        appendMsg("take out your girlfriend, for dinner or movie.");
                        appendMsg("is it helpful? (yes/no)");

                    } else if (val.indexOf("boyfriend") > -1 || val.indexOf("bf") > -1) {
                        appendMsg("bye something for him.");
                        appendMsg("is it helpful? (yes/no)");
                    } else {
                        appendMsg("sorry, i'm not able to get you point, please ask something else.");
                    }
                } else if( val.indexOf("yes") > -1) {
                    var nowtime = new Date();
                    var nowhoue = nowtime.getHours();
                    appendMsg("it's my pleaser that i can help you");
                    saybye();
                } else if( val.indexOf("no") > -1) {
                    var nowtime = new Date();
                    var nowhoue = nowtime.getHours();
                    appendMsg("it's my bad that i can't able to help you. please try letter");
                    saybye();
                } else if( val.indexOf("by") > -1 || val.indexOf("bye") > -1) {
                    var nowtime = new Date();
                    var nowhoue = nowtime.getHours();
                    appendMsg("it's my bad that i can't able to help you. please try letter");
                    saybye();
                    } 
                else if( val.indexOf("my name is ") > -1 || val.indexOf("i am ") > -1 || val.indexOf("i'm ") > -1 || val.split(" ").length < 2) {/*|| mainval != ""*/
                    // var name = "";
                    if(val.indexOf("my name is") > -1) {
                        name = val.replace("my name is", "");
                    }
                    else if(val.indexOf("i am") > -1) {
                        name = val.replace("i am", "");
                    }
                    else if(val.indexOf("i'm") > -1) {
                        name = val.replace("i'm", "");
                    }
                    else {
                        name = mainval;
                    }
                    // appendMsg("hi " + name + ", how can i help you?");
                    appendMsg("Hi "+name+" how can i help you?");
                    appendMsg("select one service");
                    appendMsg("<button type='button' class='select-service'>Need Lawyer</button>");
                    appendMsg("<button type='button' class='select-service'>Need CA</button>");
                    appendMsg("<button type='button' class='select-service'>Need CS</button>");
                    appendMsg("<button type='button' class='select-service'>Need CMA</button>");
                    $(".select-service").each(function(){
                        $(this).click(function(){
                            $(".Input_field").val($(this).html())
                            $(".Input_button ").click();
                        })
                    })

                } 
                else if( val.indexOf(" lawyer") > -1 || val.indexOf(" legal service") > -1 ){
                    appendMsg("hi "+name+" Please select one legal service");
                    appendMsg("<button type='button' class='select-service'>Bankruptcy</button>");
                    appendMsg("<button type='button' class='select-service'>Insolvency</button>");
                    appendMsg("<button type='button' class='select-service'>Banking Fraud Cases</button>");
                    appendMsg("<button type='button' class='select-service'>Cheque Bounce</button>");
                    appendMsg("<button type='button' class='select-service'>Documents</button>");
                    appendMsg("<button type='button' class='select-service'>Contracts</button>");
                    appendMsg("<button type='button' class='select-service'>Registrations</button>");
                    appendMsg("<button type='button' class='select-service'>Litigation</button>");

                    $(".select-service").each(function(){
                        var service_name = '';
                        $(this).click(function(){
                            service_name = $(this).html();
                            if(!$(this).html().startsWith("<input")){
                            appendMsg('<input type="number" name="mobile" placeholder="Mobile Number" class="form-control">')
                            appendMsg('<input type="email" name="email" placeholder="Enter Your Email Id" class="form-control">')
                            appendMsg("<button type='button' class='send-message'>send</button>");
                            $("input[type='number']").focus();
                            $(".send-message").click(function(){
                            
                            var url = "https://api.whatsapp.com/send/?phone=918335935735&text=i%20need%20"+service_name+"%20service";
                            window.location = url;
                        })
                    }
                            
                        })

                        
                    })
                }
                else if( val.indexOf(" cs") > -1 ){
                    appendMsg("hi "+name+" Please select one cs service");
                    appendMsg("<button type='button' class='select-service'>Insolvency & Bankruptcy</button>");
                    appendMsg("<button type='button' class='select-service'>Legal Due Diligence and Transaction Documents</button>");
                    appendMsg("<button type='button' class='select-service'>Corporate Governance</button>");
                    appendMsg("<button type='button' class='select-service'>Corporate Secretarial Services</button>");
                    appendMsg("<button type='button' class='select-service'>Audit & Assurance</button>");
                    appendMsg("<button type='button' class='select-service'>Regulatory Approvals</button>");
                    appendMsg("<button type='button' class='select-service'>Joint Ventures, Mergers, Amalgamations & Acquisitions</button>");

                    $(".select-service").each(function(){
                        $(this).click(function(){
                            service_name = $(this).html();
                            appendMsg('<input type="number" name="mobile" placeholder="Mobile Number" class="form-control">')
                            appendMsg('<input type="email" name="email" placeholder="Enter Your Email Id" class="form-control">')
                            appendMsg("<button type='button' class='send-message'>send</button>");
                            $("input[type='number']").focus();
                            $(".send-message").click(function(){
                            
                            var url = "https://api.whatsapp.com/send/?phone=918335935735&text=i%20need%20"+service_name+"%20service";
                            window.location = url;
                        })
                            
                        })
                    })
                }
                else if( val.indexOf(" cma") > -1 ){
                    appendMsg("hi "+name+" Please select one cma service");
                    appendMsg("<button type='button' class='select-service'>Feasibility Studies and Concept Estimates</button>");
                    appendMsg("<button type='button' class='select-service'>Cost Planning</button>");
                    appendMsg("<button type='button' class='select-service'>Budget Planning</button>");
                    appendMsg("<button type='button' class='select-service'>Cost Estimating</button>");
                    appendMsg("<button type='button' class='select-service'>Project Cost Management</button>");
                    appendMsg("<button type='button' class='select-service'>Procurement Bid Evaluation and Reconciliation</button>");
                    appendMsg("<button type='button' class='select-service'>Final Account Negotiation Cost Auditing</button>");

                    $(".select-service").each(function(){
                        $(this).click(function(){
                            service_name = $(this).html();
                            appendMsg('<input type="number" name="mobile" placeholder="Mobile Number" class="form-control">')
                            appendMsg('<input type="email" name="email" placeholder="Enter Your Email Id" class="form-control">')
                            appendMsg("<button type='button' class='send-message'>send</button>");
                            $("input[type='number']").focus();
                            $(".send-message").click(function(){
                            
                            var url = "https://api.whatsapp.com/send/?phone=918335935735&text=i%20need%20"+service_name+"%20service";
                            window.location = url;
                        })
                            
                        })
                    })
                }
                else if( val.indexOf(" ca") > -1 ){
                    appendMsg("hi "+name+" Please select one ca service");
                    appendMsg("<button type='button' class='select-service'>GST Registration</button>");
                    appendMsg("<button type='button' class='select-service'>Trademark Registration</button>");
                    appendMsg("<button type='button' class='select-service'>Company Annual Filling</button>");
                    appendMsg("<button type='button' class='select-service'>FSSAI Registration</button>");
                    appendMsg("<button type='button' class='select-service'>FDI Compliance</button>");
                    appendMsg("<button type='button' class='select-service'>Tax Filing</button>");
                    appendMsg("<button type='button' class='select-service'>Bookkeeping and Outsourcing</button>");
                    appendMsg("<button type='button' class='select-service'>Company Formation & Regulation</button>");

                    $(".select-service").each(function(){
                        $(this).click(function(){
                            service_name = $(this).html();
                            appendMsg('<input type="number" name="mobile" placeholder="Mobile Number" class="form-control">')
                            appendMsg('<input type="email" name="email" placeholder="Enter Your Email Id" class="form-control">')
                            appendMsg("<button type='button' class='send-message'>send</button>");
                            $("input[type='number']").focus();
                            $(".send-message").click(function(){
                            
                            var url = "https://api.whatsapp.com/send/?phone=918335935735&text=i%20need%20"+service_name+"%20service";
                            window.location = url;
                        })
                            
                        })
                    })

                }
                else if(val.indexOf("welcome msg") > -1 ){
                    appendMsg("Hi, Welcome to Fileurtax");
                }
                else {
                    appendMsg('<input type="number" name="mobile" placeholder="Mobile Number" class="form-control">')
                    appendMsg('<input type="email" name="email" placeholder="Enter Your Email Id" class="form-control">')
                    appendMsg("<button type='button' class='send-message'>send</button>");
                    $("input[type='number']").focus();
                }

                function saybye() {
                    if (nowhoue <= 10) {
                        appendMsg(" have nice day! :)");
                    } else if (nowhoue >= 11 || nowhoue <= 20) {
                        appendMsg(" bye!");
                    } else {
                        appendMsg(" good night!");
                    }
                }

                var lastMsg = $('.Messages_list').find('.msg').last().offset().top;
                $('.Messages').animate({scrollTop: lastMsg}, 'slow');
            });
            /* Chatboat Code */
        })
    </script>
    {{-- end chat script --}}

<script type="text/javascript" src="js/cookie-consent.js" charset="UTF-8"></script>
<script type="text/javascript" charset="UTF-8">
document.addEventListener('DOMContentLoaded', function () {
cookieconsent.run({"notice_banner_type":"simple","consent_type":"express","palette":"light","language":"en","page_load_consent_levels":["strictly-necessary"],"notice_banner_reject_button_hide":false,"preferences_center_close_button_hide":false,"page_refresh_confirmation_buttons":false,"website_name":"Fileurtax","website_privacy_policy_url":"https://fileurtax.com"});
});
</script>
