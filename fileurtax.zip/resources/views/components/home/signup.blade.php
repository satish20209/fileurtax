
<div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <!-- Page Title -->
      <section class="page-title" style="background-image:url(images/background/1.jpg)">
          <div class="auto-container">
              <h1>SIGNUP</h1>
              <ul class="page-breadcrumb">
                  <li><a href="/">Home</a></li>
                  <li>Signup</li>
              </ul>
          </div>
      </section>
      <!-- End Page Title -->
  
      <!-- Map Section -->
      <section class="map-section">
          <div class="auto-container">
              <div class="inner-container">
                  <!-- Map Boxed -->
                  <div class="map-boxed">
                      <!-- Map Outer -->
                      <div class="map-outer">
                          <section class="contact-form-section">
                              <div class="auto-container">
                                  <!-- Sec Title -->
                                  <div class="sec-title centered">
                                      <h2>SIGNUP</h2>
                                  </div>
                                  <!-- Contact Form -->
                                  <div class="contact-form">
                                    
                                      <!--Contact Form-->
                                      <form method="post" action="/membersignup" id="serviceProviderRegistration"enctype="multipart/form-data" autocapitalize="on" name="forms">
                                        @csrf
                                        <div class="row clearfix d-flex justify-content-center">
                                            

                                            <div class="col-12 col-md-6 mb-2">
                                                <input onkeypress="return onlyAlphabets()" required type="text" name="fname" id="fname" placeholder="Enter Your First Name" autocomplete="off" onpaste="return false;">
                                                <small class="d-none text-danger fname-error">First Name can`t be Empty</small>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2">
                                                <input onkeypress="return onlyAlphabetstwo()" required  type="text" name="lname" id="lname" placeholder="Enter Your Last Name" autocomplete="off" onpaste="return false;">
                                                <small class="d-none text-danger lname-error">last Name can`t be Empty</small>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2">
                                                <input required  type="text" pattern="" name="mobile" id="mobile" placeholder="Enter Your Mobile Number" autocomplete="off" class="mobilenumbervalidate" onpaste="return false;">
                                                <small class="d-none text-danger mobile-error">Mobile Number can`t be Empty</small>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2">
                                                <input required  type="email" name="email" id="email" placeholder="Enter Your Email ID" autocomplete="off" onpaste="return false;">
                                                <small class="d-none text-danger email-error">Email ID can`t be Empty</small>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2">
                                                <select required title="Select"class="mb-3 login-form-input"  name="role" id="selectservice">
                                                    <option value="">Select User</option>                                
                                                    <option value="C">CUSTOMER</option>
                                                    <option value="CA">CA</option>
                                                    <option value="CS">CS</option>
                                                    <option value="CMA">CMA</option>
                                                    <option value="L">LAWYER</option>
                                                </select>
                                                <small class="d-none text-danger selectservice-error">Please Select Role</small>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2 hidepicture">
                                                <label for="">Upload Profile Picture</label>
                                                <input required type="file" name="picture" title="Upload Your Picture"  accept="image/png,image/gif,image/jpeg" id="picture">
                                            </div>

                                            <div class="col-12 col-md-6 mb-2 experience">
                                                <select required title="Select Experience" name="experience" id="experience">
                                                    <option value="">Select Experience</option>
                                                    <option value="fresher">Fresher</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                    <option value="9">9</option>
                                                    <option value="10">10</option>
                                                    <option value="11">11</option>
                                                    <option value="12">12</option>
                                                    <option value="13">13</option>
                                                    <option value="14">14</option>
                                                    <option value="15">15</option>
                                                    <option value="16">16</option>
                                                    <option value="17">17</option>
                                                    <option value="18">18</option>
                                                    <option value="19">19</option>
                                                    <option value="20">20</option>
                                                    <option value="21">21</option>
                                                    <option value="22">22</option>
                                                    <option value="23">23</option>
                                                    <option value="24">24</option>
                                                    <option value="25">25</option>
                                                    <option value="26">26</option>
                                                    <option value="27">27</option>
                                                    <option value="28">28</option>
                                                    <option value="29">29</option>
                                                    <option value="30">30</option>
                                                    <option value="31">31</option>
                                                    <option value="32">32</option>
                                                    <option value="33">33</option>
                                                    <option value="34">34</option>
                                                    <option value="35">35</option>
                                                    <option value="36">36</option>
                                                    <option value="37">37</option>
                                                    <option value="38">38</option>
                                                    <option value="39">39</option>
                                                    <option value="40">40</option>
                                                </select>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2" id="bob-box">
                                                <label class="ms-2" for="dob">Date of Birth</label>
                                                <input required class="" type="date" name="dob" id="dob" placeholder="Select Your DOB" max="2004-12-30"><!--<?php echo date("Y-m-d"); ?>-->
                                                <div class="text-danger error-alert d-none" id="dob-error"> </div>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2">
                                                <input required type="password" name="password" id="password" placeholder="Create Your Password">
                                                <i class="fa fa-eye showpasswordeye text-dark" style="float: right;margin:-38px 15px;font-size:20px"></i>
                                                <i class="fa fa-eye-slash d-none hidepasswordeye text-dark" style="float: right;margin:-38px 15px;font-size:20px"></i>
                                                <small class="d-none text-danger password-error">Password can`t be Empty</small>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2">
                                               <input type="password" id="cpassword" placeholder="Confirm Password">
                                                <small class="d-none text-danger cpassword-error">Confirm Password can`t be Empty</small>
                                                <small class="d-none text-danger match-error">Confirm Password not Match</small>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2 salaryrange">
                                                <p style="color: black !important;padding:0px;margin:0px"><b>Salary Range</b></p>
                                                <div class="d-flex">
                                                    <input class="me-2 " type="radio" id="fixed" name="radio"
                                                        value="Fixed salary">
                                                    <label for="fixed">Fixed Salary</label>
                                                </div>
                                                <div class="hearing-hide d-flex">
                                                    <input class="me-2" type="radio" id="hiring" name="radio"
                                                        value="Hiring">
                                                    <label for="hiring">Hearing</label><br>
                                                </div>
                                                <div class=" d-flex">
                                                    <input class="me-2" type="radio" id="part" name="radio"
                                                        value="Part Time">
                                                    <label for="part">Part Time</label>
                                                </div>
                                                <div class="d-flex">
                                                    <input class="me-2" type="radio" id="full" name="radio"
                                                        value="Full Time">
                                                    <label for="full">Full Time</label>
                                                </div>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2">
                                                <input class=" me-2" type="checkbox" id="check1" name="callback" value="checked">
                                                <label class="form-check-label">Requesting Help for Updating the Profile</label>
                                            </div>

                                            <div class="col-12 col-md-6 mb-2">
                                                <p>Not Registered Yet? <span><a style="color:rgb(0, 0, 0);font-size:17px;" href="login"><b>Login Now</b></a>
                                            </div>
                                            <div class="col-12 col-md-6 mb-2">
                                                <button class="theme-btn btn-style-two"  id="submitform" type="button"><span class="txt">REGISTER<i class="arrow flaticon-right"></i></span></button>
                                            </div>


                                          </div>
                                          <div class=" mt-3 alert alert-danger erroradminlogin d-none" role="alert">
                                          </div>
                                      </form>
                      
                                      <!--End Contact Form -->
                                  </div>
                              </div>
                          </section>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <!-- End Map Section -->
  </div>
  

  {{-- thankyouModalServiceProvider --}}
  <div class="modal fade  text-center" id="thankyouModalServiceProvider" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"  aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <img src="images/registrationSuccess.gif" alt="registration Success" style="width: 70%">
                <h5>You Registered Successfully</h5>
                <p>Plaese Login</p>
                <button class="btn btn-primary mt-3 submitformregister" data-bs-dismiss="modal"  type="button"><span class="txt">Ok</span></button>
                
            </div>
        </div>
    </div>
</div>
{{-- thankyouModalServiceProvider --}}

{{-- Modal For Email Code Enter --}}
<div class="modal fade " id="enterEmailCode" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"  aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-body p-0 m-0">
                <p class="text-white bg-primary p-2 text-center">Check Your Message and E-Mail Inbox</p>
                <div class="p-3">
                    <p class="text-dark"><span>Your Email ID is :- </span> <span class="email-val"></span> </p>
                    <div>Otp Validated in <span id="time">05:00</span> minutes!</div>
                    <form method="POST">
                        <input class="login-form-input" type="text" id="emailCode" name="emailCode" placeholder="Email Verification code" required="">
                            <small class="text-danger notice-emailcode"></small>
                            <div class="d-flex justify-content-between">
                                <button class="btn btn-warning mt-3" id="editemail" type="button"><span class="txt">Edit Email</span></button>
                                <button class="btn btn-primary mt-3" id="submitEmailCode" type="button"><span class="txt">Verify</span></button>
                                <button class="btn btn-primary mt-3 d-none" id="resendotp" type="button"><span class="txt">Resend OTP</span></button>
                                
                            </div>
                    </form> 
                </div>         
            </div>
        </div>
    </div>
</div>
{{-- Modal For Email Code Enter End --}}


{{-- Ajax Request for Email Verify --}}
<script type="text/javascript">

function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    console.log(duration)
   var x = setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
        display.textContent = minutes + ":" + seconds;
        if (--timer < 0) {
            clearInterval(x);
            deleteotp();
            $("#submitEmailCode").addClass('d-none');
            $("#resendotp").removeClass('d-none');
        }
    }, 1000);
}

function deleteotp(){
    sessionStorage.clear();
    if(sessionStorage.getItem('emailcode') == null){
           $.ajax({
           url: "/deleteemail",
           type: "get",
           data: {'email':$('#email').val()}
       })
    }

}

function sendemailOTP(){
    let userEmail = $('#email').val();
    // alert("call ajax")
    $.ajax({
        url: "/emailVerify",
        type: "POST",
        data: {
            "_token": "{{ csrf_token() }}",
            email: userEmail,
        },
        beforeSend: function(){
            $("#submitform").html('<button class="theme-btn btn-style-two"  type="button"><span class="txt">Please Wait <i class="fa fa-spinner fa-spin text-white txt" style="font-size:20px"></i></button>');
        },
        success: function(response) {
            sessionStorage.setItem("emailcode",response.emailcode.code);
            $("#submitEmailCode").removeClass('d-none');
            $("#resendotp").addClass('d-none');
            $('#enterEmailCode').modal('show');
            var fiveMinutes = 60 * 5,
                display = document.querySelector('#time');
                startTimer(fiveMinutes, display);
            $("#submitform").html("REGISTER");
            $(".email-val").html($('#email').val());
            if (response.status == 'Email not registered') {
            } else if (response.status == 'Email Already registered') {
                $('.email-error').text('Email Already Registered');
            }
        }
    });
}


$("#resendotp").click(function(){
    sendemailOTP();
})
// window.onload = function () {
//     var fiveMinutes = 60 * 5,
//         display = document.querySelector('#time');
//     startTimer(fiveMinutes, display);
// };

    $("#editemail").click(function(){
        $('#enterEmailCode').modal('hide');
    });
    $("#editemail").click(function(){
        $('#enterEmailCode').modal('hide');
    });
    $(".submitformregister").click(function(){
        $("#serviceProviderRegistration").submit();
        // $('#successmodel').modal('hide');
        $('#thankyouModalServiceProvider').modal('show');
    });

    $("#mobile").on("keypress",function(e){

        var $this = $(this);
      var regex = new RegExp("^[0-9\b]+$");
      var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
      // for 10 digit number only
      if ($this.val().length > 9) {
          
          return false;
      }
      else if (e.charCode < 54 && e.charCode > 47) {
          if ($this.val().length == 0) {
              // warning for validate mobile number
              e.preventDefault();
              return false;
          } else {
              return true;
          }

      }
      else if (regex.test(str)) {
          return true;
      }
      e.preventDefault();
      return false;
    })
    $('input').on("input",function(){
        $(".fname-error").addClass('d-none');
        $(".lname-error").addClass('d-none');
        $(".mobile-error").addClass('d-none');
        $(".selectservice-error").addClass('d-none');
        $(".password-error").addClass('d-none');
        $(".cpassword-error").addClass('d-none');
        $(".match-error").addClass('d-none');
    })
    $('#submitform').on('click', function(e){
        e.preventDefault();
        if($("#fname").val() == "")
        {$(".fname-error").removeClass('d-none');}

        else if($("#lname").val() == "")
        {$(".lname-error").removeClass('d-none');}

        else if($("#mobile").val() == "")
        {
            $(".mobile-error").removeClass('d-none');
        }
        else if($("#mobile").val().length != 10)
        {
            $(".mobile-error").removeClass('d-none');
            $(".mobile-error").html("please enter valid Mobile Number")
        }

        else if($("#email").val() == "")
        {$(".email-error").removeClass('d-none');}

        else if($("#selectservice").val() == "")
        {$(".selectservice-error").removeClass('d-none');}

        else if($("#password").val() == "")
        {$(".password-error").removeClass('d-none');}

        else if($("#cpassword").val() == "")
        {
            $(".cpassword-error").removeClass('d-none');
        }

        else if($("#cpassword").val() != $("#password").val())
        {$(".match-error").removeClass('d-none');}

        else{
            if($("small").hasClass("d-none"))
                {
                    sendemailOTP();
                    
                }else{
                    return false;
                }
        
            }
    });
</script>
{{-- Ajax Request for Email Verify End --}}
{{-- Ajax Request for Email Code Submit --}}
<script type="text/javascript">
    $('#submitEmailCode').on('click', function(e) {
        e.preventDefault();
        let emailCode = $('#emailCode').val();
        var emailotp = sessionStorage.getItem("emailcode");
        
        if(emailotp == emailCode)
        {
            $(".notice-emailcode").html("Email Verification successfull");
            $('#enterEmailCode').modal('hide');
            $('#thankyouModalServiceProvider').modal('show');
            deleteotp();
        }else{
            $(".notice-emailcode").html("Email Verification failed check OTP");
        }
    });
</script>
{{-- Ajax Request for Email Code Submit End --}}
<script>
    $(document).ready(function() {
        if ($("#selectservice").val() == "") {
            $("#bob-box").addClass("d-none");
            $(".salaryrange").addClass("d-none");
            $(".experience").addClass("d-none");
            $(".hidepicture").addClass("d-none");
        }
        $("#selectservice").on("change", function() {
            if ($(this).val() == "C" || $("#selectservice").val() == "") {
                $("#dob").removeAttr('required')
                $("#experience").removeAttr('required')
                $(".picture_pic").removeAttr('required')
                $(".forcustomer").removeClass("d-none");
                $(".forserviceprovider").addClass("d-none");
                $("#bob-box").addClass("d-none");
                $(".salaryrange").addClass("d-none");
                $(".experience").addClass("d-none");
                $(".hidepicture").addClass("d-none");
            } 
             else if($(this).val() == "L") {
                $(".hearing-hide").removeClass("d-none");
                $("#dob").attr('required')
                $("#experience").attr('required')
                $(".picture_pic").attr('required')
                $("#bob-box").removeClass("d-none");
                $(".salaryrange").removeClass("d-none");
                $(".experience").removeClass("d-none");;
                $(".hidepicture").removeClass("d-none");
                $(".forserviceprovider").removeClass("d-none");
                $(".forcustomer").addClass("d-none");
            }
             else {
                $(".hearing-hide").addClass("d-none");
                $("#dob").attr('required')
                $("#experience").attr('required')
                $(".picture_pic").attr('required')
                $("#bob-box").removeClass("d-none");
                $(".salaryrange").removeClass("d-none");
                $(".experience").removeClass("d-none");;
                $(".hidepicture").removeClass("d-none");
                $(".forserviceprovider").removeClass("d-none");
                $(".forcustomer").addClass("d-none");
            }
        })
    })
</script>
<script>
$(document).ready(function(){
       $('#email').on('input',function(){
        $("#submitform").removeAttr("disabled","disabled");
        $(".email-error").addClass('d-none');
           $.ajax({
           url: "/check_email",
           type: "get",
           data: {'email':$(this).val()},
           success: function(response) {
               if(response.status == 200){
                $(".email-error").html("Email Already Register Please Login");
                $(".email-error").removeClass('d-none');
                $("#submitform").attr("disabled","disabled");
               }
           }
       })
       })

    })

    $(function() {
        $(".calendar" ).datepicker({
                dateFormat: 'dd/mm/yy',
                firstDay: 1
            });
            $(document).on('click', '.date-picker .input-date', function(e){
                e.preventDefault();
                var $me = $(this),
                        $parent = $me.parents('.date-picker');
                $parent.toggleClass('open');
            });
            $(".calendar").on("change",function(){
                var $me = $(this),
                        $selected = $me.val(),
                        $parent = $me.parents('.date-picker');
                $parent.find('.result').children('span').html($selected);
            });
    });
    function onlyAlphabets() {
        var regex = /^[a-zA-Z]*$/;
        if (regex.test(document.forms.fname.value)) {
            return true;
        }else {
            alert("only Text allowed")
            return false;
        }
    } 
function onlyAlphabetstwo() {
var regex = /^[a-zA-Z]*$/;
if (regex.test(document.forms.lname.value)) {
    return true;
} else {
    alert("only Text allowed")
    return false;
}
} 
$("#picture").on("change",function(){
    var fileName = document.getElementById("picture").value;
        var idxDot = fileName.lastIndexOf(".") + 1;
        var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();
        if (extFile=="jpg" || extFile=="jpeg" || extFile=="png"){
            //TO DO
        }else{
            alert("Only jpg/jpeg and png files are allowed!");
            $("#picture").val("");
        } 
})
$("#email").on("change",function(){
    var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
 if(!this.value.match(regex)){
    alert("enter valid email id")
    $("#email").val("");
 }
});
$("#password").on("change",function(){
    var InputValue = $("#password").val();
   var regex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
     $("#password").text(`Password value:- ${InputValue}`);
     if(regex.test(InputValue)) {
        $("#submitform").attr("disabled",false);
     }
     else{
        $('.password-error').removeClass("d-none");
        $("#submitform").attr("disabled",true);
        $('.password-error').html('password must be a minimum of 8 characters including number, Upper, Lower And one special character');
     }
})
$(".showpasswordeye").click(function(){
    $(".showpasswordeye").addClass("d-none");
    $(".hidepasswordeye").removeClass("d-none")
    $("#password").attr("type","text");
})
$(".hidepasswordeye").click(function(){
    $("#password").attr("type","password");
    $(".showpasswordeye").removeClass("d-none");
    $(".hidepasswordeye").addClass("d-none")
}) 
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.js" integrity="sha512-RCgrAvvoLpP7KVgTkTctrUdv7C6t7Un3p1iaoPr1++3pybCyCsCZZN7QEHMZTcJTmcJ7jzexTO+eFpHk4OCFAg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js" integrity="sha256-eTyxS0rkjpLEo16uXTS0uVCS4815lc40K2iVpWDvdSY=" crossorigin="anonymous"></script>

