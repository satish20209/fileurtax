<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<style>
  .card{
  height: 550px;
}
.buy-now-a {
    width: 100%;
    background: rgb(155, 1, 101);
    padding: 8px 12px;
    border-radius: 0px;
    position: absolute;
    bottom: 0px;
    left: 50%;
    color: white;
    text-align: center;
    transform: translate(-50%);
}
.buy-now-a:hover{
  background-color:#00204c;
  color: #ffffff;
}
.card-body{
  overflow-y: scroll;
}
/* Hide scrollbar for Chrome, Safari and Opera */
.card-body::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.card-body {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

@media only screen and  (max-width:600px){
  .card{
  height: 430px;
  width: 100%;
  
}


.row{
  padding: 6px !important;
}
}

.price {
    color: rgb(155, 1, 101);
    font-size: 35px;
    text-align: center;
    font-weight: 600;
}
</style>



<div>
  <!-- Page Title -->
  <section class="page-title" style="background-image:url(images/background/1.jpg)">
    <div class="auto-container">
        <h1>PACKAGES</h1>
        <ul class="page-breadcrumb">
          <li><a href="/">Home</a></li>
          <li>Packages</li>
        </ul>
      </div>
  </section>
  <!-- End Page Title -->

  <div class="mb-5 mt-5" token="{{csrf_token()}}">
    <input id='email' class="d-none" type="text" value="{{session('customerAuth')}}">
    <div class="d-flex justify-content-center " style="background: #ffffff;">
        <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist">
              <button class="nav-link active" id="protectyourintellectualporperty-tab" data-bs-toggle="tab" data-bs-target="#registerbusiness" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Register Business</button>
              <button class="nav-link" id="protectyourintellectualporperty-tab" data-bs-toggle="tab" data-bs-target="#protectyourintellectualporperty" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Protect Your Intellectual Porperty</button>
              <button class="nav-link" id="easytaxregistrationsandfilling-tab" data-bs-toggle="tab" data-bs-target="#easytaxregistrationsandfilling" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Easy tax Registrations and Filling</button>
              <button class="nav-link" id="mandatorycompliances-tab" data-bs-toggle="tab" data-bs-target="#mandatorycompliances" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Mandatory Compliances</button>
            </div>
        </nav>
    </div>
   
      <div class="tab-content" id="nav-tabContent" style="background: #e7e5e1;">
        <div class="tab-pane fade show active" id="registerbusiness" role="tabpanel" aria-labelledby="protectyourintellectualporperty-tab">
            <div class="row me-0 p-3 position-relative mr-0">
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3 me-1" >
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services">Pvt. Ltd. Registration</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 999 </p>
                            <p>applicable taxes and Govt. fees extra.</p>
                            <ul class="service-list-packges">
                                <li>DIN and DSC for two Directors</li>
                                <li>Name Approval Certificate</li>
                                <li>Drafting of MoA & AoA</li>
                                <li>Registration fees and stamp duty</li>
                                <li>Company Incorporation Certificate</li>
                                <li>Company PAN and TAN</li>
                                <li>Zero Balance Current Account</li>
                                <li>& more</li>
                            </ul>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3 col me-1" >
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Limited Liability Partnership </h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 1800 </p>
                            <p>applicable taxes and Govt. fees extra.</p>
                            <ul class="service-list-packges">
                                <li>DSC for one director and DIN for up to three directors</li>
                                <li>Drafting of MoA & AoA</li>
                                <li>Registration fees and stamp duty</li>
                                <li>Company Incorporation Certificate</li>
                                <li>Online Accounting Software valid for one year</li>
                                <li>Zero Balance Current Account</li>
                                <li>& more</li>
                            </ul>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3 col me-1" >
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">One Person Company</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 900 </p>
                            <p>applicable taxes and Govt. fees extra.</p>
                            <ul class="service-list-packges">
                                <li>DIN and DSC for the Director</li>
                                <li>Guidance for choosing the company name</li>
                                <li>Name Approval Certificate</li>
                                <li>Company PAN and TAN</li>
                                <li>Drafting of MoA & AoA</li>
                                <li>Registration fees and stamp duty</li>
                                <li>Company Incorporation Certificate</li>
                                <li>Zero Balance Current Account</li>
                                <li>& more</li>
                            </ul>
                            <div >
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3 col " >
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Partnership Firm</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 900 </p>
                            <p>applicable taxes and Govt. fees extra.</p>
                            <ul class="service-list-packges">
                                <li>Guidance on setting up a partnership firm</li>    
                                <li>Drafting Partnership Deed</li>
                                <li>Two rounds of iterations</li>
                                <li>& more</li>
                            </ul>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="tab-pane fade" id="protectyourintellectualporperty" role="tabpanel" aria-labelledby="protectyourintellectualporperty-tab">
            <div class="row p-3 mr-0  position-relative">
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Trademark <br>Registration</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 1799 </p>
                            <ol class="service-list-packges">
                                <li>Make Your Identity to Your Customers</li>
                                <li>Hassle Free Trademark Registration</li>
                                <li>Proper Trademark Class Selection</li>
                                <li>Fast Trademark Registration Process</li>
                                <li>Get Registered Your Company within 24 Hours</li>
                                <li>Best Professional Consultation Regarding Your Trademark</li>
                            </ol>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Trademark <br>Watch</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 899 </p>
                            <ol class="service-list-packges">
                                <li>Ensure Complete Trademark Protection</li>
                                <li>Prevention of Trademark Abuse</li>
                                <li>Constant Monitoring for Trademark Protection</li>
                                <li>Check if Any Other Company Using Your Trademark</li>
                                <li>Sophisticated Tools</li>
                                <li>Expert Team for Trademark Watch</li>
                                <li>Proper Protection of Authetication</li>
                            </ol>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Copyright Registration</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 2999</p>
                            <p>Government fees + applicable taxes and
                                charges extra</p>
                            <ol class="service-list-packges">
                                <li>Your work is your pride, but today it is easier than ever for people</li>
                                <li>to steal your work and use it without your permission.</li>
                                <li>Many creators don’t copyright their work</li>
                                <li>Check if Any Other Company Using Your Trademark</li>
                                <li>because of the hassle. With fileurtax you get the protection without the</li>
                                <li>hassle as
                                    we take</li>
                                <li>care of the entire process for you.</li>
                            </ol>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Patent Registration</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 1999</p>
                            <p>Government fees + applicable taxes and
                                charges extr</p>
                            <ol class="service-list-packges">
                                <li>Inventing something is hard, but protecting your invention can be harder!</li>
                                <li>to steal your work and use it without your permission.</li>
                                <li>Registering and getting a patent is difficult, but not with fileurtax. From patent search</li>
                                <li>Check if Any Other Company Using Your Trademark</li>
                                <li>and listing the different uses of your invention to filing for patent protection,our</li>
                                <li>experts take care of the complicated processes so that you get the due credit for your invention.</li>
                            </ol>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        <div class="tab-pane fade" id="easytaxregistrationsandfilling" role="tabpanel" aria-labelledby="easytaxregistrationsandfilling-tab">
            <div class="row p-3 mr-0 position-relative">
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">GST Registration </h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 299 </p>
                            <p>
                                Get GST registration done for your business easily through fileurtax. Our experts
                                will
                                walk you through the entire process and file for you. We ensure you get your GSTIN
                                at
                                the earliest.
                            </p>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Professional Tax Registration</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 1499 </p>
                            <p class="text-left" style="padding-top: 15px;">Professional life is hard enough, so
                                why
                                bother about the complicated process of professional tax registration when you can
                                get
                                the experts at fileurtax to do it for you?</p>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Income Tax Returns </h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 299 </p>
                            <p class="">
                                Please enquire for pricing*
                                <small>*price depends on the scope of work</small>

                            </p>
                            <p class="text-left" style="padding-top: 15px;">Understanding the latest rules and
                                available exemptions every year to file your tax returns can be nerve-wracking. Or
                                you
                                can get it done effortlessly through fileurtax!</p>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Tds Return </h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 299 </p>
                            <p class="">
                                Please enquire for pricing*
                                <small>*price depends on the scope of work</small>

                            </p>
                            <p class="text-left" style="padding-top: 15px;">An employer or company that has valid
                                TAN
                                - Tax Collection and Deduction Account Number can file for TDS return. Any
                                individual or
                                business who makes a particular payment which is stated under the I-T Act needs to
                                deduct tax at source.</p>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="mandatorycompliances" role="tabpanel" aria-labelledby="mandatorycompliances-tab">
            <div class="row p-3 mr-0 position-relative">
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Maintain YourAccounts</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 599 </p>
                            <ol class="service-list-packges">
                                <li>The Book-keeping and Accounting</li>
                                <li>Basic Financial Consultation</li>
                                <li>Annual Financial Statements</li>
                                <li>Monthly Reports</li>
                                <li>Invoices Designing</li>
                                <li>Taxation Advice</li>
                                <li>Financial Experts Advice</li>
                            </ol>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Annual Compliance Package for Pvt Ltd. company</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 1499 </p>
                            <ol class="service-list-packges">
                                <li>Annual Company Book-keeping</li>
                                <li>Annual Company Accounting</li>
                                <li>Annual Financial Report</li>
                                <li>Annual Financial Consultation</li>
                                <li>Annual Reports</li>
                                <li>Invoices Designing</li>
                                <li>Taxation Advice</li>
                                <li>Financial Experts Advice</li>
                            </ol>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Due Diligence</h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 1599 </p>
                            <ol class="service-list-packges">
                                <li>Accessing Safe Aspects of a Company</li>
                                <li>Safe Accessing Business Aspects</li>
                                <li>Safe Accessing Legal Aspects</li>
                                <li>Safe Accessing Financial Aspects</li>
                                <li>Get Hassle Free Guide</li>
                                <li>Need Not to Rush to Multiple Professionals</li>
                            </ol>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 m-0 p-0 mb-3">
                        <div class="card-header p-3 text-center">
                            <h5 class="hedding-services ">Secretarial Audit Package for Companies </h5>
                        </div>
                        <div class="card-body p-5 pt-2 ">
                            <p class="price">&#8377; 999 </p>
                            <ol class="service-list-packges">
                                <li>A Dedicated Secretariate</li>
                                <li>Secretarial Audit for Your Company</li>
                                <li>Audit for All Company Acts</li>
                                <li>Ensure Company Not Compliant with any Companies Act</li>
                                <li>Reduce the Pressure of Hectic Task for Checking Company Act Compliance</li>
                            </ol>
                            <div>
                                <a href="#" class="buy-now-a">Buy Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
</div>
</div>

<script src="js/package.js"></script>

