
<div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Page Title -->
    <section class="page-title" style="background-image:url(images/background/1.jpg)">
        <div class="auto-container">
            <h1>SIGNIN</h1>
            <ul class="page-breadcrumb">
                <li><a href="/">Home</a></li>
                <li>Signin</li>
            </ul>
        </div>
    </section>
    <!-- End Page Title -->

    <!-- Map Section -->
    <section class="map-section">
        <div class="auto-container">
            <div class="inner-container">
                <!-- Map Boxed -->
                <div class="map-boxed">
                    <!-- Map Outer -->
                    <div class="map-outer">
                        <section class="contact-form-section">
                            <div class="auto-container">
                                <!-- Sec Title -->
                                <div class="sec-title centered">
                                    <h2>Login</h2>
                                </div>
                                <!-- Contact Form -->
                                <div class="contact-form">
                                    <!--Contact Form-->
                                    
                                    <form method="post" action="" id="contact-form">
                                        <div class="row clearfix d-flex justify-content-center">
                                            <div class="col-12 col-md-6  ">
                                                <div class="row">
                                                    <div class="col-md-12 form-group">
                                                        <input type="email" name="email" placeholder="Enter Your Email" class="email" required >
                                                    </div>
                        
                                                    <div class="col-md-12 form-group">
                                                        <input type="password" name="password" placeholder="Enter Your Password" class="password" required>
                                                    </div>
                                                    <div class="col-md-12 text-center mt-1 alert alert-danger erroradminlogin d-none" role="alert">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-lg-12 col-md-12 col-sm-12 form-group text-center ">
                                                <div class="d-flex justify-content-center align-items-center">
                                                    <p class="me-4">Not Registered Yet? <span><a style="color:rgb(0, 0, 0);font-size:17px;" href="register"><b>Register Now</b></a></span></p>
                                                    <p class="me-4" id="resetbtn"><span style="color:rgb(0, 0, 0);font-size:17px;cursor: pointer;"><b>Forgot Password?</b></span></p>
                                                </div>
                                                
                                                <button class="theme-btn btn-style-two userloginbtn" type="button"><span class="txt">Sign In <i class="arrow flaticon-right"></i></span></button>
                                            </div>
                                        </div>
                                        
                                        
                                    </form>
                    
                                    <!--End Contact Form -->
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Map Section -->

   
</div>
{{-- request Otp model --}}
<div class="modal fade " id="resetpasswordmodel" tabindex="1"  data-bs-keyboard="false"  aria-labelledby="BackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-body p-0 m-0">
                <p class="text-white bg-primary p-2 text-center">Enter Your Register Email ID</p>
                <div class="p-3">
                    <form method="POST">
                        <input type="email" id="resetpemail" name="email" placeholder="Enter Your Email" required="">
                            <small class="text-danger notice-emailcode"></small>
                            <div class="d-flex justify-content-end">
                                <button disabled class="btn btn-secondary mt-3" id="requestotp" type="button"><span class="txt">Request OTP</span></button>                                
                            </div>
                    </form> 
                </div>         
            </div>
        </div>
    </div>
</div>
{{-- end request otp model --}}
{{-- enter otp model --}}
<div class="modal fade " id="resetEmailCode" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"  aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-body p-0 m-0">
                <p class="text-white bg-primary p-2 text-center">Check Your Message and E-Mail Inbox</p>
                <div class="p-3">
                    <p class="text-dark"><span>Your Email ID is :- </span> <span class="email-val"></span> </p>
                    <div class="timeinterval">Otp Validated in <span id="time">05:00</span> minutes!</div>
                    <form method="POST">
                        <input class="login-form-input" type="text" id="emailCode" name="emailCode" placeholder="Email Verification code" required="">
                        <input type="password" class="login-form-input mb-2 d-none" id="rpassword" placeholder="Create Password">
                        <input type="password" class="login-form-input d-none" id="rrpassword" placeholder="Confrim Password">
                            <small class="text-danger notice-emailcode"></small>
                            <div class="d-flex justify-content-between">
                                <button class="btn btn-warning mt-3" id="closeotpmodel" type="button"><span class="txt">Close</span></button>
                                <button class="btn btn-primary mt-3" id="submitEmailCode" type="button"><span class="txt">Verify</span></button>
                                <button class="btn btn-primary mt-3 d-none" id="resetpasswordbtn" type="button"><span class="txt">Reset Password</span></button>
                                <button class="btn btn-primary mt-3 d-none" id="resendotp" type="button"><span class="txt">Resend OTP</span></button>
                            </div>
                    </form> 
                </div>         
            </div>
        </div>
    </div>
</div>
{{-- enter otp model --}}

<script>
   

  $("input").on("input",function(){
      $(".erroradminlogin").addClass("d-none");
  })
  // login response 
  $(".userloginbtn").click(function(){
    if($(".email").val() == "" || $(".password").val() == "")
    {

        $(".erroradminlogin").removeClass("d-none");
        $(".erroradminlogin").html("Email Id Or Password Can`t be empty")
    }
    else{
        $.ajax({
      type: "POST",
      url: "/login_l",
      data:{
          '_token': '{{csrf_token()}}',
          email:$(".email").val(),
          password:$(".password").val(),
      },
      dataType: "json",
      beforeSend: function() {
          $(".loader-icon").removeClass('d-none');
      },
          success: function(data, response) {
             
              if(response == "success"){
                  var red = data.response;
                  if('<%= Session["SessionKey"] %>'!=null&&'<%= Session["SessionKey"] %>'!=''){
                    var chktm= parseInt(sessionStorage.getItem("lasttime"))
                   
                        if(chktm <= (chktm+5)){
                            sessionStorage.removeItem('lasttime'); 
                            window.location.href='/packages';
                        }else{
                            window.location.href = "/"+red;

                        }

                  }
              }
          },
          error: function (jqXHR ,response) {
              $(".erroradminlogin").removeClass("d-none");
              $(".erroradminlogin").html(jqXHR.responseJSON.response);                
      }
  });
    }
      
  })
</script>

<script type="text/javascript">
    $("#resetbtn").click(function(){
        $('#resetpasswordmodel').modal('show');
    });

    

    $('#resetpemail').on('input',function(){
                $(".email-error").addClass('d-none');
                $.ajax({
                url: "/check_email",
                type: "get",
                data: {'email':$(this).val()},
                success: function(response) {
                    console.log(response)
                    if(response.status == 400){
                        $(".notice-emailcode").html("Email Not Found Register Please !");
                        $("#requestotp").attr("disabled","disabled");
                        $("#requestotp").removeClass("btn-primary");
                        $("#requestotp").addClass("btn-secondary");
                    }else{
                        $(".notice-emailcode").html("");
                        $("#requestotp").attr("disabled",false);
                        $("#requestotp").removeClass("btn-secondary");
                        $("#requestotp").addClass("btn-primary");
                        $("#requestotp").click(function(){
                            if($("#resetpemail").val().trim() == ""){
                                $(".notice-emailcode").html("Please Enter Your Register Email");
                                }else{
                                    $(".notice-emailcode").html("");
                                    sendemailOTP();
                                }
                        })
                    }
                }
            })
       })






    function startTimer(duration, display) {
        var timer = duration, minutes, seconds;
       var x = setInterval(function () {
            minutes = parseInt(timer / 60, 10);
            seconds = parseInt(timer % 60, 10);
            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;
            display.textContent = minutes + ":" + seconds;
            if (--timer < 0) {
                clearInterval(x);
                deleteotp();
                $("#submitEmailCode").addClass('d-none');
                $("#resendotp").removeClass('d-none');
            }
        }, 1000);
    }
    
    function deleteotp(){
        sessionStorage.clear();
        if(sessionStorage.getItem('emailcode') == null){
               $.ajax({
               url: "/deleteemail",
               type: "get",
               data: {'email':$('#resetpemail').val()}
           })
        }
    
    }
    
    function sendemailOTP(){
        let userEmail = $('#resetpemail').val();
        // alert("call ajax")
        $.ajax({
            url: "/emailVerify",
            type: "POST",
            data: {
                "_token": "{{ csrf_token() }}",
                email: userEmail,
            },
            beforeSend: function(){
                $("#requestotp").html('<span class="txt">Please Wait <i class="fa fa-spinner fa-spin text-white txt" style="font-size:20px"></i>');
            },
            success: function(response) {
                sessionStorage.setItem("emailcode",response.emailcode.code);
                $("#submitEmailCode").removeClass('d-none');
                $("#resendotp").addClass('d-none');
                $('#resetpasswordmodel').modal('hide');
                $('#resetEmailCode').modal('show');
                var fiveMinutes = 60 * 5,
                    display = document.querySelector('#time');
                    startTimer(fiveMinutes, display);
                $("#submitform").html("REGISTER");
                $(".email-val").html($('#resetpemail').val());
                if (response.status == 'Email not registered') {
                } else if (response.status == 'Email Already registered') {
                    $('.email-error').text('Email Already Registered');
                }
            }
        });
    }
       
        $("#editemail").click(function(){
            $('#enterEmailCode').modal('hide');
        });
        $(".submitformregister").click(function(){
            $("#serviceProviderRegistration").submit();
            // $('#successmodel').modal('hide');
            $('#thankyouModalServiceProvider').modal('show');
        });


        $('#submitEmailCode').on('click', function(e) {
        e.preventDefault();
        let emailCode = $('#emailCode').val();
        var emailotp = sessionStorage.getItem("emailcode");
        
        if(emailotp == emailCode)
        {
            $("#submitEmailCode").addClass('d-none');
            $("#emailCode").addClass('d-none');
            $("#resetpasswordbtn").removeClass('d-none');
            $("#rpassword").removeClass('d-none');
            $("#rrpassword").removeClass('d-none');
            $("#resendotp").remove();
            $("#timeinterval").addClass('d-none');
            var emailrest = $(".email-val").html().trim();
            $("#resetpasswordbtn").click(function(){
                if($("#rpassword").val().trim() == $("#rrpassword").val().trim()){
                    $(".notice-emailcode").html('');
                    $.ajax({
                        url: "/updatepassword",
                        type: "POST",
                        data: {
                            "_token": "{{ csrf_token() }}",
                            email: emailrest,
                            password:$("#rpassword").val()
                        },
                        beforeSend: function(){
                            $("#resetpasswordbtn").html('<span class="txt">Please Wait <i class="fa fa-spinner fa-spin text-white txt" style="font-size:20px"></i>');
                        },
                        success: function(response) {
                            if(response.status == 200){
                                $(".notice-emailcode").html('Password Reset Successfull ! You can Login Now');
                                $("#resetpasswordbtn").html('Reset Password');
                                setInterval(function () {
                                    window.location.href = "/login"
                                },3000)
                            }else{
                                $(".notice-emailcode").html('Internal server Error Please Try Again !');
                            }
                            deleteotp();
                        }
                    });
                    }else{
                        $(".notice-emailcode").html("Confrim Password Does Not Match");
                    }
            })
            
            
            
        }else{
            $(".notice-emailcode").html("Email Verification failed check OTP");
        }
    });

    $("#closeotpmodel").click(function(){
        deleteotp();
        window.location.href = "/login";
    });
    </script>