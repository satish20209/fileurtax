<script src="js/popper.min.js"></script>
<style>
    .btn-custom{
        color: rgb(107, 12, 12)!important;
        border: 1px solid rgb(107, 12, 12);
       
    }
    .btn-custom-2{
        color: #f00!important;
        border: 1px solid red;
       
    }
</style>
<div class="p-5">

    <div class="row border border-danger p-4" style="border-radius: 20px;background:rgb(120, 118, 118)">
        <div class="d-flex justify-content-between  align-items-center text-white mb-2">
            <div>
                <h2 class="p-0 m-0">Dashboard</h2>
                <p>Welcome to Fileurtax</p>
            </div>
            <div class="d-flex">
                <div class="me-2">
                    <img  class="profile_pic" alt="service1" style="border-radius: 50%" width="50px" alt="user profile">
                </div> 
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle name" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                      Hello
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                      <li><a class="dropdown-item" href="{{route('serviceProviderlogout')}}">Logout</a></li>
                    </ul>
                  </div>
                  
            </div>
        </div>
        <div class="col border bg-white p-3 mb-3" style="border-radius: 20px">
            <div class="d-flex justify-content-center">
                <img  class="profile_pic" alt="" style="width: 200px" alt="user profile">
            </div>
            <div class="row p-3">
                <div class="col-12 d-flex justify-content-between">
                    <h2>My Profile</h2>
                    <div>

                    </div>
                </div>
                <div class="col-12 d-flex justify-content-between">
                    <div>
                        <h4 class="name"></h4>
                    <hr style="border:2px solid black">
                    </div>
                    <div>
                        <h4 class="mobile"></h4><hr style="border:2px solid black">
                    </div>
                </div>
                <div class="col-12">
                   <p class="email"></p><hr style="border:2px solid black">
                </div>
                <div class="d-flex ">
                    <h6 class="m-0 p-0 me-3 text-danger">SMS alert activation </h6> <input type="checkbox" class="form-checkbox">
                </div>
            </div>
        </div>
        <div class="col ms-3  mb-3" >
            <div class="row " >
                <div class="col-12  p-3 bg-white mb-3" style="border-radius: 20px">
                    <div class="d-flex justify-content-between">
                        <h4><b>Account Setting</b></h4>
                        <div class="d-flex ">
                            <button type="button" class="btn btn-custom text-white edit-serviceprovider-profile">Edit</button>
                        </div>
                    </div>
                    <hr style="border:2px solid black">
                    <div class="d-flex justify-content-between">
                        <h5 class="font-weight-bold">Action</h5>
                        <button class="btn btn-custom text-white">Active</button>
                    </div>
                    <hr style="border:2px solid black">
                    <div class="d-flex justify-content-between mb-2">
                        <h5 class="">Requet Change Email</h5>
                        <div>
                            <button type="button" class="btn btn-custom-2 text-white email-request">Request</button>
                            
                        </div>
                        
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h5 class="">Requet Change Mobile</h5>
                        <div>
                            <button type="button" class="btn btn-custom-2 text-white mobile-request">Request</button>
                        </div>
                    </div>
                </div>

                <div class="col-12  p-3 bg-white mb-5" style="border-radius: 20px">
                    <div class="d-flex justify-content-between mb-2">
                        <h3>My Clints</h3>
                        <input type="search" class="me-3" placeholder="Search">
                    </div>
                   
                    <div class="d-flex justify-content-between mb-2">
                        <h5 class="">Rakesh solanki</h5>
                        <div>
                            <button class="btn btn-custom-2 text-white">Pending</button>
                            <button class="btn btn-custom text-white">Solve</button>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h5 class="">Rakesh solanki</h5>
                        <div>
                            <button class="btn btn-custom-2 text-white">Pending</button>
                            <button class="btn btn-custom text-white">Solve</button>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h5 class="">Rakesh solanki</h5>
                        <div>
                            <button class="btn btn-custom-2 text-white">Pending</button>
                            <button class="btn btn-custom text-white">Solve</button>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h5 class="">Rakesh solanki</h5>
                        <div>
                            <button class="btn btn-custom-2 text-white">Pending</button>
                            <button class="btn btn-custom text-white">Solve</button>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h5 class="">Rakesh solanki</h5>
                        <div>
                            <button class="btn btn-custom-2 text-white">Pending</button>
                            <button class="btn btn-custom text-white">Solve</button>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h5 class="">Rakesh solanki</h5>
                        <div>
                            <button class="btn btn-custom-2 text-white">Pending</button>
                            <button class="btn btn-custom text-white">Solve</button>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


{{-- edit profile model --}}  
  <!-- The Modal -->
  <div class="modal" id="profile-edit">
    <div class="modal-dialog modal-md modal-dialog-centered">
      <div class="modal-content">

        <div class="modal-body">
        <div class="d-flex justify-content-center">
            <img class="update-image" alt="" style="width:180px;border-radius:50%;" alt="user profile">
        </div>
        <input type="file" name="image" id="" class="form-control mb-2 update-image-input"> 
        <input type="text" name="name" id="" class="form-control update-fname mb-2">
        <input type="text" name="name" id="" class="form-control update-lname mb-2">
        </div>
  
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary update-profile-serviceprovider" >Save</button>
        </div>
  
      </div>
    </div>
  </div>