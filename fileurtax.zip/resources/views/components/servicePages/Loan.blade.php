
<div>
  	<!-- Page Title -->
    <section class="page-title" style="background-image:url(images/background/1.jpg)">
    	<div class="auto-container">
			<h1>Loan</h1>
			<ul class="page-breadcrumb">
				<li><a href="/">home</a></li>
				<li>Loan</li>
			</ul>
        </div>
    </section>
    <!-- End Page Title -->
	
		<!-- Welcome Section -->
		<section class="welcome-section style-two">
			<div class="auto-container">
				<div class="inner-container">
					<div class="clearfix">
						
						<!-- Image Column -->
						<div class="image-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="image">
									<img src="images/service/service-1.jpg" alt="clients" />
								</div>
							</div>
						</div>
						
						<!-- Content Column -->
						<div class="content-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<!-- Sec Title -->
								<div class="sec-title">
									<h2>What We Offer</h2>
									<div class="text">We offer you full strategy and how you can get all benefits which government gives toward your business and we will  guide you how you can run your business in systematic way which can give you a good track record and a clean tax file which will be easier for you to expand your business and we will also  pipeline your work to bank so if you need they can also support you to grow</div>
								</div>
								<div class="row clearfix">
									<div class="column col-lg-6 col-md-6 col-sm-6">
										<ul class="list-style-one">
											<li> On time filling</li>
											<li>Correct way to expand</li>
											<li>Banking support</li>
											<li>Investor zone</li>
											<li> Track records</li>
										</ul>
									</div>
									<div class="column col-lg-6 col-md-6 col-sm-6">
										<ul class="list-style-one">
											<li>Tax benefits</li>
											<li>Avoid penalties</li>
											<li>Government scheme benefits</li>
											<li>Latest  technology</li>
											<li>yearly growth</li>
										</ul>
									</div>
								</div>
								<div class="btns-box">
									<a href="bookconsultation" class="theme-btn btn-style-two"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</section>
		<!-- End Welcome Section -->
		
		<!-- Services Page Section -->
		<section class="services-page-section">
			<div class="auto-container">
			
				<!-- Services Block Three -->
				<div class="services-block-three">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="row clearfix">
							<!-- Content Column -->
							<div class="content-column col-lg-6 col-md-12 col-sm-12">
								<div class="inner-column">
									<h2><a href="bookconsultation">Car Loan</a></h2>
									<div class="text">Get the best deals for owning your dream car with faster approvals.</div>
									<a href="bookconsultation" class="theme-btn btn-style-three"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
								</div>
							</div>
							<!-- Image Column -->
							<div class="image-column col-lg-6 col-md-12 col-sm-12">
								<div class="inner-column">
									<div class="image">
										<a href="bookconsultation"><img src="images/service/CarLoan.jpg" alt="clients" /></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Services Block Three -->
				<div class="services-block-three style-two">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="row clearfix">
							<!-- Image Column -->
							<div class="image-column col-lg-6 col-md-12 col-sm-12">
								<div class="inner-column">
									<div class="image">
										<a href="bookconsultation"><img src="images/service/TravelLoan.jpg" alt="clients" /></a>
									</div>
								</div>
							</div>
							<!-- Content Column -->
							<div class="content-column col-lg-6 col-md-12 col-sm-12">
								<div class="inner-column">
									<h2><a href="bookconsultation">Travel Loan</a></h2>
									<div class="text">Visit your dream holiday destination with our affordable Travel loans.</div>
									<a href="bookconsultation" class="theme-btn btn-style-three"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Services Block Three -->
				<div class="services-block-three">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="row clearfix">
							<!-- Content Column -->
							<div class="content-column col-lg-6 col-md-12 col-sm-12">
								<div class="inner-column">
									<h2><a href="bookconsultation">Gold Loan</a></h2>
									<div class="text">Get an instant gold loan with safe and secure loan processing.</div>
									<a href="bookconsultation" class="theme-btn btn-style-three"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
								</div>
							</div>
							<!-- Image Column -->
							<div class="image-column col-lg-6 col-md-12 col-sm-12">
								<div class="inner-column">
									<div class="image">
										<a href="bookconsultation"><img src="images/service/GoldLoan.jpg" alt="clients" /></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Services Block Three -->
				<div class="services-block-three style-two">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="row clearfix">
							<!-- Image Column -->
							<div class="image-column col-lg-6 col-md-12 col-sm-12">
								<div class="inner-column">
									<div class="image">
										<a href="bookconsultation"><img src="images/service/BussLoan.jpg" alt="clients" /></a>
									</div>
								</div>
							</div>
							<!-- Content Column -->
							<div class="content-column col-lg-6 col-md-12 col-sm-12">
								<div class="inner-column">
									<h2><a href="bookconsultation">Business Loan</a></h2>
									<div class="text">Meet your planned or unplanned business expenses with our small business loans.</div>
									<a href="bookconsultation" class="theme-btn btn-style-three"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</section>
		<!-- End Services Page Section -->
		
<!-- Clients Section -->
<section class="clients-section style-two">
	<div class="auto-container">
		<!-- Sec Title -->
		<div class="sec-title centered">
			<h2>TRUSTED COMPANIES</h2>
			<div class="text">For no one hates or runs away from pleasure itself because pleasure is harsh, but because it results in great pain<br> those who do not know how to follow pleasure with reason</div>
		</div>
		<div class="inner-container">
			<div class="sponsors-outer">
				<!--Sponsors Carousel-->
				<ul class="sponsors-carousel owl-carousel owl-theme">
					<li class="slide-item"><figure class="image-box"><a href="https://shivila.com" target="_blank"><img src="images/logo/shivila.jpg" alt="shivila"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Heera goods carrier-logos_black.png" alt="Heera goods carrier-logos_black"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Achyutam enterprise.png" alt="Achyutam enterprise"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Dina distributor-logos_black.png" alt="Dina distributor-logos_black"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Kausturi enterprises-logos.jpeg" alt="Kausturi enterprises-logos"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/KMD.png" alt="KDM"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Mondal Bros-logos_black.png" alt="Mondal Bros-logos_black"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Vish technologies.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Adita traders.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Amit drugs and chemist.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Ayantika institute of technology.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Dayal agriculture.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/G N power and turbo.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/ILAshree marketers.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Krishni chemical.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Podder & sons.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Prabha designers.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Priti hospital.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Shashi properties.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Vaibhavsupplier.png" alt="Vish technologies"></a></figure></li>				
				
				</ul>
				<!--End Sponsors Carousel-->
			</div>
		</div>
	</div>
</section>
<!-- End Clients Section -->
</div>