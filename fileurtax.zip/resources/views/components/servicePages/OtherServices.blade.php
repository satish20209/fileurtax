

<div>
    	<!-- Page Title -->
        <section class="page-title" style="background-image:url(images/background/1.jpg)">
            <div class="auto-container">
                <h1>Services Style 01</h1>
                <ul class="page-breadcrumb">
                    <li><a href="/">home</a></li>
                    <li>Services Style 01</li>
                </ul>
            </div>
        </section>
        <!-- End Page Title -->
        
	<!-- Welcome Section -->
	<section class="welcome-section style-two">
		<div class="auto-container">
			<div class="inner-container">
				<div class="clearfix">
					
					<!-- Image Column -->
					<div class="image-column col-lg-6 col-md-12 col-sm-12">
						<div class="inner-column">
							<div class="image">
								<img src="images/service/service-1.jpg" alt="service" />
							</div>
						</div>
					</div>
					
					<!-- Content Column -->
					<div class="content-column col-lg-6 col-md-12 col-sm-12">
						<div class="inner-column">
							<!-- Sec Title -->
							<div class="sec-title">
								<h2>What We Offer <br> for You</h2>
								<div class="text">Duis aute irure dolor in reprehenderit in volutate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
							</div>
							<div class="row clearfix">
								<div class="column col-lg-6 col-md-6 col-sm-6">
									<ul class="list-style-one">
										<li>Velit esse quam nihilumi</li>
										<li>Qui dolorem eum fugiat</li>
										<li>Aspernatur aut odit aut</li>
										<li>Ratione voluptatem sea</li>
									</ul>
								</div>
								<div class="column col-lg-6 col-md-6 col-sm-6">
									<ul class="list-style-one">
										<li>Nostrum exercitationem</li>
										<li>Reprehenderit qui nulla</li>
										<li>Tempora incidunt utao</li>
										<li>Nihil molestiae conseua</li>
									</ul>
								</div>
							</div>
							<div class="btns-box">
								<a href="bookconsultation" class="theme-btn btn-style-two"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<!-- End Welcome Section -->
	
	<!-- Services Page Section -->
	<section class="services-page-section">
		<div class="auto-container">
		
			<!-- Services Block Three -->
			<div class="services-block-three">
				<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
					<div class="row clearfix">
						<!-- Content Column -->
						<div class="content-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<h2><a href="bookconsultation">Corporate Law</a></h2>
								<div class="text">Temporibus autem quibusdam et aut officiis debitiaut rerum necessitatibus saepe eveniet ut et volutares repudiandae molestiae non earum rerum aic tenetur a sapiente delectus.</div>
								<a href="bookconsultation" class="theme-btn btn-style-three"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
						<!-- Image Column -->
						<div class="image-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="image">
									<a href="bookconsultation"><img src="images/service/service-2.jpg" alt="service" /></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Services Block Three -->
			<div class="services-block-three style-two">
				<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
					<div class="row clearfix">
						<!-- Image Column -->
						<div class="image-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="image">
									<a href="bookconsultation"><img src="images/service/service-3.jpg" alt="service" /></a>
								</div>
							</div>
						</div>
						<!-- Content Column -->
						<div class="content-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<h2><a href="bookconsultation">Real Estate Law</a></h2>
								<div class="text">Temporibus autem quibusdam et aut officiis debitiaut rerum necessitatibus saepe eveniet ut et volutares repudiandae molestiae non earum rerum aic tenetur a sapiente delectus.</div>
								<a href="bookconsultation" class="theme-btn btn-style-three"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Services Block Three -->
			<div class="services-block-three">
				<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
					<div class="row clearfix">
						<!-- Content Column -->
						<div class="content-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<h2><a href="bookconsultation">Insurance Law</a></h2>
								<div class="text">Temporibus autem quibusdam et aut officiis debitiaut rerum necessitatibus saepe eveniet ut et volutares repudiandae molestiae non earum rerum aic tenetur a sapiente delectus.</div>
								<a href="bookconsultation" class="theme-btn btn-style-three"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
						<!-- Image Column -->
						<div class="image-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="image">
									<a href="bookconsultation"><img src="images/service/service-4.jpg" alt="service" /></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Services Block Three -->
			<div class="services-block-three style-two">
				<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
					<div class="row clearfix">
						<!-- Image Column -->
						<div class="image-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="image">
									<a href="bookconsultation"><img src="images/service/service-5.jpg" alt="service" /></a>
								</div>
							</div>
						</div>
						<!-- Content Column -->
						<div class="content-column col-lg-6 col-md-12 col-sm-12">
							<div class="inner-column">
								<h2><a href="bookconsultation">Family Law</a></h2>
								<div class="text">Temporibus autem quibusdam et aut officiis debitiaut rerum necessitatibus saepe eveniet ut et volutares repudiandae molestiae non earum rerum aic tenetur a sapiente delectus.</div>
								<a href="bookconsultation" class="theme-btn btn-style-three"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</section>
	<!-- End Services Page Section -->
</div>