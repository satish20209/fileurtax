@php
$ar=[];
$feed=DB::table('feedback')->paginate(10);
$count=1;

@endphp
Profile		Email	Customer Name		
<div class="" style="margin-top:100px;margin-bottom:100px;">
    <h3 class=" p-2 ps-4 heading rounded m-0">Feedbacks</h3>
      <table  class="  table  table-bordered text-center table-striped">
        <thead class="">
          <tr>
          <th>Sr.</th>
            
            <th scope="col"> Name</th>
            <th scope="col">Email</th>
            <th>Rate</th>
            
            

            <th scope="col" class="change-th">Action</th>
          </tr>
        </thead>
        <tbody class=" ">
          
          @foreach($feed as $req)
         
          
            <tr>
              <td>{{$count}}</td>
              <td>
                {{$req->name}}
              </td>
              <td>
              {{$req->email}}
              </td>
              <td>
              {{$req->rate}}
              </td>
              @if($req->status)
              <td><button value="{{$req->id}}" class="hide_msg  msgs btn btn-success">Show</button><button value="{{$req->id}}" class=" views ms-1 btn btn-info">view</button></td>
              @else
              <td><button  value="{{$req->id}}" class=" allow_msg ms-1 msgs btn btn-info">Hide</button><button value="{{$req->id}}"  class="views  ms-1 btn btn-info">view</button></td>
             @endif
             
            </tr>

            
          @endforeach
          

        </tbody>
      </table>
      {{$feed->links()}}
      
      <!-- Modal for view comment of feedback -->
    <div class="modal fade" id="message" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Feedback Message</h5>
            <button type="button" class="close_btn close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            
          </div>
          <div class="modal-footer">
            <button type="button" class=" close_btn btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
      
   
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
  $(document).ready(function(){
    
    $(".msgs").each(function () {
        $(this).click(function () {
            $.ajax({
                type: "get",
                url: "/change_status_feedback",
                data: { id: $(this).val() },
                dataType: "json",
                beforeSend: function () {
                    $(".loader-icon").removeClass("d-none");
                },
                success: function (a, b) {
                    window.location.href="/adminfeedback";
                },
            });
        });
    });
    $(".views").each(function () {
      $(this).click(function () {
        alert()
          $.ajax({
              type: "get",
              url: "/get_feedback_msg",
              data: { id: $(this).val() },
              dataType: "json",
              beforeSend: function () {
                  $(".loader-icon").removeClass("d-none");
              },
              success: function (a, b) {
                  $(".modal-body").append("<p> " + a.data.message + "</p>"), $("#message").modal("show");
                  $('#message').modal('show');
                },
          });
      });
   })
   $(".close_btn").click(function () {
        $("#message").modal("hide"), $(".modal-body").empty();
    });
})
  
</script>

