<div>
    <div class="row p-0 m-0">
        <div class="card user-btn-fetch text-center shadow" style="" title="Users">
            <div class="card-body ">
                <span class="material-icons" style="font-size: 40px;margin-bottom:8px;color:red">account_circle <span style="font-size:13px;margin-left:-26px;margin-top:-10px;" class="user-count badge bg-dark badge-light">1</span></span>
                <p class="card-tilte ">Customers</p>
            </div>
        </div>
        <div class="card services-btn-fetch text-center shadow" title="Service Providers">
            <div class="card-body ">
                <span class="material-icons" style="font-size: 40px;margin-bottom:8px;color:blue;">group <span style="font-size:13px;margin-left:-26px;margin-top:-10px;" class="serviceprovidercount badge bg-dark badge-light"></span></span>
                <p class="card-tilte">Service Providers</p>
            </div>
        </div>
        <div class="card get_sP_req text-center shadow" title="Service Providers Request">
            <div class="card-body ">
                <span class="material-icons" style="font-size: 40px;margin-bottom:8px;color:orange">rule <span style="font-size:13px;margin-left:-26px;margin-top:-10px;" class="servicerequestcount badge bg-dark badge-light"></span></span>
                <p class="card-tilte">Service Providers Request</p>
            </div>
        </div>
        <div class="card get_feedback shadow text-center">
            <div class="card-body ">
                <span class="material-icons" style="font-size: 40px;margin-bottom:8px;color:rgb(196, 51, 207)">group <span style="font-size:13px;margin-left:-26px;margin-top:-10px;" class="feedbackcount badge bg-dark badge-light"></span></span>
                <p class="card-tilte">Feedbacks</p>
            </div>
        </div>
        
    </div>
</div>
