@php
// users_id
// ticket_id
$help=DB::table('helps')->paginate(5);
$count=1;
@endphp
<div class="" style="margin-top:100px;margin-bottom:100px;">
    <h3 class=" p-2 ps-4 heading rounded m-0">Customers</h3>
      <table  class="  table  table-bordered text-center table-striped">
        <thead class="">
          <tr>
          <th>Sr.</th>
            <th>Profile</th>
            <th scope="col">Name</th>
            <th scope="col">subject</th>
            <th scope="col">Ticket Id</th>
            <th scope="col" class="change-th">requesttype</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody class=" ">
          @foreach($help as $cust)
          @php
            $username = DB::table('members')->where('id',$cust->users_id)->first()->fname;
          @endphp
            <tr>
              <td>{{$count}}</td>
              <td>
                <img src="images/guest-user.png" alt="guest-user" style="width:35px;border-radius:50%;border:2px solid black" />
              </td>
              <td>
                {{$username}}
              </td>
              
              <td>
                {{$cust->subject}}
              </td>
              <td>
                {{$cust->ticket_id}}
              </td>
              <td>
                {{$cust->requesttype}}
              </td>
              <td>
                <button class="btn btn-primary helpview"  custid="{{$cust->users_id}}">View</button> <button class="btn btn-danger" custid="{{$cust->users_id}}">
                  @if ($cust->status == Null)
                  Pendding
                  @else
                  solved
                  @endif
                </button>
                  
                
              </td>
              
            </tr>

            @php
            $count+=1;
            @endphp
          @endforeach
        </tbody>
      </table>
      {{$help->links() }}
      {{-- show model  --}}
      <div class="viewhelpmodal">
      </div>
      {{-- end show model --}}
</div>
