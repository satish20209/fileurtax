<link rel="stylesheet" href="css/blog.css" />
<link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
    />
<link
      href="https://fonts.googleapis.com/css2?family=Poppins&display=swap"
      rel="stylesheet"
    />
    @php
    $blog=DB::table('blogs')->where('id',request()->get('id'))->first();
    @endphp
<div style="margin-top:80px !important;" class="mt-5 m-2">
  
      <div class="options mb-3">
        <!-- Text Format -->
        <button  id="bold" class=" link_btn option-button format">
          <i class="fa-solid fa-bold"></i>
        </button>
        <button id="italic" class=" link_btn option-button format">
          <i class="fa-solid fa-italic"></i>
        </button>
        <button id="underline" class=" link_btn option-button format">
          <i class="fa-solid fa-underline"></i>
        </button>
        <button id="strikethrough" class=" link_btn option-button format">
          <i class="fa-solid fa-strikethrough"></i>
        </button>
        <button id="superscript" class=" link_btn option-button script">
          <i class="fa-solid fa-superscript"></i>
        </button>
        <button id="subscript" class=" link_btn option-button script">
          <i class="fa-solid fa-subscript"></i>
        </button>

        <!-- List -->
        <button id="insertOrderedList" class=" link_btn option-button">
          <div class="fa-solid fa-list-ol"></div>
        </button>
        <button id="insertUnorderedList" class=" link_btn option-button">
          <i class="fa-solid fa-list"></i>
        </button>

        <!-- Undo/Redo -->
        <button id="undo" class=" link_btn option-button">
          <i class="fa-solid fa-rotate-left"></i>
        </button>
        <button id="redo" class=" link_btn option-button">
          <i class="fa-solid fa-rotate-right"></i>
        </button>

        <!-- Link -->
        <button id="createLink" class=" link_btn adv-option-button">
          <i class="fa fa-link"></i>
        </button>
        <button id="unlink" class=" link_btn option-button">
          <i class="fa fa-unlink"></i>
        </button>

        <!-- Alignment -->
        <button id="justifyLeft" class=" link_btn option-button align">
          <i class="fa-solid fa-align-left"></i>
        </button>
        <button id="justifyCenter" class=" link_btn option-button align">
          <i class="fa-solid fa-align-center"></i>
        </button>
        <button id="justifyRight" class=" link_btn option-button align">
          <i class="fa-solid fa-align-right"></i>
        </button>
        <button id="justifyFull" class=" link_btn option-button align">
          <i class="fa-solid fa-align-justify"></i>
        </button>
        <button id="indent" class=" link_btn option-button spacing">
          <i class="fa-solid fa-indent"></i>
        </button>
        <button id="outdent" class=" link_btn option-button spacing">
          <i class="fa-solid fa-outdent"></i>
        </button>

        <!-- Headings -->
        <select  id="formatBlock" class="select_heding adv-option-button">
          <option value="H1">H1</option>
          <option value="H2">H2</option>
          <option value="H3">H3</option>
          <option value="H4">H4</option>
          <option value="H5">H5</option>
          <option value="H6">H6</option>
        </select>

        <!-- Font -->
        <select id="fontName" class="select_name adv-option-button"></select>
        <select id="fontSize" class="select_heding adv-option-button"></select>

        <!-- Color -->
        <div class="input-wrapper">
          <input type="color" id="foreColor" class="adv-option-button" />
          <label for="foreColor">Font Color</label>
        </div>
        <div class="input-wrapper">
          <input type="color" id="backColor" class="adv-option-button" />
          <label for="backColor">Highlight Color</label>
        </div>
      </div>

  
  <form action="updateblog" method="post" enctype="multipart/form-data">
    @csrf
    <input type="text" name="blog_id" hidden value="{{$blog->id}}">
    <div class="row p-0 m-0">
      <div required id="text-input" class="border p-2 rounded col-md-8"   contenteditable="true" ><?php echo $blog->content; ?></div>
      <div class="col-md-4 col-12">
        <div  class="row ">
          
            <div  class="mb-2 col-md-12 col-sm-6">
              <div class=" card" style=" width:100%;">
                <div class="card-body">
                  <h5 class="card-title">Blog Name</h5>
                  <input required class="form-control" value="{{$blog->blogName}}"   name="blog_name" id="" ></input>
                </div>
              </div>
            </div>
            <div  class="mb-2 col-md-12 col-sm-6">
              <div class=" card" style=" width:100%;">
                <div class="card-body">
                  <h5 class="card-title">Title Heading</h5>
                  <textarea required cols="40" rows="5"   style="resize: both;overflow: auto;" name="title_name" id="" cols="" rows="">{{$blog->title}}</textarea>
                </div>
              </div>
            </div>

            <div class="col-md-12 col-sm-6">
              <div class="mb-2  card" style=" width:100%;">
                <div class="card-body">
                  <h5 class="card-title">Upload Thumbnail</h5>
                    <div class="d-flex justify-content-center">
                      <button  type="button" class=" d-none upld_btn w-50 btn btn-secondary">Upload</button>
                      <input  name="thumbnail" hidden type="file" id="image_upload">
                      <div>
                        
                      </div>
                      <div class=" img border border-dark">

                        <span class="close_btn" ><i class="fa-solid fa-remove"></i></span>
                        <img class="img_show" src="/fileurtax/blogs/{{$blog->thumbnail}}"   alt="Blog Thumbnail">
                        
                      </div>
                    
                    </div>
                </div>
              </div>
            </div>

        </div>
      </div>

      <div class="d-flex  mt-2  justify-content-end">
        <button type="submit" style="width: 100px;" class=" btn btn-success " id="clickd">save</button>
      </div>
      
      
    </div>
    <textarea  hidden required name="content" id="textar" cols="30" rows="10"></textarea>

  </form>




</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="js/blog.js"></script>