@php
$role=['CA','CS','CMA','L'];
$consultants=DB::table('members')->whereIn('role', $role)->paginate(5);
$count=1;
@endphp

<div class="" style="margin-top:100px;margin-bottom:100px;">
    <h3 class=" p-2 ps-4 heading rounded m-0">Consultants</h3>
      <table  class="  table  table-bordered text-center table-striped">
        <thead class="">
          <tr>
          <th>Sr.</th>
            <th>Profile</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col" class="change-th">Mobile</th>
          </tr>
        </thead>
        <tbody class=" ">
          @foreach($consultants as $cust)
          
            <tr>
              <td>{{$count}}</td>
              <td>
                <img src="images/guest-user.png" alt="guest-user" style="width:35px;border-radius:50%;border:2px solid black" />
              </td>
              <td>
                {{$cust->fname}}
              </td>
              
              <td>
                <a href="mailto:{{$cust->email}}">{{$cust->email}}</a>
              </td>
              <td>
              <a href="tel:+91{{$cust->mobile}}">{{$cust->mobile}}</a>
              </td>
            </tr>

            @php
            $count+=1;
            @endphp
          @endforeach
          

        </tbody>
      </table>
      {{$consultants->links() }}
      
      
   
</div>

