<link rel="stylesheet" href="css/blog.css" />
<link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
    />
<link
      href="https://fonts.googleapis.com/css2?family=Poppins&display=swap"
      rel="stylesheet"
    />
<div style="margin-top:80px !important;" class="mt-5 m-2">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
  <div>
    @php

   $res=DB::table('blogs')->where('id',request()->get('id'))->first();
   
    @endphp
    
    <div>
        <div class=" d-flex justify-content-center row">
            <div  class="d-flex justify-content-center m-5 col-md-10">
                <h2>{{$res->blogName}}</h2>

            </div>
            <div class="d-flex justify-content-center mb-2  col-md-10">
                <img src="https://fileurtax-jobaroundyou.s3.ap-south-1.amazonaws.com/fileurtax/blogs/{{$res->thumbnail}}"  style="width: 150px;">
            </div>
            <div class="col-md-10">
            <h3>{{$res->title}}</h3>
            </div>
            <div class=" justify-align-center col-md-10">
                <h2> <?php echo $res->content?> </h2>
            </div>

        </div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="js/blog.js"></script>