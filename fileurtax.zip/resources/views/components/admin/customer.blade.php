<div class="" style="margin-top:100px;margin-bottom:100px;">
    <h3 class=" p-2 ps-4 heading rounded m-0">Customers</h3>
      <table  class=" user_tbl table cus-table table-bordered text-center table-striped">
        <thead class="service_pr_head">
          <tr>
            <th scope="col"><img src="images/guest-user.png" alt="user profile" style="width:30px;border-radius:50%;" ></th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col" class="change-th">Mobile</th>
          </tr>
        </thead>
        <tbody class="userdata-display service_pr_body">
          {{-- data update by onclick ajax  --}}
        </tbody>
      </table>
      <table  class="d-none blog_table table cus-table table-bordered text-center table-striped">
      <a href="CreateBlog" type="button" class="CreateBlog d-none  m-3 btn btn-primary">Create Blog</a>
        <thead class="blog_head">
        
          <tr>
            <th scope="col">Sr No</th>
            <th scope="col">Thumbnail</th>
            <!-- <th scope="col"><img src="images/guest-user.png" alt="user profile" style="width:30px;border-radius:50%;" ></th> -->
            <th scope="col">Title Name</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody class="blog_data">
          {{-- data update by onclick ajax  --}}
        </tbody>
      </table>
    <!-- Modal -->
    <div class="modal fade" id="message" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Feedback Message</h5>
            <button type="button" class=" close_btn close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            
          </div>
          <div class="modal-footer">
            <button type="button" class=" close_btn btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
</div>

