@php

$blogs=DB::table('blogs')->paginate(10);
$count=1;
@endphp

<div class="" style="margin-top:100px;margin-bottom:100px;">
    <h3 class=" p-2 ps-4 heading rounded m-0">Blogs</h3>
    <div class="p-2 ps-4">
    <a style="font-size:15px;" href="CreateBlog" class=" btn btn-info">Create Blog</a>
    </div>
      <table  class="  table  table-bordered text-center table-striped">
        <thead class="">
          <tr>
          <th>Sr.</th>
            <th>Profile</th>
            <th scope="col">BLog Name</th>
            <th scope="col">Title</th>
            <th scope="col" class="change-th">Action</th>
          </tr>
        </thead>
        <tbody class=" ">
          @foreach($blogs as $blog)
          
            <tr>
              <td>{{$count}}</td>
              <td>
                <img src="/fileurtax/blogs/{{$blog->thumbnail}}"   alt="Blog Thumbnail" style="width:35px;border-radius:50%;border:2px solid black" />
              </td>
              <td>
                {{$blog->blogName}}
              </td>
              
              <td>
              {{$blog->title}}
              </td>
              <td><a href="/AdminViewBlog?id={{$blog->id}}"  type="button" class="me-2 btn btn-primary">View</a><a href="/AdminEditBlog?id={{$blog->id}}" target="" type="button" class="btn btn-info">Edit</a><a type="button" id="{{$blog->id}}" class="delete_blog ms-2 btn btn-danger">Delete</a></td>
            </tr>

            @php
            $count+=1;
            @endphp
          @endforeach
          

        </tbody>
      </table>
      {{$blogs->links() }}
      
      
   
</div>


