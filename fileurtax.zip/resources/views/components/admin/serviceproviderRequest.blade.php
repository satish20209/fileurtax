@php
$ar=[];
$data= DB::table('services_requests')->where('status',1)->paginate(10);
foreach($data as $val){
    $get_data=DB::table('members')->where('id',$val->service_provider_id)->first();
    if($get_data){
        $cust_data=DB::table('members')->where('id',$val->customer_id)->first();
        array_push($ar, (object) array('accept'=>$val->accept,'service_requests'=>$val->id,'role'=>$get_data->role,'servicePrid' =>$get_data->id,'profileImage' =>$get_data->profileImage,'servicePrname' =>$get_data->fname,'servicePremail' =>$get_data->email,'cust_name' =>$cust_data->fname,'cust_email' =>$cust_data->email));
    }
}
$count=1;

@endphp
Profile		Email	Customer Name		
<div class="" style="margin-top:100px;margin-bottom:100px;">
    <h3 class=" p-2 ps-4 heading rounded m-0">Service Providers Requirement</h3>
      <table  class="  table  table-bordered text-center table-striped">
        <thead class="">
          <tr>
          <th>Sr.</th>
            <th>Profile</th>
            <th scope="col">Service Pr. Name</th>
            <th scope="col">Email</th>
            <th>Customer Name</th>
            <th>Customer Need</th>
            

            <th scope="col" class="change-th">Action</th>
          </tr>
        </thead>
        <tbody class=" ">
          
          @foreach($ar as $req)
          
          
            <tr>
              <td>{{$count}}</td>
              <td>
                <img src="images/guest-user.png" alt="guest-user" style="width:35px;border-radius:50%;border:2px solid black" />
              </td>
              <td>
              {{$req->servicePrname}}
              </td>
              <td>{{$req->servicePremail}}</td>
              
              <td>{{$req->cust_name}}</td>
              <td>{{$req->role}}</td>
              @if(!$req->accept)
              <td><button  value="{{$req->service_requests}}" class="enable btn btn-success test-light">Approve</button></td>
              @else
              <td><button  value="{{$req->service_requests}}" class="desable  btn btn-danger test-light">Disapprove</button></td>
              @endif
             
            </tr>
            @php
            $count+=1;
          @endphp
            
          @endforeach
          

        </tbody>
      </table>
      {{$data->links()}}
      
      
      
   
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
  $(document).ready(function(){
    $('.enable').click(function(){
        $.ajax({
          type: "GET",
          url: "/service_provider_req_status",
          data: { id: $(this).val() },
          dataType: "json",
          beforeSend: function () {
              $(".loader-icon").removeClass("d-none");
          },
          success: function (a, b) {
              window.location.href="/adminviewrequest"
          },
      });
    })
    $('.desable').click(function(){
      $.ajax({
        type: "GET",
        url: "/service_provider_req_status_desable",
        data: { id: $(this).val() },
        dataType: "json",
        beforeSend: function () {
            $(".loader-icon").removeClass("d-none");
        },
        success: function (a, b) {
           window.location.href="/adminviewrequest";
        },
    });
    })
  })
  
</script>

