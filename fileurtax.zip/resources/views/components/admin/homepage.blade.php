<div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid p-3">
          <a class="navbar-brand " style=" font-weight: 600;" href="/"> <span style="font-weight: 600;color: orange">FILE</span>UR<span style="font-weight: 600;color: green">TAX</span> </b></a>
          <button class="navbar-toggler mb-2" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="main-navbar collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mb-2 mb-lg-0 ms-auto">
              <li class="nav-item bg-info rounded">
                <a class="nav-link active " aria-current="page" href="/">Home</a>
              </li>
              <li class="nav-item bg-danger rounded">
                <a class="nav-link" title="logout" href="/logoutAdmin"><span class="text-white material-icons" style="font-size: 20px;">logout</span></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
</div>
