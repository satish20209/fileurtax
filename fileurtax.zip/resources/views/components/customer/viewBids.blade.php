<div class="container">
    <div class="card">
        @php
            $quotationId = request()->get('quotationId');
            $customer = DB::table('members')
            ->where('email',session('customerAuth'))
            ->first();
            $bids = DB::table('bids')
            ->where('id',$quotationId)
            ->first();
        @endphp
        @if ($bids)
            <div class="text-center">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th>Consultant Name</th>
                            <th>Bidding Amount</th>
                            <th>Action</th>
                            
                        </tr>
                        @php
                            $allBids = DB::table('bids')
                            ->where('id',$quotationId)
                            ->orderBy('amount','asc')
                            ->get();
                      @endphp
                        @foreach ($allBids as $allBid)
                            @php
                                $consultant = DB::table('members')
                                ->where('id',$allBid->consultantId)
                                ->first();
                            @endphp
                            <tr>
                                <td>{{$consultant->fname}}</td>
                                <td>₹ {{$allBid->amount}}.00</td>
                                <td>
                                    @php
                                        $requestSent = DB::table('services_requests')
                                        ->where(
                                            [
                                                'customer_id' => $customer->id,
                                                'service_provider_id' => $allBid->consultantId,
                                            ]
                                        )
                                        ->where('status','!=',0)
                                        ->exists();
                                    @endphp
                                    @if ($requestSent)
                                    <button type="button" class="btn btn-success btn-sm" disabled>Request Sent</button>
                                    @else
                                        <form action="serviceRequest" method="POST">
                                            @csrf
                                            <input type="hidden" name="customer_id" value="{{$customer->id}}">
                                            <input type="hidden" name="service_provider_id" value="{{$allBid->consultantId}}">
                                            <button type="submit" class="btn btn-primary btn-sm">Send Request</button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        @else
            <div class="text-center mt-5 mb-5">
                <h5 class="text-danger">No Bids Placed Yet</h5>
            </div>
        @endif
    </div>
</div>