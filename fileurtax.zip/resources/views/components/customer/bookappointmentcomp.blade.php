@php
    $customerDetails = DB::table('members')->where('email',session('customerAuth'))->first();

    $servicerequest = DB::table('services_requests')->where('customer_id',$customerDetails->id)->first();           
@endphp
@if($servicerequest)
@php
 $serviceProviders = DB::table('members')->where('id',$servicerequest->service_provider_id)->first();
@endphp
@if(!$servicerequest->apptime == NULL)
<div class="p-3">
    <h3>Appointment Details</h3>
    <div class="row text-center">
        <div class="col-12">
          <div class="card text-center mt-5 mb-5">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <tr>
                        <th class="bg-primary text-light"> Service Provider Name </th>
                        <td class="srprovider"> {{$serviceProviders->fname}} </td>
                    </tr>
                    <tr>
                      <th class="bg-primary text-light">Customer Name </th>
                      <td class="custsname"> {{$customerDetails->fname}} </td>
                    </tr>
                    <tr>
                        <th class="bg-primary text-light"> Contact Number </th>
                        <td > {{$customerDetails->mobile}} </td>
                    </tr>
                    
                    <tr>
                        <th class="bg-primary text-light"> Email </th>
                        <td> {{$customerDetails->email}} </td>
                    </tr>
                    <tr>
                        <th class="bg-primary text-light"> Appointment Date </th>
                        <td class="appdate"> {{$servicerequest->appdate}}</td>
                    </tr>
                    <tr>
                        <th class="bg-primary text-light"> Appointment Time </th>
                        <td class="apptime"> 
                            {{$servicerequest->apptime}}
                        </td>
                    </tr>
                    <tr>
                        <th class="bg-primary text-light"> Appointment Time Period </th>
                        <td class="timeperiod"> 
                            {{$servicerequest->timeperiod}} Minutes
                        </td>
                    </tr>
                    <tr>
                        <th class="bg-primary text-light"> Appointment Charge </th>
                        <td> 
                            {{$servicerequest->fee}} Rs
                        </td>
                    </tr>
                  
                </table>
              </div>
              
          </div>
        </div>
        <button type="button" class="btn btn-primary bookAppointmenteditbtn">Edit Appointment</button>
    </div>
</div>
@else
<div>
    <h3>Appointment Details</h3>
    <p>No Appointment Booked </p>
    <p>Please Click Book Appointment</p>
</div>
<button type="button" class="btn btn-primary bookAppointmenteditbtn">Book Appointment</button>
@endif
<div class="modal fade" id="bookAppointmenteditmodel" tabindex="-1" aria-labelledby="bookAppointmentmodelLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background: #fc0765">
                <h5 class="modal-title text-white"><b>Book Appointment</b></h5>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="layername">lawyer Name</label>
                    <input type="text" disabled name="layer" id="layername" lid="{{$serviceProviders->id}}" class="form-control" value="{{$serviceProviders->fname}}">
                </div>
                <div class="form-group">
                    <label for="customername">Customer Name</label>
                    <input type="text" disabled name="customer" id="customername" custid="{{$customerDetails->id}}"  class="form-control" value="{{$customerDetails->fname}}">
                </div>
                <div class="form-group">
                    <label for="customername">Select Appointment Date</label>
                    <input type="date" name="customer" required id="appdate" class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Select Appointment Time</label>
                    <input type="time" name="customer" required id="apptime" class="form-control">
                </div>

                <div class="form-group">
                    <label for="customername">Select Time Period </label>
                    <select required name="appointmenttime" id="appointmenttime" style="color: black;width:100%;border-radius:5px;padding:5px;">
                        <option value="15" selected>15 Minutes</option>
                        <option value="30">30 Minutes</option>
                        <option value="60">60 Minutes</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="customername"> Appointment Charge</label>
                    <input type="text" disabled name="feecharge" id="feecharge" class="form-control" value="300">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger bookAppointmentmodelclose" >Cancel</button>
                <button type="button" class="btn btn-primary booknowbtn"  >Update</button>
            </div>
        </div>
    </div>
</div>
@else
    <h5>You can See Appointment After Accept Request by Consutant</h5>
@endif



<script>

    $(document).ready(function(){
        $(".bookAppointmentmodelclose").click(function(){
            $("#bookAppointmenteditmodel").modal('hide');
        });

        $("#appointmenttime").on("change",function(){
            if($("#appointmenttime").val() == "15"){
            $("#feecharge").val("300");
            }
            else if($("#appointmenttime").val() == "30"){
                $("#feecharge").val("600");
            }
            else if($("#appointmenttime").val() == "60"){
                $("#feecharge").val("900");
            }
        })
        

        $(".bookAppointmenteditbtn").click(function(){
            $("#appdate").val($(".appdate").html());
            $("#apptime").val($(".apptime").html());
            $("#bookAppointmenteditmodel").modal('show');
           
        })
    $(".booknowbtn").click(function(){
            var layerid = $("#layername").attr("lid"); 
            var customreid = $("#customername").attr("custid"); 
            if($("#appdate").val() == "" && $("#apptime").val() == ""){
                alert("please fill app filed")
            }
            else{
                $("#bookAppointmentmodel").modal('hide');

                    $.ajax({
                        url: 'bookappointment',
                        type: 'get',
                        data: {
                            '_token': '{{csrf_token()}}',
                            lid:layerid,
                            custid:customreid,
                            appdate:$("#appdate").val(),
                            apptime:$("#apptime").val(),
                            timeperiod:$("#appointmenttime").val(),
                            fee:$("#feecharge").val()
                        },
                        success: function(response) {
                            
                            alert(response.response);
                            $("#bookAppointmenteditmodel").modal('hide');
                            window.location.href = '/bookedappointment';
                        },
                        error: function(error) {
                            
                        },
                    });
                }
        })
    })
</script>