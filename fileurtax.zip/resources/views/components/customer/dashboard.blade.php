@php
    $customerDetails = DB::table('members')->where('email',session('customerAuth'))->first();
@endphp

<div class="row text-center">
    <div class="col-12">
        <h3>Basic Details</h3>
      <div class="card text-center mt-5 mb-5">
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <tr>
                  <th class="bg-primary text-light"> Name </th>
                  <td> {{$customerDetails->fname}} </td>
                </tr>
                <tr>
                    <th class="bg-primary text-light"> Contact Number </th>
                    <td> {{$customerDetails->mobile}} </td>
                </tr>
                <tr>
                    <th class="bg-primary text-light"> Email </th>
                    <td> {{$customerDetails->email}} </td>
                </tr>
                <tr>
                    <th class="bg-primary text-light"> Requirements </th>
                    <td> 
                        @php
                            $customerRequirement = DB::table('customer_requirements')
                            ->where('user_id',$customerDetails->id)
                            ->first();
                        @endphp

                        @if ($customerRequirement)
                            {{$customerRequirement->requirements}}
                        @else
                            No Requirements Mentioned
                        @endif
                    </td>
                </tr>
              
            </table>
          </div>
      </div>
    </div>
</div>

{{-- Customer Requirement Modal --}}
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
            <div class="text-center mb-5">
                <h4>What Type of Service Are You Looking For?</h4>
            </div>
            <form action="updateCustomerReq" method="POST" autocomplete="on" enctype="multipart/form-data">
                @csrf
                <div class="form-group mb-2">
                    <label for="service">Select Services</label>
                    <select required id="service" class="services mb-2" style="color: black;width:100%;border-radius:5px;padding:5px;"  name="services" id="">
                        <option value="L">Lawyer</option>
                        <option value="CA">CA</option>
                        <option value="CS">CS</option>
                        <option value="CMA">CMA</option>
                    </select>
                </div>
                <div class="form-group mb-2">
                    <textarea required class="form-control" name="requirements" id="requirements" maxlength="150" minlength="20" rows="3" placeholder="Requirements/Needs "></textarea>
                </div>
                <div class="form-group mb-5">
                    <label class="lable"  for="Files">Upload Files</label>
                    <input id="Files" required multiple="multiple" type="file" name="files[]" title="upload file"  />
                </div>
                <div class="d-flex justify-content-between mb-5">
                    <div>
                        <input type="submit" class="btn-get btn btn-primary ml-auto" value="submit">
                    </div>
                </div>
            </form>
        </div>
      </div>
    </div>
</div>
{{-- Customer Requirement Modal End --}}




@php
    $serviceRequest = DB::table('services_requests')
    ->where(
        [
            'customer_id' => $customerDetails->id,
            'status'      => 1,
        ]
    )
    ->first();
@endphp

@php
    $customerReq = DB::table('customer_requirements')
    ->where('user_id',$customerDetails->id)
    ->first();
@endphp

{{-- Check Customer Location Enabled or Not --}}

@if ($customerDetails->lat !== NULL)
    @if ($serviceRequest)
        <div class="row text-center">
            <div class="col-md-6 col-xl-4 grid-margin stretch-card">
                @php
                    $serviceProviders = DB::table('members')
                    ->where('id',$serviceRequest->service_provider_id)
                    ->select(DB::raw("members.*,
                    ( 6371 * acos( cos( radians($customerDetails->lat) ) *
                    cos( radians( lat ) )
                    * cos( radians( longt ) - radians($customerDetails->longt)
                    ) + sin( radians($customerDetails->lat) ) *
                    sin( radians( lat ) ) )
                    ) AS distance"))
                    ->first();
                @endphp
                @if($serviceProviders->lat)
                    <div class="card ">
                        <div class="card-body">
                                @if ($serviceProviders->profileImage == NULL)
                                <img src="images/userPic.png" class="serviceProviderProfile" alt="Service Providers Profile Image">
                                @else
                                    <img src="/fileurtax/serviceprovider/{{$serviceProviders->email}}/{{$serviceProviders->profileImage}}" class="serviceProviderProfile" alt="Service Providers Profile Image">
                                @endif
                            <div class="event py-2">
                                <p class="mb-2 font-weight-medium">Name : {{$serviceProviders->fname}}</p>
                                @if ($serviceProviders->role == "L")
                                <p class="mb-1 font-weight-medium">Role : Lawyer</p>
                                @elseif ($serviceProviders->role == "CA")
                                <p class="mb-1 font-weight-medium">Role : CA</p>
                                @elseif ($serviceProviders->role == "CMA")
                                <p class="mb-1 font-weight-medium">Role : CMA</p>
                                @elseif ($serviceProviders->role == "CS")
                                <p class="mb-1 font-weight-medium">Role : CS</p>
                                @endif
                                <p class="text-mute">
                                    @if (round($serviceProviders->distance) == 0)
                                    <p class="mb-2 font-weight-medium">Distance : Within 1 Km</p>
                                    @else
                                    <p class="mb-2 font-weight-medium">Distance : Within {{round($serviceProviders->distance)}} Km </p>
                                    @endif
                                </p>
                                <button type="button" disabled class="btn bg-secondary text-dark mb-2">Request Accepted</button>
                                @php
                                    $servicerequest = DB::table('services_requests')->where('customer_id',$customerDetails->id)->first();
                                    // print_r($servicerequest);
                                @endphp
                                @if($servicerequest->apptime == NULL)
                                <button type="button" lid="{{$serviceProviders->id}}" custid="{{$customerDetails->id}}" layername="{{$serviceProviders->fname}}" customrename="{{$customerDetails->fname}}" class="btn bg-primary text-light bookAppointmentbtn mb-2">Book Appointment</button>
                                @else
                                <button type="button"  class="btn bg-secondary text-dark mb-2">Appointment Booked</button>
                                @endif
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    @else
        <div class="row text-center">
            @if ($customerReq)
                @php
                    $serviceProviders = DB::table('members')
                    ->where('role',$customerReq->parent_service)
                    ->select(DB::raw("members.*,
                    ( 6371 * acos( cos( radians($customerDetails->lat) ) *
                    cos( radians( lat ) )
                    * cos( radians( longt ) - radians($customerDetails->longt)
                    ) + sin( radians($customerDetails->lat) ) *
                    sin( radians( lat ) ) )
                    ) AS distance"))
                    ->orderBy('distance', 'asc')
                    ->get();
                @endphp
                @foreach ($serviceProviders as $serviceProvider)
                    @if($serviceProvider->lat)
                        <div class="col-md-6 col-xl-4 grid-margin stretch-card">
                            {{-- Recent Consultation Bookings --}}
                            <div class="card text-center">
                                <div class="card-body">
                                    @if ($serviceProvider->profileImage == NULL)
                                        <img src="images/userPic.png" class="serviceProviderProfile" alt="Service Providers Profile Image">
                                    @else
                                    <img src="/fileurtax/serviceprovider/{{$serviceProvider->email}}/{{$serviceProvider->profileImage}}" class="serviceProviderProfile" alt="Service Providers Profile Image">
                                    @endif
                                
                                    <div class="event py-3">
                                        <p class="mb-2 font-weight-medium">{{$serviceProvider->fname}}</p>
                                        <p class="text-mute">
                                            @if (round($serviceProvider->distance) == 0)
                                                Within 1 Km
                                            @else
                                                Within {{round($serviceProvider->distance)}} Km
                                            @endif
                                        </p>
                                        <form action="serviceRequest" method="POST">
                                            @csrf
                                            <input type="hidden" name="customer_id" value="{{$customerDetails->id}}">
                                            <input type="hidden" name="service_provider_id" value="{{$serviceProvider->id}}">
                                            @php
                                                $requestExists = DB::table('services_requests')->where(
                                                    [
                                                        'customer_id' => $customerDetails->id,
                                                        'service_provider_id' => $serviceProvider->id,
                                                        'status' => 0
                                                    ]
                                                    )->exists();
                        
                                                    $requestDeny = DB::table('services_requests')->where(
                                                    [
                                                        'customer_id' => $customerDetails->id,
                                                        'service_provider_id' => $serviceProvider->id,
                                                        'status' => -1
                                                    ]
                                                    )->exists();
                                            @endphp
                                            @if (!$requestExists)
                                                @if ($requestDeny)
                                                    <button type="button" class="btn bg-danger text-light">Request Denied</button>
                                                @else
                                                    <button type="submit" class="btn bg-primary text-light">Send Request</button>
                                                @endif
                                            @else

                                                <button type="button" class="btn bg-success text-light">Request Sent</button>
                                            @endif
                                    
                                        </form>
                                    </div>
                                </div>
                            </div>
                            {{-- Recent Consultation Bookings End --}}
                        </div>
                    @endif
                @endforeach
            @endif
        </div>
    @endif
@else
    <div class="row text-center">
        <div class="col">
            <div class="spinner-grow text-primary" role="status"></div>
            <div class="spinner-grow text-secondary" role="status"></div>
            <div class="spinner-grow text-success" role="status"></div>
            <div class="spinner-grow text-danger" role="status"></div>
            <div class="spinner-grow text-warning" role="status"></div>
            <div class="spinner-grow text-info" role="status"></div>
            <div class="spinner-grow text-light" role="status"></div>
            <p>Plaese Enable Your Location to Get Best Lawyer Suggestions</p>
            <button onclick="updateCustomerLocation()" class="btn btn-primary">Enable</button>
        </div>
    </div>

    
    <script>
        function updateCustomerLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showCustomerPosition);
            } else { 
                alert("Geolocation is not supported by this browser.");
            }
        }
        function showCustomerPosition(position) {
            var lat = position.coords.latitude; 
            var longt = position.coords.longitude;
            $.ajax({
                url: 'updateCustomerLocation',
                method: 'POST',
                data: {
                    lat:lat,
                    longt:longt,
                    customer_id:'{{$customerDetails->id}}',
                    _token:'{{csrf_token()}}',
                },
                success:function(status) {
                    window.location.reload();
                },
                error: function(status) {
                    window.location.reload();
                },
            });
            
        }
    </script>
@endif

{{-- book bookAppointment model --}}
<div class="modal fade" id="bookAppointmentmodel" tabindex="-1" aria-labelledby="bookAppointmentmodelLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background: #fc0765">
                <h5 class="modal-title text-white"><b>Book Appointment</b></h5>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="layername">lawyer Name</label>
                    <input type="text" disabled name="layer" id="layername" class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Customer Name</label>
                    <input type="text" disabled name="customer" id="customername"  class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Select Appointment Date</label>
                    <input type="date" name="customer" id="appdate" class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Select Appointment Time</label>
                    <input type="time" name="customer" id="apptime" class="form-control">
                </div>

                <div class="form-group">
                    <label for="customername">Select Time Period </label>
                    <select name="appointmenttime" id="appointmenttime" style="color: black;width:100%;border-radius:5px;padding:5px;">
                        <option value="15" selected>15 Minutes</option>
                        <option value="30">30 Minutes</option>
                        <option value="60">60 Minutes</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="customername"> Appointment Charge</label>
                    <input type="text" disabled name="feecharge" id="feecharge" class="form-control" value="300">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger bookAppointmentmodelclose" >Cancel</button>
                <button type="button" class="btn btn-primary booknowbtn"  >Book Now</button>
            </div>
        </div>
    </div>
</div>


{{-- end book  --}}
    
<script>
    $.ajax({
        url:'checkCustomserRequirement',
        type:'POST',
        data: {
        '_token':'{{csrf_token()}}',
        user_id:'{{$customerDetails->id}}',
        },
        success: function(response) {
            if (response.data == 'Not Found') {
                $('#staticBackdrop').modal('show');
            }
        
        //$('#staticBackdrop').modal('hide'); 
        },
        error: function(error) {
        
        },
    });
</script>

<script>
    $(document).ready(function(){
        $(".bookAppointmentmodelclose").click(function(){
            $("#bookAppointmentmodel").modal('hide');
        });

        $(".bookAppointmentbtn").click(function(){
            var layername = $(this).attr("layername"); 
            var customrename = $(this).attr("customrename"); 
            var layerid = $(this).attr("lid"); 
            var customreid = $(this).attr("custid");
            $("#bookAppointmentmodel").modal('show');
            $("#layername").val(layername);
            $("#layername").attr("lid",layerid);
            $("#customername").attr("custid",customreid);
            $("#customername").val(customrename);
           
        })

        $("#appointmenttime").on("change",function(){
            if($("#appointmenttime").val() == "15"){
            $("#feecharge").val("300");
            }
            else if($("#appointmenttime").val() == "30"){
                $("#feecharge").val("600");
            }
            else if($("#appointmenttime").val() == "60"){
                $("#feecharge").val("900");
            }
        })

        $(".booknowbtn").click(function(){
            var layerid = $("#layername").attr("lid"); 
            var customreid = $("#customername").attr("custid"); 
            if($("#appdate").val() == "" && $("#apptime").val() == ""){
                alert("please fill app filed")
            }
            else{
            $("#bookAppointmentmodel").modal('hide');
            $.ajax({
                url: 'bookappointment',
                type: 'get',
                data: {
                    '_token': '{{csrf_token()}}',
                    lid:layerid,
                    custid:customreid,
                    appdate:$("#appdate").val(),
                    apptime:$("#apptime").val(),
                    timeperiod:$("#appointmenttime").val(),
                    fee:$("#feecharge").val()
                },
                success: function(response) {
                    
                   
                    $("#bookAppointmenteditmodel").modal('hide');
                    window.location.href = "/customerDashboard";
                },
                error: function(error) {
                    
                },
            });
        }
        })
    });
</script>