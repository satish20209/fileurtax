<div class="container">
    <div class="card">
        @php
            $quotations = DB::table('askquotations')
            ->where('email',session('customerAuth'))
            ->first();
        @endphp
        @if ($quotations)
            <div class="text-center">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th>Services</th>
                            <th>Quotation Amount</th>
                            <th>Message</th>
                            <th>Bids</th>
                            
                        </tr>
                        @php
                            $allQuoatations = DB::table('askquotations')
                            ->where('email',session('customerAuth'))
                            ->get();
                      @endphp
                        @foreach ($allQuoatations as $allQuoatation)
                            @php
                                if ($allQuoatation->services == 'L') {
                                $service = 'Lawyer';
                            }elseif ($allQuoatation->services == 'CA') {
                                $service = 'Chartered Accountant';
                            }elseif ($allQuoatation->services == 'CS') {
                                $service = 'Company Secretary';
                            }elseif ($allQuoatation->services == 'CMA') {
                                $service = 'Cost Management Accountant';
                            }
                            @endphp
                            <tr>
                                <td>{{$service}}</td>
                                <td>₹ {{$allQuoatation->quotation_price}}.00</td>
                                <td>{{$allQuoatation->message}}</td>
                                <td><a href="viewBids?quotationId={{$allQuoatation->id}}" class="btn btn-primary btn-sm"><i class="mdi mdi-eye"></i>View Bids</a></td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        @else
            <div class="text-center mt-5 mb-5">
                <h5 class="text-danger">No Quotation Submitted</h5>
                <a href="quotation" target="_blank" class="btn btn-primary btn-sm mt-5">SUBMIT A QUOATION</a>
            </div>
        @endif
    </div>
</div>