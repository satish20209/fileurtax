<nav class="sidebar sidebar-offcanvas dynamic-active-class-disabled" id="sidebar">
    <ul class="nav">
      <li class="nav-item nav-profile not-navigation-link">
        <div class="nav-link">
          <div class="user-wrapper">
            <div class="text-wrapper">
              <p class="profile-name text-capitalize">
                @php
                    $customerDetails = DB::table('members')->where('email',session('customerAuth'))->first();
                $status=0;
                    $user_id = DB::table('members')->where('email',session('customerAuth'))->first('id')->id;
                    $chk_status = DB::table('services_requests')->where('customer_id',$user_id)->first();
                    if($chk_status){
                        $status=$chk_status->status;
                        if($chk_status->status==1){
                            $consl_id= DB::table('services_requests')->where('customer_id',$user_id)->first('service_provider_id')->service_provider_id;
                            $servicep_fname = DB::table('members')->where('id', $consl_id)->first('fname')->fname;
                        }
                    }
                
                @endphp
                {{$customerDetails->fname}}
              </p>
              <div class="dropdown" data-display="static">
                <a href="#" class="nav-link d-flex user-switch-dropdown-toggler" id="UsersettingsDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                  <small class="designation text-muted">Online</small>
                  <span class="status-indicator online"></span>
                </a>
              </div>
            </div>
          </div>
          {{-- <a class="btn btn-primary btn-md" href="{{route('superAdminLogOut')}}">LOG OUT 
            <i class="mdi mdi-logout-variant"></i>
          </a> --}}
        </div>
      </li>
     
      <li class="nav-item">
        <a href="{{route('customerDashboard')}}" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-view-dashboard text-primary"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="customerQuotations" class="nav-link " aria-expanded="" aria-controls="basic-ui">
        <i class="mdi mdi-calendar-edit text-info"></i>
        <span class="menu-title">Quotations</span>
        </a>
        </li>
      
      <li class="nav-item">
        <a href="bookedappointment" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-calendar"></i>
          <span class="menu-title">Appointments</span>
        </a>
      </li>   
      <li class="nav-item">
        <a href="helpcustomerview" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-help-circle text-primary"></i>
          <span class="menu-title">Support</span>
        </a>
      </li>   
      <li class="nav-item">
        <a href="customermakepayment " class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-contactless-payment text-danger"></i> 
          <span class="menu-title">Make Payments</span>
        </a>
      </li>
      <li class="nav-item">
        @if($status)
        <a href="/chat?id=user-{{Crypt::encrypt($user_id)}},cons-{{Crypt::encrypt($consl_id)}}," class="nav-link text-success" aria-expanded="" aria-controls="basic-ui">
        <i class="mdi mdi-chat"></i>
        <span class="menu-title">Chat</span>
        </a>            
        @endif
        </li>
      <li class="nav-item">
        <a href="customerLogOut" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-logout"></i>
          <span class="menu-title">Logout</span>
        </a>
      </li>      
 </ul>
</nav>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
    integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/script.js"></script>
<script src="js/perfect-scrollbar.min.js?cache=<?php echo time(); ?>"></script>
<script src="js/off-canvas.js?cache=<?php echo time(); ?>"></script>
<script src="js/hoverable-collapse.js?cache=<?php echo time(); ?>"></script>
<script src="js/misc.js?cache=<?php echo time(); ?>"></script>
<script src="js/settings.js?cache=<?php echo time(); ?>"></script>