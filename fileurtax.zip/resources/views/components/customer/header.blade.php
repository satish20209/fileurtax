<link rel="stylesheet" href="css/superAdmin/perfect-scrollbar.css?cache=<?php echo time(); ?>">
<link rel="stylesheet" href="css/superAdmin/app.css?cache=<?php echo time(); ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@6.9.96/css/materialdesignicons.css">

<nav class="navbar default-layout col-lg-12 col-12 p-0 d-flex flex-row">
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
      <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
        <span class="mdi mdi-menu"></span>
      </button>
      <ul class="navbar-nav navbar-nav-left header-links">
        <li class="nav-item d-none d-xl-flex">
          <a href="/"><img src="images/logo-cmp.png" class="superAdminLogo" alt="FileUrTax Logo"></a>
        </li>
      </ul>
      <ul class="navbar-nav navbar-nav-right">
        <li class="nav-item nav-itemc ">
          <a class="nav-link bg-dark p-2 rounded" aria-current="page" href="/">Home</a>
        </li>
      </ul>
      <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
        <span class="mdi mdi-menu icon-menu"></span>
      </button>
    </div>
  </nav>