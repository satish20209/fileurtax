<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

@php
    $customerDetails =DB::table('members')->where('email',session('customerAuth'))->first();
@endphp

@php
    $paymentRequests = DB::table('paymentrequest')
                          ->where(
                            [
                              'customerId' => $customerDetails->id,
                              
                            ]
                          )
                          ->first();
    $paymentRequestsExists = DB::table('paymentrequest')
                          ->where(
                            [
                              'customerId' => $customerDetails->id,
                              
                            ]
                            )
                    ->exists();
@endphp
<div>
<div class="row text-center mb-5">
    <div class="col-12">
        <h3> Payment Requests</h3>
    </div>
</div>
</div>
    <div class="row text-center mt-5 d-flex align-items-center mr-auto ml-auto">
    
        @if ($paymentRequestsExists)
                
            @php
                $consultantDetails=DB::table('members')->where('id', $paymentRequests->consultationId)->first();
            @endphp
                
            
                <div class="col col-md-4 col-xl-4 d-flex align-items-center">
                    <div class="card d-flex align-items-center m-3" style="width: 20rem">
                        <div class="card-body d-flex align-items-center">
                            <div class="event py-3">
                                <p class="mb-2 font-weight-medium">Name : {{$consultantDetails->fname}}</p>
                                <p class="mb-2 font-weight-medium">Payment : 1000</p>
                                @if($paymentRequests->status==1 && $paymentRequests->paymentStatus==0)
                                    <div class="text-center">
                                    <input type="hidden" id="cstmrsName" name="customer_id" value="{{$customerDetails->id}}">
                                    <input type="hidden"  id="conslName" name="consultation_id" value="{{$consultantDetails->id}}">    
                                    <button type="button"  class="btn   btn-info paynow  mr-3 w-100">Pay</button>

                                    </div>
                                @elseif($paymentRequests->status==1 && $paymentRequests->paymentStatus==1)
                                    <button type="button" disabled  class="btn   btn-secondary bg-secondary taxt-dark   mr-3 w-100">Success</button>
                                    
                                    @elseif($paymentRequests->status== -1)
                                    <button type="button" disabled  class="btn   btn-secondary bg-secondary taxt-dark   mr-3 w-100">Request calcelled</button>
                                    @else
                                    <div class="text-center">
                                        <form action="acceptConsultantPaymentReq" method="POST">
                                            @csrf
                                            <input type="hidden" name="customer_id" value="{{$customerDetails->id}}">
                                            <input type="hidden"  name="consultation_id" value="{{$consultantDetails->id}}">
                                            <div class="text-center">
                                                <button type="submit"  class="btn   btn-success  mr-3 w-100">accept & Pay</button>
                                                
                                            </div>
                                        </form>
                                    
                                    </div>
                                    <div class="mt-2 mb-2 text-center">
                                        <form action="denyConsultantPaymentReq" method="POST">
                                            @csrf
                                            <input type="hidden"  name="customer_id" value="{{$customerDetails->id}}">
                                            <input type="hidden"  name="consultation_id" value="{{$consultantDetails->id}}">
                                            <div class="text-center">
                                                
                                                <button type="submit"  class="btn  btn-danger test-light  mr-3 w-100">Deny</button>
                                            </div>
                                        </form>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                @else
            
                <div class="text-center NotAvailable">
                    <p class="text-mute">You Have't any requests</p>
                </div>
        @endif
  </div>
  <script>
    $(document).ready(function(){
        $('.paynow').click(function(){    

                    new Razorpay({
                        key: "rzp_live_6hXmEuiPgjqSaA",
                        amount: 100 * 1000,
                        currency: "INR",
                        name: "Acme Corp",
                        description: "Test Transaction",
                        image: "https://image.freepik.com/free-vector/logo-sample-text_355-558.jpg",
                        handler: function (a) {
                            jQuery.ajax({
                                type: "get",
                                url: "customer_payment",
                                data: "txn_id=" + a.razorpay_payment_id + "&payment_id=" + $('#cstmrsName').val() + "&amt=" + 1000 + "&cnslId=" + $('#conslName').val(),
                                success: function (data, response) {  
                                    window.location.href="/customermakepayment";                              
                                },
                            });
                        },
                    }).open();
                
            // });
        })
        
    })
        
  </script>