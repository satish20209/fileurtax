@php
    $cmaDetails =DB::table('members')
    ->where('email',session('cmaAuth'))
    ->first();
@endphp

@php
//---------------|-------------//
//   Status      |  Code      //
//---------------|-----------//
//   Sent        |  0       //
//---------------|---------//
//   Accepted    |  1     //
//---------------|-------//
//   Denied      |  -1  //
//---------------|-----//

    $serviceRequests = DB::table('services_requests')
    ->where(
            [
                'service_provider_id' => $cmaDetails->id,
                'status' => '0',
            ]
        )
    ->get();

    $serviceRequestsExists = DB::table('services_requests')
    ->where(
            [
                'service_provider_id' => $cmaDetails->id,
                'status' => '0',
            ]
        )
    ->exists();
@endphp
<div class="text-center mb-5">
    <h3>All Service Requests</h3>
</div>





  <div class="row text-center mt-5 mr-auto ml-auto">
            {{-- Recent Consultation Bookings --}}
            @if ($serviceRequestsExists)
                @foreach ($serviceRequests as $serviceRequest)
                @php
                    $customers = DB::table('members')->where('id',$serviceRequest->customer_id)->first();
                    $requirement = DB::table('customer_requirements')->where('user_id',$serviceRequest->customer_id)->first();
                @endphp
                <div class="col col-md-4 col-xl-4 d-flex align-items-center">
                <div class="card text-center m-3">
                    <div class="card-body">
                        <div class="event py-3">
                            <p class="mb-2 font-weight-medium">Name : {{$customers->fname}}</p>
                            <p class="mb-2 font-weight-medium">Requirements : {{$requirement->requirements}}</p>
                            <div class="d-flex align-items-center">
                                <form action="cmaAcceptRequest" method="POST">
                                    @csrf
                                    <input type="hidden" name="service_provider_id" value="{{$cmaDetails->id}}">
                                    <input type="hidden" name="customer_id" value="{{$customers->id}}">
                                    <button type="submit" class="btn btn-success text-light mr-3">Accept</button>
                                </form>
                                <form action="cmaDenyRequest" method="POST">
                                    @csrf
                                    <input type="hidden" name="service_provider_id" value="{{$cmaDetails->id}}">
                                    <input type="hidden" name="customer_id" value="{{$customers->id}}">
                                    <button type="submit" class="btn btn-danger text-light mr-3">Deny</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            
                @endforeach
            @else
                <div class="text-center NotAvailable">
                    <p class="text-mute">No Service Request Recieved</p>
                </div>
            @endif

            {{-- Recent Consultation Bookings End --}}
    
  </div>

  
  
  