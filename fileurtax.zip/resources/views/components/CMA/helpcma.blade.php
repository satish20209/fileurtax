<div class="p-2">
    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="p-3 bg-white shadow">
                <h3 class="text-center">Create Ticket</h3>
                <form action="/helpcustomer" method="post">
                    @csrf

                    <input required type="hidden" name="ticket_id" value="{{ rand(000000,999999) }}">
                    <input required type="hidden" name="users_id" value="{{ session('cmaAuth') }}">
                    <div class="mb-3">

                        <label for="subject" class="form-label">Subject</label>
                        <input required type="text" class="form-control" name="subject" id="subject" placeholder="Subject">
                    </div>
                    <select required class="form-select" name="requesttype" aria-label="Default select example" style="color: black;width:100%;border-radius:5px;padding:5px;">
                        <option value="">Request Type</option>
                        <option value="Service Provider">Service Provider</option>
                        <option value="Admin">Admin</option>
                    </select>
                    <div class="mb-3">
                        <label for="Description" class="form-label">Description</label>
                        <textarea rows="3" required class="form-control" maxlength="240" minlength="50" name="description" id="Description" rows="1"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            
        </div>
        <div class="col-md-1"></div>
        <div class="col-md-7 bg-white shadow mb-3">
            <div class="p-3">
                <h3 class="text-center mb-2">Your Tickets</h3>
                @php
                    $userdata = DB::table('members')->where('email',session('cmaAuth'))->first('id');
                    $data = DB::table('helps')->where('users_id',$userdata->id)->get();
                @endphp
                <div class="row">
                @foreach ($data as  $value)
                    <div class="col-md-6 mb-3">
                        <div class="card w-100">
                            <div class="card-body">
                                <p><b>Subject : </b> {{ $value->subject }}</p>  
                                <p><b>Description : </b>{{ $value->description }} </p> 
                                <p><b>Request To : </b> {{ $value->requesttype }}</p>
                                <p><b>Status : </b>
                                @if ($value->status == null)
                                <button type="button" disabled class="btn btn-info">pending</button>
                                @else
                                <button type="button" disabled class="btn btn-success">Solved</button>
                                @endif
                                </p>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){
    toastr.options.timeOut = 10000;
    @if (Session::has('error'))
          toastr.error('{{ Session::get('error') }}');
    @elseif(Session::has('success'))
          toastr.success('{{ Session::get('success') }}');
    @endif
 });
</script>