    {{-- <div class="fluid-container footerWrap">
        <footer class="footer">
            <h4 class="firstRow">All Right Reserved. Developed By <a href="https://shivila.com/" target="_blank">Shivila Technologies</a> </h4>
    
            <h5 class="secondRow">Copyright © Shivila Technologies Private Limited, 2022. Use of our products is governed by our Privacy Policy.</h5>
        </footer>
        {{-- <div class="container text-center">
            <p class="footerCopyright">COPYRIGHT {{date('Y')}} @ SHIVILA PRIVATE LIMITED</p>
        </div> 
    </div> --}}
    <script>
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");
        let mobileMenuBar = document.querySelector("#mobileMenuBar");
        let mobileMenu = document.querySelector("#mobileMenu");
        let mobileMenuWrap = document.querySelector(".mobileMenuWrap");

        closeBtn.addEventListener("click", ()=>{
        sidebar.classList.toggle("open");
        menuBtnChange();//calling the function(optional)
        });
        mobileMenuBar.addEventListener("click", ()=>{
        mobileMenuWrap.classList.toggle("open");
        controllMenu();//Controll Mobile Menu
        });
        // following are the code to change sidebar button(optional)
        function menuBtnChange() {
            if(sidebar.classList.contains("open")){
                closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the icons class
            }else {
                closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the icons class
            }
        }
        //Controll Mobile Menu
        function controllMenu() {
            if (mobileMenuWrap.classList.contains("open")) {
                mobileMenuWrap.style.display = "block";
            }else {
                mobileMenuWrap.style.display = "none";
            }
        }
    </script>
    <script>
        document.querySelector('.ProfilePic').addEventListener('click', function() {
        document.querySelector('.ProfileCard').classList.toggle('active');
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>