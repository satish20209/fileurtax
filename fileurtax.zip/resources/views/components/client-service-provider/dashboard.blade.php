<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
    function getServiceProviderLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition);
        } else { 
            alert("Geolocation is not supported by this browser.");
        }
    }
    function showPosition(position) {
        var lat = position.coords.latitude; 
        var longt = position.coords.longitude;
        $.ajax({
            url: 'serviceProviderLocation',
            method: 'POST',
            data: {
                lat:lat,
                longt:longt,
                _token:'{{csrf_token()}}',
            },
            success:function(status) {
               
            },
        });
        
    }
</script>
@php
    $location_check = DB::table('service_provider_clients')
                        ->where('id',session('session_service_provider'))
                        ->first();
    if ($location_check->lat === NULL || $location_check->longt === NULL) {
        echo '<script>getServiceProviderLocation()</script>';
        // $lat = 
        // $update_location = DB::table('service_provider_clients')
        // ->where('id',session('session_service_provider'))
        // ->update(
        //     [
        //         'lat' => '<script>lat</script>',
        //         'longt' => '<script>longt</script>',
        //     ]
        // );
    }
   
@endphp
<div class="container-fluid">
    <div class="container text-center">
        <div class="row serviceProviderProfile shadow">
            <h5>Welcome Back</h5>
            @php
                $serviceProvider = DB::table('service_provider_clients')
                                    ->where('id',session('session_service_provider'))
                                    ->first();
                $serviceDetails = DB::table('child_services')
                                    ->where('id',$serviceProvider->services)
                                    ->first();
            @endphp
            <h4>{{$serviceProvider->fname}} {{$serviceProvider->lname}}</h4>
            <h4>{{$serviceDetails->childService}}</h4>
        </div>

        <div class="row mt-5">
            <div class="col-md-7 recentServicesWrap shadow border">
                <div>
                    <h5>RECENT SERVICES</h5>
                    <div class="row mt-5">
                        @php
                            $serviceDetails = DB::table('users')
                                ->where('serviceProvider',session('session_service_provider'))
                                ->orderBy('id','DESC')
                                ->take(2)
                                ->get();
                        @endphp
                                <div class="table-responsive">
                                    <table class="table table-responsive-sm table-bordered border-primary">
                                        <tr>
                                            <th>Client Name</th>
                                            <th>Client Email</th>
                                            <th>Client Contact</th>
                                            <th>View Details</th>
                                        </tr>
                                        @if ($serviceDetails->count() > 0)
                                        @foreach ($serviceDetails as $serviceDetail)
                                            <tr>
                                                <td>
                                                    @if ($serviceDetail->name)
                                                        <p class="clientName">{{$serviceDetail->name}}</p>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($serviceDetail->email)
                                                        <p class="clientEmail">{{$serviceDetail->email}}</p>
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($serviceDetail->mobile)
                                                        <p class="clientPhone">{{$serviceDetail->mobile}}</p>
                                                    @endif
                                                </td>
                                                <td>
                                                    <a href="/serviceId={{$serviceDetail->id}}" class="btn serviceDetailsBtn">Details</a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </table>
                                </div>
                        @else
                            <div class="col text-center text-danger">
                                <p class="mt-5">No Services Available For Now</p>
                            </div>
                        @endif
                    </div>
                    <div class="row mb-3 text-center">
                        <a href="{{route('services')}}" class="btn primaryBtn">CHECK ALL SERVICES</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 recentUpdateWrap">
                <h5>RECENT UPDATES</h5>
                <div class="row mt-5">
                    @php
                        $recentUpdates = DB::table('service_updates')
                        ->where('serviceProviderId', session('session_service_provider'))
                        ->orderBy('id','DESC')
                        ->take(3)
                        ->get();
                    @endphp
                    @if ($recentUpdates->count() > 0)
                        @foreach ($recentUpdates as $recentUpdate)
                            <div class="recentUpdates">
                                <div class="row">
                                    <div class="col-sm-2">
                                        <img src="images/userPic.png" class="recentUpdatePic" alt="user Pic">
                                    </div>
                                    <div class="col-sm-7">
                                        @if ($recentUpdate->status == '1')
                                            <p>Next Date</p>
                                        @endif
                                        @if ($recentUpdate->status == '2')
                                            <p>Pending Upto</p>
                                        @endif
                                        <p>{{$recentUpdate->date}}</p>
                                    </div>
                                    <div class="col-sm-2">
                                        <a class="btn recentUpdateBtn align-middle" href="serviceId={{$recentUpdate->userId}}#id{{$recentUpdate->id}}">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
                                                <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div class="recentUpdates">
                            <div class="row">
                                <p>No Updates Avaiable for Now</p>
                            </div>
                        </div>
                    @endif
                </div>
                <div class="row text-center">
                    <a href="{{route('allUpdates')}}" class="btn primaryBtn">CHECK ALL UPDATES</a>
                </div>
            </div>
        </div>
    </div>
</div>