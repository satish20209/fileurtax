<div class="container-fluid serviceProviderTopbar">
    <div class="container topbarWrap">
        <div class="row">
            <div class="col-md-1 mobileMenuBar">
                <svg id="mobileMenuBar" xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="blue" class="bi bi-list" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
                </svg>
            </div>
            <div class="col-md-10 text-center topbarLogo">
                <div>
                    <a href="{{route('dashboard')}}">
                        <img src="images/logo-cmp.png" alt="company logo" class="companyLogo">
                    </a>
                </div>
            </div>
            <div class="col-md-1">

            </div>
        </div>
    </div>
</div>
<div class="container-fluid mobileMenuWrap serviceProviderTopbar">
    <div class="container topbarWrap mobileMenuDiv">
        <div class="row">
            <div class="col mobileMenu text-center" id="mobileMenu">
                <a href="{{route('dashboard')}}" class="mobileMenuItemLink">
                    <div class="mobileMenuItem">
                        Dashboard
                    </div>
                </a>
                <a href="{{route('services')}}" class="mobileMenuItemLink">
                    <div class="mobileMenuItem">
                        Services
                    </div>
                </a>
                <a href="{{route('allUpdates')}}" class="mobileMenuItemLink">
                    <div class="mobileMenuItem">
                        Updates
                    </div>
                </a>
                <a href="dashboard" class="mobileMenuItemLink">
                    <div class="mobileMenuItem">
                        Profile
                    </div>
                </a>
                <a href="dashboard" class="mobileMenuItemLink">
                    <div class="mobileMenuItem">
                        Support
                    </div>
                </a>
                <a href="{{route('serviceProviderlogout')}}" class="mobileMenuItemLink">
                    <div class="mobileMenuItem">
                        Log Out
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>
