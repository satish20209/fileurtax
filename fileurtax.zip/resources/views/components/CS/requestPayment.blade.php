@php
    $csDetails =DB::table('members')->where('email',session('csAuth'))->first();
@endphp

@php
    $serviceRequests = DB::table('services_requests')
                          ->where(
                            [
                              'service_provider_id' => $csDetails->id,
                              'status' => '1',
                            ]
                          )
                          ->orderBy('id','desc')
                          ->get();
    $serviceRequestsExists = DB::table('services_requests')
                                ->where(
                                    [
                                        'service_provider_id' => $csDetails->id,
                                        'status' => '1',
                                    ]
                                        )
                                ->exists();
                                
@endphp
<div class="row text-center mb-5">
    <div class="col-12">
        <h3>All Payment Requests</h3>
    </div>
</div>





  <div class="row text-center mt-5 d-flex align-items-center mr-auto ml-auto">
            {{-- Recent Consultation Bookings --}}
            @if ($serviceRequestsExists)
                @foreach ($serviceRequests as $serviceRequest)
                @php
                    $customers = DB::table('members')->where('id',$serviceRequest->customer_id)->first();
                    $requirement = DB::table('customer_requirements')->where('user_id',$serviceRequest->customer_id)->first();
                    $paymentRequest=DB::table('paymentrequest')->where('customerId',$customers->id)->first();
                @endphp
                @php
                $paymentsts="";
                if ($paymentRequest) {
                    if($paymentRequest->status==0){
                        $disable = 'disabled';
                        $value="Request Sent";
                        $btn="btn-success text-light";
                    }else if($paymentRequest->status==1){
                        $paymentsts="Pending";
                        $disable = 'disabled';
                        $value="Accepted";
                        $btn="bg-secondary text-dark";
                    }else{
                        
                        $disable = 'disabled';
                        $value="Request Rejected";
                        $btn="bg-secondary text-dark ";
                    }
                    if($paymentRequest->paymentStatus==1){
                        $paymentsts="success";
                    }
                }else{
                        $disable = '';
                        $value="Send Request";
                        $btn="btn-primary text-light";
                    }
                @endphp
                <div class="col col-md-4 col-xl-4 d-flex align-items-center">
                    <div class="card d-flex align-items-center m-3" style="width: 20rem">
                        <div class="card-body d-flex align-items-center">
                            <div class="event py-3">
                                <p class="mb-2 font-weight-medium">Name : {{$customers->fname}}</p>
                                <p class="mb-2 font-weight-medium">Requirements : {{$requirement->requirements}}</p>
                                <div class="text-center">
                                <form action="CSRequestPayment" method="POST">
                                    @csrf
                                    <input type="hidden" name="customer_id" value="{{$customers->id}}">
                                    <input type="hidden" name="consultation_id" value="{{$csDetails->id}}">
                                    <div class="text-center">
                                        <button type="submit" {{$disable}} class="btn   {{$btn}}  mr-3 w-100">{{$value}}</button>
                                    </div>
                                </form>
                                </div>
                                @if($paymentsts)
                                <p class=" mt-2 mb-2 font-weight-medium">Payment Status : {{$paymentsts}}</p>
                                @endif
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
                
                @endforeach
            @else
                <div class="text-center NotAvailable">
                    <p class="text-mute">When You have coustomer the you can request for payment</p>
                </div>
            @endif

            {{-- Recent Consultation Bookings End --}}
        
   
   

    
  </div>

  
  
  