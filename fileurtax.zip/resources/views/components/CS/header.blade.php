<link rel="stylesheet" href="css/superAdmin/perfect-scrollbar.css?cache=<?php echo time(); ?>">
<link rel="stylesheet" href="css/superAdmin/app.css?cache=<?php echo time(); ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@6.9.96/css/materialdesignicons.css">

@php
    $csDetails =DB::table('members')
    ->where('email',session('csAuth'))
    ->first();
@endphp 

<div class="preloader">
  <div class="main-box-div">
      <div class="row">
      <div class="col-md-12">
          <div class="loader">
              <span class="loader-inner text-dark"><b><span style="color: #eb6c18">FILE</span><span>UR</span><span style="color: green">TAX</span> </b></span>
          </div>
      </div>
  </div>
  </div>
</div>

<nav class="navbar default-layout col-lg-12 col-12 p-0 d-flex flex-row">
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
      <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
        <span class="mdi mdi-menu"></span>
      </button>
      <ul class="navbar-nav navbar-nav-left header-links">
        <li class="nav-item d-none d-xl-flex">
          <a href="/" class="text-decoration-none">
            <img src="images/logo-cmp.png" class="superAdminLogo" alt="FileUrTax Logo">
          </a>
        </li>
      </ul>
      <ul class="navbar-nav navbar-nav-right invisible">
        <li class="nav-item nav-itemc ">
          <a class="nav-link bg-dark p-2 rounded" aria-current="page" href="/">Home</a>
        </li>
        


        <li class="nav-item dropdown">
          <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
            <i class="mdi mdi-bell-outline"></i>
            <span class="count bg-success">4</span>
          </a>
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list pb-0" aria-labelledby="notificationDropdown">
            <a class="dropdown-item py-3 border-bottom">
              <p class="mb-0 font-weight-medium float-left">4 new notifications </p>
              <span class="badge badge-pill badge-primary float-right">View all</span>
            </a>
            <a class="dropdown-item preview-item py-3">
              <div class="preview-thumbnail">
                <i class="mdi mdi-alert m-auto text-primary"></i>
              </div>
              <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal text-dark mb-1">Application Error</h6>
                <p class="font-weight-light small-text mb-0"> Just now </p>
              </div>
            </a>
            <a class="dropdown-item preview-item py-3">
              <div class="preview-thumbnail">
                <i class="mdi mdi-settings m-auto text-primary"></i>
              </div>
              <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal text-dark mb-1">Settings</h6>
                <p class="font-weight-light small-text mb-0"> Private message </p>
              </div>
            </a>
            <a class="dropdown-item preview-item py-3">
              <div class="preview-thumbnail">
                <i class="mdi mdi-airballoon m-auto text-primary"></i>
              </div>
              <div class="preview-item-content">
                <h6 class="preview-subject font-weight-normal text-dark mb-1">New user registration</h6>
                <p class="font-weight-light small-text mb-0"> 2 days ago </p>
              </div>
            </a>
          </div>
        </li>

        
        <li class="nav-item dropdown d-none d-xl-inline-block">
          <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
            <span class="profile-text d-none d-md-inline-flex">{{$csDetails->fname}} </span>
            
            
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
            <a class="dropdown-item mt-2"> View Profile </a>
            <a class="dropdown-item"> Change Password </a>
            <a href="" class="dropdown-item"> Sign Out </a>
          </div>
        </li>
      </ul>
      <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
        <span class="mdi mdi-menu icon-menu"></span>
      </button>
    </div>
  </nav>