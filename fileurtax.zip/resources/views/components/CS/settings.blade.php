<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../css/jquery-ui.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/materialize.min.css?cache=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/responsive.css?cache=<?php echo time(); ?>">
    <script src="js/comman_cities.js"></script>

    @php
if(session()->has('csAuth')){
    $consultantId = DB::table("members")->where('email',session('csAuth'))->first('id')->id;
    $consultant = DB::table('members')
    ->where('id',$consultantId)
    ->first();
    $consultantDetails = DB::table('serviceprovidercs')
      ->where('userId',$consultantId)
      ->first();
    
}
@endphp
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card shadow text-center p-3">
            
              @if ($consultant->profileImage == NULL)
              <img class=" img-account-profile img-xs consultantProfilePic rounded-circle" src="images/userPic.png" alt="Profile image"> </a>
              @else
              <img class="img-account-profile consultantProfilePic" src="/fileurtax/serviceprovider/{{$consultant->email}}/{{$consultant->profileImage}}" alt="Profile image"> </a>
              @endif
              <button style="margin-left:25%"; class="mt-2  w-50  buttonProfile btn btn-primary" type="button">Upload new image</button>
               
            </div>
        </div>
        <div class="col-md-8">
            <div class="card shadow consultantProfileDetails">
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active bg-light" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Personal Details</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link bg-light" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Professional Details</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link bg-light" id="documents-tab" data-bs-toggle="tab" data-bs-target="#documents" type="button" role="tab" aria-controls="documents" aria-selected="false">Documents</button>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">
                {{-- Personal Details --}}
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                  <form action="update_cs_1" method="post" enctype="multipart/form-data">
                    @csrf
                    <input hidden  type="file" name="picture" id="layerProfile">
                    <div class="row">
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input name="fname" class="fname input__field" type="text" value="{{$consultant->fname}}" placeholder=" " />
                          <span class="input__label">Full Name </span>
                      </label>
                        
                        <!-- <span class="consultantDetailsHeading badge text-light">NAME</span>
                        <p class="mx-3 consultantDetails">{{$consultant->fname}}</p> -->
                      </div>
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input disabled  class="email input__field" type="text" value="{{$consultant->email}}" placeholder=" " />
                          <span class="input__label">EMAIL </span>
                      </label>
                        <!-- <span class="consultantDetailsHeading badge text-light">EMAIL</span>
                        <p class="mx-3 consultantDetails">{{$consultant->email}}</p> -->
                      </div>
                    </div>
                    <div class="row">
                      @if($consultantDetails)
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input name="pancard"  class="pan_card input__field" type="text" value="{{$consultantDetails->pancard}}" placeholder=" " />
                          <span class="input__label">PAN CARD</span>
                      </label>
                      </div>
                    
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input name="aadhar_card" class="aadhar_card input__field" type="text" value="{{$consultantDetails->aadhaarcard}}" placeholder=" " />
                          <span class="input__label">AADHAR CARD</span>
                      </label>
                      </div>
                      @endif
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                      <label class="input fnamelabel field w-100 mt-4">
                          <input disabled name="mobile"  class="mobile input__field" type="text" value="{{$consultant->mobile}}" placeholder=" " />
                          <span class="input__label">MOBILE NO.</span>
                      </label>
                        <!-- <span class="consultantDetailsHeading badge text-light">MOBILE NO.</span>
                        <p class="mx-3 consultantDetails">{{$consultant->mobile}}</p> -->
                      </div>
                      @if($consultant->gender)
                      <div class="col-md-6">
                      <label class="input practincingSincelabel field w-100 mt-5">
                            <select name="gender" class="gender input__field" type="text"  placeholder=" ">
                                <option value="">Select Gender</option>
                            @php
                                $temp=["male","female"];
                                foreach($temp as $val){
                                    if($consultant->gender==$val){
                                        echo '<option selected="selected" value="'.$val.'">'.$val.'</option>';
                                    }else{
                                        echo '<option value="'.$val.'">'.$val.'</option>';
                                    }

                                }
                                
                            @endphp
                    </select>
                      </label>
                      
                        <!-- <span class="consultantDetailsHeading badge text-light">GENDER</span>
                        <p class="mx-3 consultantDetails">{{$consultant->gender}}</p> -->
                      </div>
                      @endif
                    </div>
                    <button style="float:right;" type="submit" class="mt-3 btn btn-success">Update</button>
                  </form>
                </div>
                {{-- Personal Details End --}}
                {{-- Professional Details --}}
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <form action="update_cs_2" method="post" >
                        @csrf
                        @if($consultantDetails)  
                            @if ($consultant->role == 'CMA' || $consultant->role == 'CA' || $consultant->role == 'CS')
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                    <label class="input fnamelabel field w-100 mt-4">
                                    <input name="award" class="fname input__field" type="text" value="{{$consultantDetails->recognitions}}" placeholder=" " />
                                    <span class="input__label">AWARDS</span>
                                    </label>
                                    <!-- <span class="consultantDetailsHeading badge text-light">AWARDS</span>
                                    <p class="mx-3 consultantDetails">{{$consultantDetails->recognitions}}</p> -->
                                    </div>
                                    <div class="col-md-6">
                                    <label class="input fnamelabel field w-100 mt-4">
                                    <input name="reg_no" class="fname input__field" type="text" value="{{$consultantDetails->registrationNumber}}" placeholder=" " />
                                    <span class="input__label">FIRM REG. NUM.</span>
                                    </label>
                                    <!-- <span class="consultantDetailsHeading badge text-light">FIRM REG. NUM.</span>
                                    <p class="mx-3 consultantDetails">{{$consultantDetails->registrationNumber}}</p> -->
                                    </div>
                                </div> 
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                    <label class="input practice_statelabel field w-100 mt-5">
                                        <select name="industry"  class="practice_state input__field" type="text" placeholder=" ">
                                            <option value="">STATE</option>
                                            @php
                                            $temp=["Industry Experience","Agriculture","Automobiles","Aviation",
                                            "Biotechnology","Cement","Consumer Markets","Education and Traning","Engineering",
                                            "Gems and Jewellery","Infrastructure","IT & ITeS","Manufacturing","Media and Entertainment",
                                            "Oil and Gas","Pharmaceuticals","Real Estate","Research and Development Retail",
                                            "Science and Technology","Services","Steel","Telecommunications","Textiles","Tourism and Hospitality",
                                            "Urban Market","Other"];
                                            
                                            foreach($temp as $val){
                                                if($consultantDetails->experience==$val){
                                                    echo '<option selected="selected" value="'.$val.'">'.$val.'</option>';
                                                }else{
                                                    echo '<option value="'.$val.'">'.$val.'</option>';
                                                }
                                                
                                            }
                                            @endphp
                                            
                                        </select>
                                        <span class="input__label">INDUSTRY STATE</span>
                                    </label>
                                    <!-- <label class="input fnamelabel field w-100 mt-4">
                                    <input name="industry" class="fname input__field" type="text" value="{{$consultantDetails->experience}}" placeholder=" " />
                                    <span class="input__label">INDUSTRY</span>
                                    </label> -->
                                    <!-- <span class="consultantDetailsHeading badge text-light">INDUSTRY</span>
                                    <p class="mx-3 consultantDetails">{{$consultantDetails->experience}}</p> -->
                                    </div>
                                    <div class="col-md-6">
                                    <label class="input practice_statelabel field w-100 mt-5">
                                        <select disabled name="country"  class="practice_state input__field" type="text" placeholder=" ">
                                            <option value="">India</option>

                                        </select>
                                        <span class="input__label">COUNTRY</span>
                                    </label>
                                    <!-- <label class="input fnamelabel field w-100 mt-4">
                                    <input disabled name="country" class="fname input__field" type="text" value="{{$consultantDetails->country}}" placeholder=" " />
                                    <span class="input__label">COUNTRY</span>
                                    </label> -->
                                    <!-- <span class="consultantDetailsHeading badge text-light">COUNTRY</span>
                                    <p class="mx-3 consultantDetails">{{$consultantDetails->country}}</p> -->
                                    </div>
                                </div> 
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                    <input   type="text" hidden id="temp_sts" value="{{$consultantDetails->state}}">
                                        <label class="input practice_statelabel field w-100 mt-5">
                                            <select name="state" id="sts" class="practice_state input__field" type="text" placeholder=" ">
                                                <option value="">STATE</option>
                                                
                                            </select>
                                            <span class="input__label">State</span>
                                        </label>
                                    <!-- <span class="consultantDetailsHeading badge text-light">STATE</span>
                                    <p class="mx-3 consultantDetails">{{$consultantDetails->state}}</p> -->
                                    </div>
                                    <div class="col-md-6">
                                    <input type="text" id="temp_city"  hidden  value=" {{$consultantDetails->city}} ">
                                    <label  class="input citylabel field w-100 mt-5">
                                        <select name="city" id="city_names" class="city input__field" type="text" placeholder=" ">
                                            <option value="">Select City</option>
                                        </select>
                                        <span class="input__label">Select City<span class="red">*</span></span>
                                    </label>
                                    <!-- <span class="consultantDetailsHeading badge text-light">CITY</span>
                                    <p class="mx-3 consultantDetails">{{$consultantDetails->city}}</p> -->
                                    </div>
                                </div> 
                            @endif

                            <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="input fnamelabel field w-100 mt-4">
                                    <input name="address" class="fname input__field" type="text" value="{{$consultantDetails->address}}" placeholder=" " />
                                    <span class="input__label">ADDRESS</span>
                                </label>
                                <!-- <span class="consultantDetailsHeading badge text-light">ADDRESS</span>
                                <p class="mx-3 consultantDetails">{{$consultantDetails->address}}</p> -->
                            </div>
                            <div class="col-md-6">
                                <label class="input fnamelabel field w-100 mt-4">
                                    <input name="pincode" class="fname input__field" type="text" value="{{$consultantDetails->pincode}}" placeholder=" " />
                                    <span class="input__label">PIN CODE</span>
                                </label>
                                <!-- <span class="consultantDetailsHeading badge text-light">PIN CODE</span>
                                <p class="mx-3 consultantDetails">{{$consultantDetails->pincode}}</p> -->
                            </div>
                            </div>
                    
                    
                        @endif
                        <button style="float:right;" type="submit" class="mt-3 btn btn-success">Update</button>
                    </form>
                </div>


                <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="profile-tab">
                  @if($consultantDetails)  

                    <form action="update_cs_3" method='post' enctype="multipart/form-data">
                      @csrf
                        <div class="row mb-3">
                          <div class="col-md-6">

                          <label class="input  field w-100 mt-5">
                            <input  name="certificate" class="input__field"  type="file" >
                            <span class="input__label"> Upload Certificate</span>
                          </label>

                          </div>
                          <div class="col-md-6">
                          <label class="input  field w-100 mt-5">
                            <input  name="aadhar" class="input__field"  type="file" >
                            <span class="input__label"> Upload Aadhar</span>
                          </label>
                          </div>
                        </div>
                        <div class="row mb-3">
                          <div class="col-md-6">

                          <label class="input  field w-100 mt-5">
                            <input  name="pancard" class="input__field"  type="file" >
                            <span class="input__label"> Upload Pancard</span>
                          </label>
                           
                            
                          </div>
                          
                        </div>
                        
                      <button style="float:right;" type="submit" class="mt-3 btn btn-success">Update</button>

                    </form>
                  
                  
                  @endif
                </div>
                
              </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $('.buttonProfile').click(function(){
            $('#layerProfile').click()
            
        })


        function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('.img-account-profile').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $("#layerProfile").change(function(){
        readURL(this);
    });
    })

    $('.pan_card').on('input', function(e) {
           var pancard_val = $('.pan_card').val();
            var regex = /([A-Z]){5}([0-9]){4}([A-Z]){1}$/;
        if (regex.test(pancard_val.toUpperCase())) {
            
            $(".required-notice-pancard").html("");
        } else {
            $(".required-notice-pancard").html("");
            $('<small class="text-danger required-notice-pancard mb-2"> <i class="fa fa-warning"></i>Please Enter Valid PAN Card</small>').insertAfter($(".pancardlabel"))
        }
        });
        
        $('.aadhar_card').on('keypress', function(e) {
            var $this = $(this);
            var regex = new RegExp("^[0-9\b]+$");
            var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
            // for 10 digit number only
            if ($this.val().length > 11) {
                e.preventDefault();
                return false;
            } 
        });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>