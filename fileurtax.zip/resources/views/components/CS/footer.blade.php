<footer class="footer bg-dark text-light text-center p-0 m-0">
  <div class="p-3">
      <h5 class="firstRow">All Right Reserved. Developed by <a href="https://shivila.com/" style="color:rgb(240, 161, 3)" target="_blank">Shivila Technologies</a> </h5>

      <h6 class="secondRow">Copyright © 2022 Shivila Technologies Private Limited. Use of our Products/Services is
          governed by our Privacy Policy.</h6>
  </div>
</footer>

<script>
  $(document).ready(function(){
     toastr.options.timeOut = 10000;
     @if (Session::has('error'))
           toastr.error('{{ Session::get('error') }}');
     @elseif(Session::has('success'))
           toastr.success('{{ Session::get('success') }}');
     @endif
  });
  </script>