@section("title")
FileUrTax | Disclaimer
@endsection
<x-home.topbar/>
<x-home.header/>
<x-home.disclaimer/>
<x-home.footer/>