<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CMA Customer Details - FileUrTax</title>
</head>
<body>
    @php
    $customerDetails =DB::table('members')
    ->where('id',$customer_id)
    ->first();
    @endphp 
    <div class="container-scroller" id="app">
        <x-CMA.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-CMA.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              {{-- Main Dashboard Content --}}
                <div class="row text-center">
                    <div class="text-center align-item-center">
                    
                    </div>
                    <div class="col-lg-12 grid-margin">
                    <div class="card">
                        <h3 class="mt-3">Customer Basic Details</h3>
                        <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <tr>
                                <th > First name </th>
                                <td> {{$customerDetails->fname}} </td>
                                </tr>
                                <tr>
                                    <th > Phone Number </th>
                                    <td> {{$customerDetails->mobile}} </td>
                                </tr>
                                <tr>
                                    <th > Email </th>
                                    <td> {{$customerDetails->email}} </td>
                                </tr>
                                <tr>
                                    <th > Requirements </th>
                                    <td> 
                                        @php
                                            $requirement = DB::table('customer_requirements')
                                            ->where('user_id',$customer_id)
                                            ->first();
                                        @endphp
                                        {{$requirement->requirements}}
                                    </td>
                                </tr>
                            </table>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>

                <div class="row text-center">
                    <div class="text-center align-item-center">
                    
                    </div>
                    <div class="col-lg-12 grid-margin">
                    <div class="card">
                        <h3 class="mt-3">Customer Files</h3>
                        <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <tr>
                                    <th > File name </th>
                                    <th> Download </td>
                                </tr>
                                @php
                                    $files = explode(',',$requirement->files);
                                @endphp
                                @foreach ($files as $file)
                                <tr>
                                    
                                    <th > {{$file}} </th>
                                    <th> <a href="/fileurtax/customer_files/{{$customerDetails->email}}/{{$file}}" class="mdi mdi-file-download text-primary" download></a> </td>
                                </tr>
                                @endforeach
                               
                            </table>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>

                
              {{-- Main Dashboard Content End --}}
            </div>
            <x-CMA.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
</body>
</html>



