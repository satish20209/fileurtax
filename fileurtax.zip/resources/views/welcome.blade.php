@section("title")
Welcome to FileUrTax, providing multi-disciplinary legal solutions. {{-- ranging from transactional, regulatory, advisory, dispute resolution, and tax services. --}}
@endsection

@section("description")
At FileUrTax, we provide legal facilitator services for a range of issues that include LLP Registration, filing ITR Returns, getting a certificate of GST Registration, or finding advocates near me at affordable rates.
@endsection

@section("keywords")
e filing for income tax,income tax e filing in india,e filing of itr,income tax returning,llp registration,filing itr return,income return online,aoc4,certificate of gst registration,chartered accountants,lawyers,advocates near me,lawyers corporate
@endsection

@section('customcss')
<link rel="stylesheet" href="css/feedback.css" >
@endsection

@section('customjs')
<script src="js/feedback.js"></script>
@endsection

<x-home.topbar/>
<x-home.header/>
<x-home.section/>
<x-home.footer/>