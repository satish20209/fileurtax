<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Customer Dashboard | FileUrTax</title>
</head>
<body>
  
  <div class="preloader">
    <div class="main-box-div">
        <div class="row">
        <div class="col-md-12">
            <div class="loader">
                <span class="loader-inner text-dark"><b><span style="color: #eb6c18">FILE</span><span>UR</span><span style="color: green">TAX</span> </b></span>
            </div>
        </div>
    </div>
    </div>
</div>

    <div class="container-scroller" id="app">
        <x-customer.header/>
        {{-- @include('layout.header') --}}
        <div class="container-fluid page-body-wrapper">
            <x-customer.sidebar/>
          {{-- @include('layout.sidebar') --}}
          <div class="main-panel">
            <div class="content-wrapper">
              {{-- Main Dashboard Content --}}
              <x-customer.makepayment/>
              {{-- Main Dashboard Content End --}}
            </div>
            <x-customer.footer/>
            {{-- @include('layout.footer') --}}
          </div>
        </div>
      </div>
</body>
</html>
