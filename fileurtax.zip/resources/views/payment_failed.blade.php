<x-topbar/>
<x-header/>
<div class="p-5">
    <h1>payment failed</h1>
    <p id="email"></p>
    <p id="txn_id"></p>
    <p id="package"></p>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
</script>
<x-footer/>