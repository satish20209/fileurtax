<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
        integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<div class="mt-4 text-center">
  <h1>Payment Information</h1>
</div>


{{-- composer require barryvdh/laravel-dompdf --}}
{{-- use PDF; --}}
{{-- $pdf = PDF::loadView("viewname",compact('data'))->setPaper('a5'); $fileName = "filename.pdf'; return $pdf->download($fileName);
$data = array of data pass into pdf blade --}}

@php
  $userdata = DB::table('users')->where('email',session('email'))->first();
  // echo $userdata->id;
  // print_r($data);
@endphp


<div class="p-3 container w-50 shadow shadow-md mt-5 mb-5">
  <div class="d-flex justify-content-between">
    <div class="">
      <img src="images/logo-cmp.png" alt="logo cmp" style="width: 25%;">
    </div>
    <div class="w-50 text-center">
      <h3 class="p-0 m-0">Shivila Services</h3>
      <small class="">shivila technologies</small>
    </div>
  </div>
<div class="mt-3 mb-3">
  <h4>Payment Receipt</h4>
  <span>This is a payment receipt for your Transaction on</span> <span class="package"></span>
</div>
  <div class="pt-3">
    <h4>User Details</h4>
  </div>
  <table class="table table-primary">
    <thead>
      <tr>
        <th scope="col">User Name</th>
        <th scope="col">User Mobile</th>
        <th scope="col">User Email Id</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td id="username">@php echo $userdata->name;  @endphp</td>
        <td id="user_mobile">@php echo $userdata->mobile;  @endphp</td>
        <td id="email"></td>
      </tr>
    </tbody>
  </table>

  <div class="pt-3">
    <h4>Payment Details</h4>
  </div>
  <table class="table table-primary">
    <thead>
      <tr>
        <th scope="col">Service Name</th>
        <th scope="col">Service Charge</th>
        <th scope="col">Transaction Id</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td id="package"></td>
        <td id="payment"></td>
        <td id="txn_id"></td>
      </tr>
    </tbody>
  </table>
  <div class="w-100 d-flex justify-content-between ps-4 pe-4">
    <button class="btn btn-primary" ><a href="/recipt" style="text-decoration: none;color:white">Download</a></button>
    <button class="btn btn-primary" onclick="window.print()">Print</button>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
var data=JSON.parse(sessionStorage.getItem("data"));

$(document).ready(function(){

    $('#email').html(data.email);
    $('#payment').html("&#8377;"+data.amt);
    $('#txn_id').html(data.txn);
    $('#package').html(data.name);
    $('.package').html(data.name);
});
</script>