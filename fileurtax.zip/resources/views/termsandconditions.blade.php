<x-home.topbar/>
<x-home.header/>
<x-home.termsandconditions/>
<x-home.footer/>