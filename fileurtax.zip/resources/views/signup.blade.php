@section("title")
FileUrTax | Register
@endsection
<x-home.topbar/>
<x-home.header/>
<x-home.signup/>
<x-home.footer/>