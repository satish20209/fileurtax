
    @foreach ($serviceDetails as $serviceDetail)
        <div class="col serviceCard text-center">
            @if ($serviceDetail->name)
                <p class="clientName">{{$serviceDetail->name}}</p>
            @endif
            @if ($serviceDetail->email)
                <p class="clientEmail">{{$serviceDetail->email}}</p>
            @endif
            @if ($serviceDetail->mobile)
                <p class="clientPhone">{{$serviceDetail->mobile}}</p>
            @endif
                <a href="/serviceId={{$serviceDetail->id}}" class="btn serviceDetailsBtn">Details</a>
        </div>
    @endforeach