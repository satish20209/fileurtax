<x-client-service-provider.header/>
<x-client-service-provider.sidebar/>
    <section class="dashboardMain">
        <x-client-service-provider.topbar/>
        <div class="container text-center">
            <div class="recentServicesWrap servicePageWrap">
                <h5 class="recentServiceHeading">RECENT SERVICES</h5>
                <div class="row mt-5 text-center d-flex justify-content-center" id="serviceAppend">
                    @if ($serviceDetails->count() > 0)
                        @foreach ($serviceDetails as $serviceDetail)
                            <div class="col-md-3 serviceCard text-center">
                                @if ($serviceDetail->name)
                                    <p class="clientName">{{$serviceDetail->name}}</p>
                                @endif
                                @if ($serviceDetail->email)
                                    <p class="clientEmail">{{$serviceDetail->email}}</p>
                                @endif
                                @if ($serviceDetail->mobile)
                                    <p class="clientPhone">{{$serviceDetail->mobile}}</p>
                                @endif
                                <a href="/serviceId={{$serviceDetail->id}}" class="btn serviceDetailsBtn">Details</a>
                                
                                
                            </div>
                        @endforeach
                    @else
                        <div class="col text-center ">
                            <p class="mt-5">No Services Available For Now</p>
                        </div>
                    @endif
                </div>
                <div class="row text-center serviceLoader" style="display: none;">
                    <img src="images/jobloader.gif" alt="Job Loader">
                </div>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
            <script type="text/javascript">
                var page = 1;
                $(window).scroll(function() {
                    if($(window).scrollTop() + $(window).height() >= $(document).height()) {
                        page++;
                        loadMoreData(page);
                    }
                });
            
            
                function loadMoreData(page){
                  $.ajax(
                        {
                            url: '?page=' + page,
                            type: "get",
                            beforeSend: function()
                            {
                                $('.serviceLoader').show();
                            }
                        })
                        .done(function(data)
                        {
                            if(data.html == " "){
                                $('.serviceLoader').html("No More Service Found");
                                return;
                            }
                            $('.serviceLoader').hide();
                            $("#serviceAppend").append(data.html);
                        })
                        .fail(function(jqXHR, ajaxOptions, thrownError)
                        {
                              alert('server not responding...');
                        });
                }
            </script>
    </section>
<x-client-service-provider.footer/>