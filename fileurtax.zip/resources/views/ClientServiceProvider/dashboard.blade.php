<x-client-service-provider.header/>
<x-client-service-provider.sidebar/>
    <section class="dashboardMain">
        <x-client-service-provider.topbar/>
        <x-client-service-provider.dashboard/>
    </section>
<x-client-service-provider.footer/>