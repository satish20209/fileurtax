<x-client-service-provider.header/>
<x-client-service-provider.sidebar/>
    <section class="dashboardMain">
        <x-client-service-provider.topbar/>
        <div class="container text-center">
            <div class="recentServicesWrap updatePageWrap">
                <h5 class="recentServiceHeading">ALL UPDATES</h5>
                <div class="row mt-5" id="serviceAppend">
                    @php
                    $recentUpdates = DB::table('service_updates')
                    ->where('serviceProviderId', session('session_service_provider'))
                    ->orderBy('id','DESC')
                    ->get();
                @endphp
                @if ($recentUpdates->count() > 0)
                    @foreach ($recentUpdates as $recentUpdate)
                        <div class="recentUpdates" style="width:80%; margin-right:auto; margin-left:auto;">
                            <div class="row">
                                <div class="col-sm-2">
                                    <img src="images/userPic.png" alt="user Picture"  class="recentUpdatePic">
                                </div>
                                <div class="col-sm-7">
                                    @if ($recentUpdate->status == '1')
                                        <p>Next Date</p>
                                    @endif
                                    @if ($recentUpdate->status == '2')
                                        <p>Pending Upto</p>
                                    @endif
                                    <p>{{$recentUpdate->date}}</p>
                                </div>
                                <div class="col-sm-2">
                                    <a class="btn recentUpdateBtn align-middle" href="serviceId={{$recentUpdate->userId}}#id{{$recentUpdate->id}}">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                            <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
                                            <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @else
                    <div class="recentUpdates">
                        <div class="row">
                            <p>No Updates Avaiable for Now</p>
                        </div>
                    </div>
                @endif
                </div>
                
            </div>
        </div>
    </section>
<x-client-service-provider.footer/>
