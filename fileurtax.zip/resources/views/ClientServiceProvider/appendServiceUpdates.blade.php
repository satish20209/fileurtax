<div class="serviceUpdates" id="id{{$seviceUpdate->id}}">
    @if ($seviceUpdate->status == '1')
        <p> Next Date: {{$seviceUpdate->date}}</p>
    @endif
    @if ($seviceUpdate->status == '2')
        <p> Pending Upto: {{$seviceUpdate->date}}</p>
    @endif
</div>