<x-client-service-provider.header/>
<x-client-service-provider.sidebar/>
    <section class="dashboardMain">
        <x-client-service-provider.topbar/>
        <div class="container-fluid">
            <div class="container text-center">
                <div class="row serviceProviderProfile">
                    @php
                        $userDetails = DB::table('users')
                                        ->where('id',$userId)
                                        ->first();
                    @endphp
                    <h2>I Need Your Help !</h2>
                    @if ($userDetails->name !== NULL)
                        <h4>My Name: {{$userDetails->name}}</h4>
                    @endif
                    @if ($userDetails->email !== NULL)
                        <h4>My Email: {{$userDetails->email}}</h4>
                    @endif
                    @if ($userDetails->mobile !== NULL)
                        <h4>My Contact No: {{$userDetails->mobile}}</h4>
                    @endif
                </div>
            </div>
            @php
                $runningService = DB::table('running_services')
                                 ->where('userId',$userDetails->id)
                                 ->first();
            @endphp
            @if (!$runningService)
            <div class="container takeAction text-center">
                <h3>Take Action to Start Contract</h3>
                <div class="row mt-5">
                    <div class="col">
                        <button class="btn greenBtn" data-bs-toggle="modal" data-bs-target="#acceptService">ACCEPT</button>
                        {{-- Accept Service --}}
                        <div class="modal fade" id="acceptService" tabindex="-1" aria-labelledby="acceptServiceLabel" aria-hidden="true">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <form action="takeAction" method="POST">
                                        @csrf
                                        <h3 class="modalText">Do You Want to Start the Contract?</h3>
                                        <input type="hidden" name="userId" value="{{$userId}}">
                                        <input type="hidden" name="status" value="1">
                                        <div class="row">
                                            <div class="col">
                                                <button type="submit" class="btn greenBtn" data-bs-toggle="modal" data-bs-target="#acceptService">ACCEPT</button>
                                            </div>
                                            <div class="col">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            </div>
                        </div>
                        {{-- Accept Service End --}}
                    </div>
                    <div class="col">
                        <button class="btn redBtn" data-bs-toggle="modal" data-bs-target="#declineService">DECLINE</button>
                        {{-- Decline Service --}}
                        <div class="modal fade" id="declineService" tabindex="-1" aria-labelledby="declineServiceLabel" aria-hidden="true">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <form action="takeAction" method="POST">
                                        @csrf
                                        <h3 class="modalText">Do You Want to Decline the Contract?</h3>
                                        <input type="hidden" name="userId" value="{{$userId}}">
                                        <input type="hidden" name="status" value="-1">
                                        <div class="row">
                                            <div class="col">
                                                <button type="submit" class="btn redBtn">DECLINE</button>
                                            </div>
                                            <div class="col">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                            </div>
                        </div>
                        {{-- Decline Service End --}}
                    </div>
                </div>
            </div>
            @endif
            @if ($runningService)
                <div class="container text-center">
                    @if ($runningService->status == '1')
                        <div class="serviceUpdate statusAccepted">
                            Service Request Accepted
                        </div>
                        @php
                            $seviceUpdates = DB::table('service_updates')
                            ->where(
                                    [
                                        'userId' => $userId,
                                        'serviceProviderId' => session('session_service_provider')
                                    ]
                                )
                            ->get();
                        @endphp
                        <div id="appendServiceUpdates">
                        @foreach ($seviceUpdates as $seviceUpdate)
                            <div class="serviceUpdates" id="id{{$seviceUpdate->id}}">
                                @if ($seviceUpdate->status == '1')
                                    <p> Next Date: {{$seviceUpdate->date}}</p>
                                @endif
                                @if ($seviceUpdate->status == '2')
                                    <p> Pending Upto: {{$seviceUpdate->date}}</p>
                                @endif
                            </div>
                        @endforeach
                           {{-- Append the Latest Service Updates Here --}}
                        </div>
                       <div class="serviceUpdateForm">
                            <div class="row">
                                    <div class="col mt-3">
                                        <select id="serviceStatus" class="form-select" aria-label="Default select example" required>
                                            <option value="1">Next Date</option>
                                            <option value="2">Pending Upto</option>
                                        </select>
                                    </div>
                                    <div class="col mt-3">
                                        <input id="date" type="date" min="{{\Carbon\Carbon::today('Asia/Kolkata')->format('Y-m-d')}}" class="form-control" id="exampleInputEmail1" required>
                                    </div>
                                    <div class="col mt-3">
                                        <button class="btn primaryBtn updateServiceStatus">Update Status</button>
                                    </div>
                            </div>
                            <div class="row mt-3">
                                <button class="btn primaryBtn updateServiceStatus" data-bs-toggle="modal" data-bs-target="#closeService">Close the Service</button>
                            </div>
                            {{-- Close Service Modal --}}
                            <div class="modal fade" id="closeService" tabindex="-1" aria-labelledby="closeServiceLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <div class="row">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <form action="{{route('closeService')}}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="userId" value="{{$userId}}">
                                                    <input type="hidden" name="status" value="0">
                                                    <button type="submit" class="btn greenBtn">WON</button>
                                                </form>
                                            </div>
                                            <div class="col">
                                                <form action="{{route('closeService')}}"method="POST">
                                                    @csrf
                                                    <input type="hidden" name="userId" value="{{$userId}}">
                                                    <input type="hidden" name="status" value="-2">
                                                    <button type="submit" class="btn redBtn">LOST</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                            {{-- Close Service Modal End --}}
                        </div>
                    @endif
                    @if ($runningService->status == '-1')
                        <div class="serviceUpdate statusDeclined">
                            Service Request Declined
                        </div>
                    @endif
                    @if ($runningService->status == '0')
                        <div class="serviceUpdate statusAccepted">
                            You Won The Case
                        </div>
                    @endif
                    @if ($runningService->status == '-2')
                        <div class="serviceUpdate statusDeclined">
                            You Lost The Case
                        </div>
                    @endif
                </div>
            @endif
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<script>
    $('.updateServiceStatus').on('click',function() {
        var Status = document.getElementById('serviceStatus');
        var serviceStatus = Status.options[Status.selectedIndex].value;
        var date = document.getElementById('date').value;
        $.ajax({
            url: '/statusUpdate',
            method: 'POST',
            data: {
                serviceStatus:serviceStatus,
                date:date,
                userId: '{{$userId}}',
                '_token': '{{csrf_token()}}',
            },
            success: function(seviceUpdate) {
                document.getElementById('appendServiceUpdates').innerHTML += seviceUpdate.seviceUpdate;
            },
            error: function(seviceUpdate) {
                
            }
        });
    });
</script>
    </section>
<x-client-service-provider.footer/>
