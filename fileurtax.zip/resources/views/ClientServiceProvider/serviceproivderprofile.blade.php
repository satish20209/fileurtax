@if (session()->has('session_service_provider'))
<x-client-service-provider.header/>
<x-client-service-provider.sidebar/>
<section class="p-5"> 
    <x-serviceproviderprofile.profile-page/>
</section>
<x-client-service-provider.footer/>
@else
 <script>
    window.location = "signin";
 </script>
@endif




