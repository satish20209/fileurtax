<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>FileUrTax Mail Verification</title>
    <style>
        .mailCode {
            width: 300px;
            padding: 20px 10px;
            margin-right: auto;
            margin-left: auto;
        }
        h5 {
            color: black;
        }
        p {
            color: blue;
            font-size: 25px;
        }
    </style>
</head>
<body>
    <div class="mailCode">
        <h3>Please Note This Id/Code and veryfy your Email Id  </h3>
        <p><b>{{ $emailCode['code'] }}</b></p>
    </div>
</body>
</html>