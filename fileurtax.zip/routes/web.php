<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\General;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AskquotationController;
use App\Http\Controllers\BidController;
use App\Http\Controllers\BookconsultaionController;
use App\Http\Controllers\ChildServiceController;
use App\Http\Controllers\ContactMassageController;
use App\Http\Controllers\CustomerRequirementController;
use App\Http\Controllers\EmailVerificationController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\PackageController;
use App\Http\Controllers\ParentPackageController;
use App\Http\Controllers\ParentServiceController;
use App\Http\Controllers\PaymenteController;
use App\Http\Controllers\RunningServiceController;
use App\Http\Controllers\ServiceprovidercaController;
use App\Http\Controllers\ServiceProviderClientController;
use App\Http\Controllers\ServiceprovidercmaController;
use App\Http\Controllers\ServiceprovidercsController;
use App\Http\Controllers\ServiceproviderLawyerController;
use App\Http\Controllers\ServicesRequestController;
use App\Http\Controllers\ServiceUpdateController;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\HelpController;
use App\Http\Controllers\feedback;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\BlogcomentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('download/{chid}/{id}',[ChatController::class,'filedownload']);
Route::post('/chatmsg',[ChatController::class,'chatmsg']);
Route::get('/getChatFilename',[ChatController::class,'ChatFilenameData']);
Route::get('/chat',[ChatController::class,'chatview']);
Route::post('/fileupload',[ChatController::class,'fileupload']);
Route::get('/showserviceprovider',[ChatController::class,'showserviceprovider']); //this funtion call in user side to show send request after accepet then show service provider
Route::get('/showcustomer',[ChatController::class,'showcustomer']); //this function call in service provider to show all user in service provider accepet all users


Route::get('/msgceo', function () {return view('msgceo');});
Route::get('/whychooseus', function () {return view('whychooseus');});
Route::get('/privacypolicy', function () {return view('privacypolicy');});
Route::get('/payment_success', function () {return view('payment_success');});
Route::get('/payment_failed', function () {return view('payment_failed');});
//testing image upload s3
Route::post('/upload_files',[General::class,'upload_files']);

Route::get('/',[General::class,'welcome']);
Route::get('/aboutus',[General::class,'aboutus']);
Route::get('/contact',[General::class,'contact']);
Route::get('/termsandconditions',[AdminController::class,'termsandconditions']);
Route::get('/services',[General::class,'services']);
Route::get('/packages',[General::class,'packages']);
Route::get('/quotation',[General::class,'quotation']);
Route::get('/disclaimer',[General::class,'disclaimerfun']);
Route::get('/register',[ChatController::class,'signup']);
Route::get('/login',[ChatController::class,'signin']);
Route::get('charteredaccountant',[General::class,'charteredAccountant']);
Route::get('costmanagementaccountant',[General::class,'CostManagementAccountant']);
Route::get('legalservices',[General::class,'LegalServices']);
Route::get('companysecretary',[General::class,'CompanySecretary']);
Route::get('personalfinance',[General::class,'PersonalFinance']);
Route::get('loan',[General::class,'Loan'])->name('Loan');
Route::get('investment',[General::class,'Investment']);
Route::get('OtherServices',[General::class,'OtherServices']);


//Route for Super Admin
Route::get('/superAdminDashboard',[SuperAdminController::class,'superAdminDashboard'])->name('superAdminDashboard');
Route::post('/superAdminAuth',[SuperAdminController::class,'superAdminAuth'])->name('superAdminAuth');
Route::get('/superAdminLogOut',[SuperAdminController::class,'superAdminLogOut'])->name('superAdminLogOut');
Route::get('/superAdminPackages',[SuperAdminController::class,'superAdminPackages'])->name('superAdminPackages');
Route::get('/superAdminConsulations',[SuperAdminController::class,'superAdminConsulations'])->name('superAdminConsulations');
Route::get('/superAdminSales',[SuperAdminController::class,'superAdminSales'])->name('superAdminSales');
Route::get('/superAdminLeads',[SuperAdminController::class,'superAdminLeads'])->name('superAdminLeads');
Route::get('/superAdminProfile',[SuperAdminController::class,'superAdminProfile'])->name('superAdminProfile');
Route::post('/superadminPassword',[SuperAdminController::class,'superadminPassword'])->name('superadminPassword');
Route::get('/superAdminViewAdmins',[SuperAdminController::class,'superAdminViewAdmins'])->name('superAdminViewAdmins');
Route::post('/superAdminAddAdmins',[SuperAdminController::class,'superAdminAddAdmins'])->name('superAdminAddAdmins');
Route::post('/superAdminDeleteAdmins',[SuperAdminController::class,'superAdminDeleteAdmins'])->name('superAdminDeleteAdmins');
Route::get('/superAdminViewCustomers',[SuperAdminController::class,'superAdminViewCustomers'])->name('superAdminViewCustomers');
Route::get('/superAdminViewConsultants',[SuperAdminController::class,'superAdminViewConsultants'])->name('superAdminViewConsultants');
Route::get('/superAdminViewQuotations',[SuperAdminController::class,'superAdminViewQuotations'])->name('superAdminViewQuotations');
Route::get('/superAdminSalesPage',[SuperAdminController::class,'superAdminSalesPage'])->name('superAdminSalesPage');
Route::get('/consultantProfile',[SuperAdminController::class,'consultantProfile'])->name('consultantProfile');
Route::get('/customerProfile',[SuperAdminController::class,'customerProfile'])->name('customerProfile');
Route::get('update_customer_details',[SuperAdminController::class,'update_customer_details']);
Route::get('delete_customer_details',[SuperAdminController::class,'delete_customer_details']);
Route::get('/superadminlogin',[SuperAdminController::class,'login'])->name('login');
Route::get('superAdminBids',[BidController::class,'superAdminBids'])->name('superAdminBids');
//Route for Bid Submit
Route::post('bidSubmit',[BidController::class,'bidSubmit'])->name('bidSubmit');
//Route for View Bids
Route::get('viewBids',[BidController::class,'viewBids'])->name('viewBids');



// admin routes
Route::get('/adminlogin',[AdminController::class,'adminLloginViewpage'])->middleware('isLoinDashboard');
Route::post('/admindashboard',[AdminController::class,'loginAdmin']);
Route::get('/adminchat',[AdminController::class,'adminchat']);
// Route::get('/servicerequestcount',[AdminController::class,'servicerequestcount']);
Route::get('/logoutAdmin',[AdminController::class,'flush'])->name('logoutAdmin');
// Route::get('/adminUserDatafetch',[AdminController::class,'adminUserDatafetch']);
// Route::get('/adminServiceProviderClientDatafetch',[AdminController::class,'adminServiceProviderClientDatafetch']);
// Route::get('service_provider_req',[AdminController::class,'service_provider_req']);
Route::get('service_provider_req_status',[AdminController::class,'service_provider_req_status']);
Route::get('service_provider_req_status_desable',[AdminController::class,'service_provider_req_status_desable']);

Route::get('adminhelp',[AdminController::class,'adminhelp']);
Route::get('viewhelp',[AdminController::class,'viewhelp']);
Route::get('helpsolve',[AdminController::class,'helpsolve']);
Route::get('adminviewcustomer',[AdminController::class,'adminviewcustomer']);
Route::get('adminviewconsultant',[AdminController::class,'adminviewconsultant']);
Route::get('adminviewrequest',[AdminController::class,'adminviewrequest']);
Route::get('adminfeedback',[AdminController::class,'adminfeedback']);
Route::get('adminblog',[AdminController::class,'adminblog']);
Route::get("CreateBlog",function(){ return view("admin.CreateBlog");});



Route::post('/selectParentService',[ParentServiceController::class,'selectParentService'])->name('selectParentService');
Route::post('/selectChildService',[ChildServiceController::class,'selectChildService'])->name('selectChildService');
Route::post('/selectOtherChildService',[ChildServiceController::class,'selectOtherChildService'])->name('selectOtherChildService');



 // user controller
Route::get('/insert_mobile', [UserController::class,'insert_mobile']);
Route::post('/details_sub', [UserController::class,'details_sub']);
Route::post('userLocation',[UserController::class,'userLocation'])->name('userLocation');
Route::get('/google', [UserController::class,'redirectGoogle']);
Route::get('/google/res', [UserController::class,'resgoogle']);
Route::get('/facebook', [UserController::class,'redirectfacebook']);
Route::get('/facebook/res', [UserController::class,'resfacebook']);
Route::get('/instagram', [UserController::class,'redirectinstagram']);
Route::get('/instagram/res', [UserController::class,'resinstagram']);
Route::get('/linkedin', [UserController::class,'redirectlinkedin']);
Route::get('/linkedin/res', [UserController::class,'reslinkedin']);
Route::get('/twitter', [UserController::class,'redirecttwitter']);
Route::get('/twitter/res', [UserController::class,'restwitter']);

// ContactMassageController
Route::get('/contactus_form', [ContactMassageController::class, 'contact']);

Route::post('statusUpdate',[ServiceUpdateController::class,'statusUpdate'])->name('statusUpdate');


Route::post('/takeAction',[RunningServiceController::class,'takeAction'])->name('takeAction');
Route::post('closeService',[RunningServiceController::class,'closeService'])->name('closeService');
Route::get('allUpdates',[RunningServiceController::class,'allUpdates'])->name('allUpdates');


// bookconsultation 
Route::get('/bookconsultation',[BookconsultaionController::class,'index']);
Route::get('/get_city/{city}',[BookconsultaionController::class,'get_city']);
Route::post('/bookconsultaionfun',[BookconsultaionController::class,'bookconsultaionfun']);


// payment routing
Route::get('/process',[PaymenteController::class,"action"]);
Route::get('/process_success',[PaymenteController::class,"action_success"]);
Route::get('/recipt',[PaymenteController::class,'recipt']);


// packagecontroller routes
Route::post('/process_package',[PackageController::class,"action"]);
Route::get('/process_success_package',[PackageController::class,"action_success"]);

//Route for General controller

Route::get('customerQuotations',[General::class,'customerQuotations'])->name('customerQuotations');

Route::get('/check_email', [General::class,'checkemail']);

Route::post('checkCustomserRequirement',[CustomerRequirementController::class,'checkCustomserRequirement'])->name('checkCustomserRequirement');
// Route::get('charteredAccountant',[General::class,'charteredAccountant'])->name('charteredAccountant');
// Route::get('CostManagementAccountant',[General::class,'CostManagementAccountant'])->name('CostManagementAccountant');
// Route::get('LegalServices',[General::class,'LegalServices'])->name('LegalServices');
// Route::get('CompanySecretary',[General::class,'CompanySecretary'])->name('CompanySecretary');
// Route::get('PersonalFinance',[General::class,'PersonalFinance'])->name('PersonalFinance');
// Route::get('Loan',[General::class,'Loan'])->name('Loan');
// Route::get('Investment',[General::class,'Investment'])->name('Investment');
// Route::get('OtherServices',[General::class,'OtherServices'])->name('OtherServices');

Route::get('updateUserService',[General::class,'updateUserService'])->name('updateUserService');

Route::get('/dashboard',[General::class,'dashboard'])->name('dashboard');

Route::get('/serviceproivderprofile',[General::class,'dashboard'])->name('serviceproivderprofile');
// password reset routes
Route::post('resetphone',[General::class,'resetphone'])->name('resetphone');

Route::post('updatepassword',[General::class,'updatepassword']);

Route::post('updateCustomerLocation',[General::class,'updateCustomerLocation']);

Route::get('get_data_PD',[General::class,'get_data_PD'])->name('get_data_PD');

Route::post('register_submit',[General::class,'register_submit'])->name('register_submit');


Route::post('/quotation_form', [AskquotationController::class, 'askQuotationfun']);








//Route for ServiceProviderClientController
// Route::get('/',[ServiceProviderClientController::class,'index'])->name('index');
// Route::post('/serviceProviderRegister',[ServiceProviderClientController::class,'serviceProviderRegister'])->name('serviceProviderRegister');
// Route::post('/serviceProviderLogin',[ServiceProviderClientController::class,'serviceProviderLogin'])->name('serviceProviderLogin');
// Route::get('serviceProviderlogout',[ServiceProviderClientController::class,'serviceProviderlogout'])->name('serviceProviderlogout');
// Route::get('get_profile_info',[ServiceProviderClientController::class,'get_profile_info']);
// Route::get('update_profile_info',[ServiceProviderClientController::class,'update_profile_info']);
// Route::get('/serviceId={userId}',[ServiceProviderClientController::class,'serviceDetails'])->name('serviceDetails');
// Route::get('services',[ServiceProviderClientController::class,'services'])->name('services');
// Route::post('serviceProviderLocation',[ServiceProviderClientController::class,'serviceProviderLocation'])->name('serviceProviderLocation');



//Route customerController
Route::get('/customerDashboard',[CustomerRequirementController::class,'customerDashboard'])->name('customerDashboard');
Route::post('/serviceRequest',[CustomerRequirementController::class,'serviceRequest'])->name('serviceRequest');
Route::get('/bookappointment',[CustomerRequirementController::class,'bookappointment']);
Route::get('/bookedappointment',[CustomerRequirementController::class,'bookedappointment']);
Route::get('/viewbookedappointment',[CustomerRequirementController::class,'viewbookedappointment']);
Route::get('/csviewbookedappointment',[CustomerRequirementController::class,'csviewbookedappointment']);
Route::get('/caviewbookedappointment',[CustomerRequirementController::class,'caviewbookedappointment']);
Route::get('/cmaviewbookedappointment',[CustomerRequirementController::class,'cmaviewbookedappointment']);
Route::get('/customermakepayment',[CustomerRequirementController::class,'makepayment']);


// BookConsultation
Route::get('/get_city_lawyer/{city}',[BookconsultaionController::class,'get_city']);

// member controller routes
Route::post('//updatepassword',[MemberController::class,'updatepassword']);
Route::post('/membersignup',[MemberController::class,'membersignup']);
Route::get('/memberslogin',[MemberController::class,'memberlogin']);
Route::post('login_l',[MemberController::class,'login'])->name('login_l');
Route::get('customerLogOut',[MemberController::class,'customerLogOut']);


//Update Customer Requirement
Route::post('updateCustomerReq',[CustomerRequirementController::class,'updateCustomerReq'])->name('updateCustomerReq');
Route::get('customerRequirement',[CustomerRequirementController::class,'customerRequirement'])->name('customerRequirement');
Route::post('customerRequirement_reg',[CustomerRequirementController::class,'customerRequirement_reg'])->name('customerRequirement_reg');
Route::post('get_clint_service',[CustomerRequirementController::class,'get_clint_service'])->name('get_clint_service');

// EmailVerificationController
Route::post('emailVerify',[EmailVerificationController::class,'emailVerify'])->name('emailVerify');
Route::post('emailCodeVerify',[EmailVerificationController::class,'emailCodeVerify'])->name('emailCodeVerify');
Route::get('deleteemail',[EmailVerificationController::class,'deleteemail']);


// lawyer routes
Route::get('lawyerQuotation',[ServiceproviderLawyerController::class,'lawyerQuotation'])->name('lawyerQuotation');
Route::get('/lawyerDashboard',[ServiceproviderLawyerController::class,'lawyerDashboard'])->name('lawyerDashboard');
Route::post('lawyerAcceptRequest',[ServiceproviderLawyerController::class,'lawyerAcceptRequest']);
Route::post('customerDetails',[ServiceproviderLawyerController::class,'customerDetails']);
Route::get('recentServices',[ServiceproviderLawyerController::class,'recentServices']);
Route::get('runningServices',[ServiceproviderLawyerController::class,'runningServices']);
Route::get('laywerLogOut',[ServiceproviderLawyerController::class,'laywerLogOut']);
Route::post('lawyerDenyRequest',[ServiceproviderLawyerController::class,'lawyerDenyRequest']);
Route::get('/register_lawyer',[ServiceproviderLawyerController::class,'index']);
// Route::get('/login',[ServiceproviderLawyerController::class,'viewlogin']);
Route::post('/loginlawyer',[ServiceproviderLawyerController::class,'logincheck']);
Route::post('/registerlawyersignup',[ServiceproviderLawyerController::class,'registerspfun']);
Route::get('UpdateLawyer',[ServiceproviderLawyerController::class,'layerSetting']);
// Route::post('lawyerUpdate',[ServiceproviderLawyerController::class,'lawyerUpdate']);
Route::get('helplawyer',[ServiceproviderLawyerController::class,'helplawyer']);



// cs routes
Route::post('/registerlawyersignupcs',[ServiceprovidercsController::class,'registerlawyersignupcs']);
Route::get('register_CS',[ServiceprovidercsController::class,'register_CS_form'])->name('register_CS');
Route::post('csDenyRequest',[ServiceprovidercsController::class,'csDenyRequest']);
Route::post('cscustomerDetails',[ServiceprovidercsController::class,'cscustomerDetails']);
Route::get('csDashboard',[ServiceprovidercsController::class,'csDashboard']);
Route::get('csActiveServices',[ServiceprovidercsController::class,'csActiveServices']);
Route::get('csServiceRequest',[ServiceprovidercsController::class,'csServiceRequest']);
Route::get('csLogOut',[ServiceprovidercsController::class,'csLogOut']);
Route::post('csAcceptRequest',[ServiceprovidercsController::class,'csAcceptRequest']);
Route::get('UpdateCs',[ServiceprovidercsController::class,'csSetting']);
// Route::post('csUpdate',[ServiceprovidercsController::class,'csUpdate']);
Route::get('csQuotation',[ServiceprovidercsController::class,'csQuotation'])->name('csQuotation');
Route::get('cshelp',[ServiceprovidercsController::class,'cshelp']);



// ca routes

Route::post('caDenyRequest',[ServiceprovidercaController::class,'caDenyRequest']);
Route::post('cacustomerDetails',[ServiceprovidercaController::class,'cacustomerDetails']);
Route::get('caDashboard',[ServiceprovidercaController::class,'caDashboard']);
Route::get('caActiveServices',[ServiceprovidercaController::class,'caActiveServices']);
Route::get('caServiceRequest',[ServiceprovidercaController::class,'caServiceRequest']);
Route::get('caLogOut',[ServiceprovidercaController::class,'caLogOut']);
Route::post('caAcceptRequest',[ServiceprovidercaController::class,'caAcceptRequest']);
Route::get('UpdateCa',[ServiceprovidercaController::class,'caSetting']);
// Route::post('caUpdate',[ServiceprovidercaController::class,'caUpdate']);
Route::get('caQuotation',[ServiceprovidercaController::class,'caQuotation'])->name('caQuotation');
Route::get('/registerca',[ServiceprovidercaController::class,'index']);
Route::get('/cahelp',[ServiceprovidercaController::class,'cahelp']);
Route::post('/registerlawyersignupca',[ServiceprovidercaController::class,'registerlawyersignupca']);

// cma route
Route::post('/registerlawyersignupcms',[ServiceprovidercmaController::class,'registerlawyersignupcms']);
Route::get('register_CMA',[ServiceprovidercmaController::class,'register_CMA'])->name('register_CMS');
Route::post('cmaDenyRequest',[ServiceprovidercmaController::class,'cmaDenyRequest']);
Route::post('cmacustomerDetails',[ServiceprovidercmaController::class,'cmacustomerDetails']);
Route::get('cmaDashboard',[ServiceprovidercmaController::class,'cmaDashboard']);
Route::get('cmaActiveServices',[ServiceprovidercmaController::class,'cmaActiveServices']);
Route::get('cmaServiceRequest',[ServiceprovidercmaController::class,'cmaServiceRequest']);
Route::get('cmaLogOut',[ServiceprovidercmaController::class,'cmaLogOut']);
Route::post('cmaAcceptRequest',[ServiceprovidercmaController::class,'cmaAcceptRequest']);
Route::get('UpdateCma',[ServiceprovidercmaController::class,'cmaSetting']);
// Route::post('cmaUpdate',[ServiceprovidercmaController::class,'cmaUpdate']);
Route::get('cmahelp',[ServiceprovidercmaController::class,'cmahelp']);
Route::get('cmaQuotation',[ServiceprovidercmaController::class,'cmaQuotation'])->name('cmaQuotation');

Route::get('support',[HelpController::class,'support']);
Route::post('helpcustomer',[HelpController::class,'help']);
Route::get('helpcustomerview',[HelpController::class,'helpcustomerview']);
Route::get('supportname/{id}',[HelpController::class,'supportname']);


Route::post('feedbacks',[feedback::class,'feedbacks']);
Route::get('feedback',[feedback::class,'feedback']);
Route::get('get_feedback',[feedback::class,'get_feedback']);
Route::get('get_feedback_msg',[feedback::class,'get_feedback_msg']);
Route::get('change_status_feedback',[feedback::class,'change_status_feedback']);
Route::get('count_feedback',[feedback::class,'count_feedback']);


// update all filed 
Route::post('update_lyr_PD',[ServiceproviderLawyerController::class,'update_lyr_tab_1']);
Route::post('update_Ltab_2',[ServiceproviderLawyerController::class,'update_lyr_tab_2']);
Route::post('update_Ltab_3',[ServiceproviderLawyerController::class,'update_Ltab_3']);

// for cs
Route::post('update_cs_1',[ServiceprovidercsController::class,'update_cstab_1']);
Route::post('update_cs_2',[ServiceprovidercsController::class,'update_cstab_2']);
Route::post('update_cs_3',[ServiceprovidercsController::class,'update_cstab_3']);

// for cma
Route::post('update_cma_1',[ServiceprovidercmaController::class,'update_cmatab_1']);
Route::post('update_cma_2',[ServiceprovidercmaController::class,'update_cmatab_2']);
Route::post('update_cma_3',[ServiceprovidercmaController::class,'update_cmatab_3']);

// for ca
Route::post('update_ca_1',[ServiceprovidercaController::class,'update_catab_1']);
Route::post('update_ca_2',[ServiceprovidercaController::class,'update_catab_2']);
Route::post('update_ca_3',[ServiceprovidercaController::class,'update_catab_3']);

Route::get('get_blogs',[BlogController::class,'get_all_blogs']);
Route::get("AdminViewBlog",function(){return view('admin.viewBlog');});
Route::get("AdminEditBlog",function(){ return view('admin.AdminEditblog');});
// Route::get("CreateBlog",function(){ return view("admin.blog");});
Route::post("updateblog",[BlogController::class,'updateblog']);
Route::get("deleteBlog",[BlogController::class,'deleteBlog']);
Route::get("Blogs",[BlogController::class,'blogs']);
Route::get("viewBlog",[BlogController::class,'viewBlog']);
Route::get("read_blog",[BlogController::class,'read_blogs']);
Route::post('submit_blog',[BlogController::class,'submit_blog']);
Route::post('comments',[BlogcomentController::class,'comments']);



// pyment route
Route::post('lyerRequestPayment',[ServiceproviderLawyerController::class,'lyerRequestPayment']);
Route::post('acceptConsultantPaymentReq',[CustomerRequirementController::class,'acceptConsultantPaymentReq']);
Route::get('customer_payment',[CustomerRequirementController::class,'customer_payment']);
Route::post('denyConsultantPaymentReq',[CustomerRequirementController::class,'denyConsultantPaymentReq']);
Route::post('CSRequestPayment',[ServiceprovidercsController::class,'csRequestPayment']);
Route::post('CMARequestPayment',[ServiceprovidercmaController::class,'CMARequestPayment']);
Route::post('CARequestPayment',[ServiceprovidercaController::class,'CARequestPayment']);
Route::get('requestPayment',[ServiceproviderLawyerController::class,'requestPayment']);
Route::get('csrequestPayment',[ServiceprovidercsController::class,'requestPayment']);
Route::get('carequestPayment',[ServiceprovidercaController::class,'requestPayment']);
Route::get('cmarequestPayment',[ServiceprovidercmaController::class,'requestPayment']);