<?php
    $laywerDetails =DB::table('members')->where('email',session('layerAuth'))->first();
?>

<?php
    $serviceRequests = DB::table('services_requests')
                          ->where(
                            [
                              'service_provider_id' => $laywerDetails->id,
                              'status' => '1',
                            ]
                          )
                          ->orderBy('id','desc')
                          ->get();
    $serviceRequestsExists = DB::table('services_requests')
                                ->where(
                                    [
                                        'service_provider_id' => $laywerDetails->id,
                                        'status' => '1',
                                    ]
                                        )
                                ->exists();
?>
<div class="row text-center mb-5">
    <div class="col-12">
        <h3>All Running Services</h3>
    </div>
</div>





  <div class="row text-center mt-5 d-flex align-items-center mr-auto ml-auto">
            
            <?php if($serviceRequestsExists): ?>
                <?php $__currentLoopData = $serviceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $customers = DB::table('members')->where('id',$serviceRequest->customer_id)->first();
                    $requirement = DB::table('customer_requirements')->where('user_id',$serviceRequest->customer_id)->first();
                ?>
                <?php
                if ($serviceRequest->accept == NULL) {
                $disable = 'disabled';
                }else {
                $disable = '';
                }
                ?>
                <div class="col col-md-4 col-xl-4 d-flex align-items-center">
                    <div class="card d-flex align-items-center m-3" style="width: 20rem">
                        <div class="card-body d-flex align-items-center">
                            <div class="event py-3">
                                <p class="mb-2 font-weight-medium">Name : <?php echo e($customers->fname); ?></p>
                                <p class="mb-2 font-weight-medium">Requirements : <?php echo e($requirement->requirements); ?></p>
                                <div class="text-center">
                                <form action="customerDetails" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="customer_id" value="<?php echo e($customers->id); ?>">
                                    <div class="text-center">
                                        <button type="submit" <?php echo e($disable); ?> class="btn btn-primary text-light mr-3 w-100">View Details</button>
                                    </div>
                                </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="text-center NotAvailable">
                    <p class="text-mute">No Running Services Available</p>
                </div>
            <?php endif; ?>

            
        
   
   

    
  </div>

  
  
  <?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/components/lawyer/runningServices.blade.php ENDPATH**/ ?>