<?php $__env->startSection("title"); ?>
FileUrTax | Login
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Topbar::class, []); ?>
<?php $component->withName('home.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8)): ?>
<?php $component = $__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8; ?>
<?php unset($__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Header::class, []); ?>
<?php $component->withName('home.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93)): ?>
<?php $component = $__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93; ?>
<?php unset($__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.home.signin','data' => []]); ?>
<?php $component->withName('home.signin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal623176770b884771a62630739c42e1bd0e3c713f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Footer::class, []); ?>
<?php $component->withName('home.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal623176770b884771a62630739c42e1bd0e3c713f)): ?>
<?php $component = $__componentOriginal623176770b884771a62630739c42e1bd0e3c713f; ?>
<?php unset($__componentOriginal623176770b884771a62630739c42e1bd0e3c713f); ?>
<?php endif; ?><?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/signin.blade.php ENDPATH**/ ?>