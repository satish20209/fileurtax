<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-89X63WK48Y"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-89X63WK48Y');
</script>
<div>
   <!-- Main Header-->
   <header class="main-header header-style-one">
    <!--Header-Upper-->
    <div class="header-upper">
        <div class="auto-container clearfix">
            <div class="pull-left logo-box">
                <div class="logo"><a href="/"><img src="images/logo.png" alt="fileurtax logo" title="" style="width: 150px;" ></a></div>
            </div>
            
            <div class="nav-outer clearfix">
                <!-- Mobile Navigation Toggler -->
                <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
                <!-- Main Menu -->
                <nav class="main-menu navbar-expand-md">
                    <div class="navbar-header">
                        <!-- Toggle Button -->    	
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    
                    <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                        <ul class="navigation clearfix">
                            <li class="current"><a href="/">Home</a>
                            </li>
                            <li class="dropdown"><a href="/aboutus">About Us</a>
                                <ul>
                                    <li><a href="/msgceo">Director</a></li>
                                    <li><a href="/aboutus">About Us</a></li>
                                    <li><a href="/whychooseus">Why Choose Us</a></li>
                                </ul>
                            </li>
                            <li class="dropdown"><a href="#">Services</a>
                                <ul>
                                    <li><a href="/charteredaccountant">Chartered Accountant</a></li>
                                    <li><a href="/costmanagementaccountant">Cost Management Accountant</a></li>
                                    <li><a href="/companysecretary">Company Secretary</a></li>
                                    <li><a href="/legalservices">Legal Services</a></li>
                                    <li><a href="/investment">Investment</a></li>
                                    <li><a href="/loan">Loan</a></li>
                                    <li><a href="/personalfinance">Personal Finance</a></li>
                                    
                                    
                                </ul>
                            </li>
                            <li><a href="/packages">Packages</a>
                            </li>
                            <li><a href="/quotation">Ask Quotation</a>
                            </li>
                            <li><a href="/Blogs">Blogs</a>
                            </li>
                            <li><a href="/contact">Contact us</a></li>
                            
                        </ul>
                    </div>
                </nav>
                
                <!-- Main Menu End-->
                <div class="outer-box clearfix">
                    
                    <!-- Btn Box -->
                    <div class="btn-box">
                        <?php if(session('caAuth')): ?>
                        <?php
                            $caname = DB::table('members')->where('email',session('caAuth'))->first()->fname;
                        ?>
                        <a href="/caDashboard" class="theme-btn btn-style-one"><span class="txt"> <?php echo e($caname); ?></span></a>
                        <?php elseif(session('csAuth')): ?> 
                        <?php
                            $csname = DB::table('members')->where('email',session('csAuth'))->first()->fname;
                        ?>
                        <a href="/csDashboard" class="theme-btn btn-style-one"><span class="txt"><?php echo e($csname); ?> </span></a>
                        <?php elseif(session('cmaAuth')): ?> 
                        <?php
                            $cmaname = DB::table('members')->where('email',session('cmaAuth'))->first()->fname;
                        ?>
                        <a href="/cmaDashboard" class="theme-btn btn-style-one"><span class="txt"> <?php echo e($cmaname); ?> </span></a>
                        <?php elseif(session('layerAuth')): ?> 
                        <?php
                            $lawyername = DB::table('members')->where('email',session('layerAuth'))->first()->fname;
                        ?>
                        <a href="/lawyerDashboard" class="theme-btn btn-style-one"><span class="txt"> <?php echo e($lawyername); ?> </span></a>
                        <?php elseif(session('customerAuth')): ?>
                        <?php
                            $customername = DB::table('members')->where('email',session('customerAuth'))->first()->fname;
                        ?>
                        <a href="/customerDashboard" class="theme-btn btn-style-one"><span class="txt"><?php echo e($customername); ?></span></a>
                        <?php else: ?>
                        <a href="/login" class="theme-btn btn-style-one"><span class="txt">Sign In</span></a>
                        <?php endif; ?>
                        
                    </div>                        
                </div>
            </div>
            
        </div>
    </div>
    <!--End Header Upper-->
    
    <!-- Sticky Header  -->
    <div class="sticky-header" style="background: linear-gradient(120deg, #2f78e9, #128bfc, #18bef1);">
        <div class="auto-container clearfix" >
            <!--Logo-->
            <div class="logo pull-left">
                <a href="/" title=""><img src="images/logo-small.png" alt="fileurtax logo" title="" style="width: 150px;"></a>
            </div>
            <!--Right Col-->
            <div class="pull-right">
                <!-- Main Menu -->
                <nav class="main-menu">
                    <!--Keep This Empty / Menu will come through Javascript-->
                </nav><!-- Main Menu End-->
                
                <!-- Main Menu End-->
                <div class="outer-box clearfix">
                    
                    <!-- Btn Box -->
                    <div class="btn-box">
                        <?php if(session('caAuth')): ?>
                        <?php
                            $caname = DB::table('members')->where('email',session('caAuth'))->first()->fname;
                        ?>
                        <a href="/caDashboard" class=""><span class="text-uppercase text-white rounded mt-2"> <?php echo e($caname); ?></span></a>
                        <?php elseif(session('csAuth')): ?> 
                        <?php
                            $csname = DB::table('members')->where('email',session('csAuth'))->first()->fname;
                        ?>
                        <a href="/csDashboard" class=""><span class="text-uppercase text-white rounded mt-2"><?php echo e($csname); ?> </span></a>
                        <?php elseif(session('cmaAuth')): ?> 
                        <?php
                            $cmaname = DB::table('members')->where('email',session('cmaAuth'))->first()->fname;
                        ?>
                        <a href="/cmaDashboard" class=""><span class="text-uppercase text-white rounded mt-2"> <?php echo e($cmaname); ?> </span></a>
                        <?php elseif(session('layerAuth')): ?> 
                        <?php
                            $lawyername = DB::table('members')->where('email',session('layerAuth'))->first()->fname;
                        ?>
                        <a href="/lawyerDashboard" class=""><span class="text-uppercase text-white rounded mt-2"> <?php echo e($lawyername); ?> </span></a>
                        <?php elseif(session('customerAuth')): ?>
                        <?php
                            $customername = DB::table('members')->where('email',session('customerAuth'))->first()->fname;
                        ?>
                        <a href="/customerDashboard" class=""><span class="text-uppercase text-white rounded mt-2"><?php echo e($customername); ?></span></a>
                        <?php else: ?>
                        <a href="/login" class="theme-btn btn-style-one"><span class="txt">Sign In</span></a>
                        <?php endif; ?>
                    </div>
                    
                    
                    <!-- Mobile Navigation Toggler -->
                    <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
                    
                </div>
                
            </div>
        </div>
    </div><!-- End Sticky Menu -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><span class="icon flaticon-multiply"></span></div>
        
        <nav class="menu-box">
            <div class="nav-logo"><a href="/"><img src="images/logo-2.png" alt="fileurtax logo" title=""></a></div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
        </nav>
    </div><!-- End Mobile Menu -->

</header>
<!-- End Main Header -->
</div>


<?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/components/home/header.blade.php ENDPATH**/ ?>