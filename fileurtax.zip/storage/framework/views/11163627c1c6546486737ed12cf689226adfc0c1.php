<?php $__env->startSection("title"); ?>
Welcome to FileUrTax, providing multi-disciplinary legal solutions. 
<?php $__env->stopSection(); ?>

<?php $__env->startSection("description"); ?>
At FileUrTax, we provide legal facilitator services for a range of issues that include LLP Registration, filing ITR Returns, getting a certificate of GST Registration, or finding advocates near me at affordable rates.
<?php $__env->stopSection(); ?>

<?php $__env->startSection("keywords"); ?>
e filing for income tax,income tax e filing in india,e filing of itr,income tax returning,llp registration,filing itr return,income return online,aoc4,certificate of gst registration,chartered accountants,lawyers,advocates near me,lawyers corporate
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customcss'); ?>
<link rel="stylesheet" href="css/feedback.css" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
<script src="js/feedback.js"></script>
<?php $__env->stopSection(); ?>

<?php if (isset($component)) { $__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Topbar::class, []); ?>
<?php $component->withName('home.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8)): ?>
<?php $component = $__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8; ?>
<?php unset($__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Header::class, []); ?>
<?php $component->withName('home.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93)): ?>
<?php $component = $__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93; ?>
<?php unset($__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal832caf47ac0bd19d7d753f0c82b76a3f669ee8a2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Section::class, []); ?>
<?php $component->withName('home.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal832caf47ac0bd19d7d753f0c82b76a3f669ee8a2)): ?>
<?php $component = $__componentOriginal832caf47ac0bd19d7d753f0c82b76a3f669ee8a2; ?>
<?php unset($__componentOriginal832caf47ac0bd19d7d753f0c82b76a3f669ee8a2); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal623176770b884771a62630739c42e1bd0e3c713f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Footer::class, []); ?>
<?php $component->withName('home.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal623176770b884771a62630739c42e1bd0e3c713f)): ?>
<?php $component = $__componentOriginal623176770b884771a62630739c42e1bd0e3c713f; ?>
<?php unset($__componentOriginal623176770b884771a62630739c42e1bd0e3c713f); ?>
<?php endif; ?><?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/welcome.blade.php ENDPATH**/ ?>