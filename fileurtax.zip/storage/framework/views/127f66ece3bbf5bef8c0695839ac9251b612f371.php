<?php
    $csDetails =DB::table('members')
    ->where('email',session('csAuth'))
    ->first();
?> 
<nav class="sidebar sidebar-offcanvas dynamic-active-class-disabled" id="sidebar">
    <ul class="nav">
      <li class="nav-item nav-profile not-navigation-link">
        <div class="nav-link">
          <div class="user-wrapper">
            <div class="profile-image">
              <?php if($csDetails->profileImage == NULL): ?>
              <img class="img-xs rounded-circle" src="images/userPic.png" alt="Profile image"> </a>
              <?php else: ?>
              <img class="img-xs rounded-circle adminProfileImage" src="https://fileurtax-jobaroundyou.s3.ap-south-1.amazonaws.com/fileurtax/serviceprovider/<?php echo e(session('csAuth')); ?>/<?php echo e($csDetails->profileImage); ?>" alt="Profile image"> </a>
              <?php endif; ?>
              
            </div>
            <div class="text-wrapper">
              <p class="profile-name text-capitalize"><?php echo e($csDetails->fname); ?> </p>
              <div class="dropdown" data-display="static">
                <a href="#" class="nav-link d-flex user-switch-dropdown-toggler" id="UsersettingsDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                  <small class="designation text-muted">Online</small>
                  <span class="status-indicator online"></span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </li>
     
      <li class="nav-item">
        <a href="csDashboard" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-view-dashboard text-primary"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="csServiceRequest" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-page-previous-outline text-warning"></i>
          <span class="menu-title">Service Request</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="csActiveServices" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-briefcase text-success"></i>
          <span class="menu-title">Running Services</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="csviewbookedappointment" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-calendar"></i>
          <span class="menu-title">Appointments</span>
        </a>
      </li>
      
      <li class="nav-item">
        <a href="csQuotation" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-calendar-edit text-info"></i>
        <span class="menu-title">Quotation Request</span>
        </a>
        </li>
        <li class="nav-item">
          <a href="csrequestPayment" class="nav-link" aria-expanded="" aria-controls="basic-ui">
            <i class="mdi mdi-contactless-payment text-danger"></i> 
            <span class="menu-title">Make Payments</span>
          </a>
        </li>
      <li class="nav-item">
        <a href="cshelp" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-help-circle text-primary"></i>
        <span class="menu-title">Support</span>
        </a>
        </li>
        <li class="nav-item">
          <a href="/showcustomer" class="nav-link" aria-expanded="" aria-controls="basic-ui">
            <i class="mdi mdi-chat text-success"></i>
            <span class="menu-title">Chat</span>
          </a>
        </li>      
      <li class="nav-item">
        <a href="UpdateCs" class="nav-link" aria-expanded="" aria-controls="basic-ui">
        <i class="mdi mdi-table-edit"></i>
          <span class="menu-title">Edit Profile</span>
        </a>
      </li>
      <li class="nav-item">
        <a href="csLogOut" class="nav-link" aria-expanded="" aria-controls="basic-ui">
          <i class="mdi mdi-logout text-danger"></i>
          <span class="menu-title">LOG OUT</span>
        </a>
      </li>  
      
 </ul>
</nav>

<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
    integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/script.js"></script>
<script src="js/perfect-scrollbar.min.js?cache=<?php echo time(); ?>"></script>
<script src="js/off-canvas.js?cache=<?php echo time(); ?>"></script>
<script src="js/hoverable-collapse.js?cache=<?php echo time(); ?>"></script>
<script src="js/misc.js?cache=<?php echo time(); ?>"></script>
<script src="js/settings.js?cache=<?php echo time(); ?>"></script><?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/components/CS/sidebar.blade.php ENDPATH**/ ?>