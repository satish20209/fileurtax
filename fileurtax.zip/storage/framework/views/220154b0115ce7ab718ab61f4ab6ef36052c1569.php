<?php
    $customerDetails = DB::table('members')->where('email',session('customerAuth'))->first();
?>

<div class="row text-center">
    <div class="col-12">
        <h3>Basic Details</h3>
      <div class="card text-center mt-5 mb-5">
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <tr>
                  <th class="bg-primary text-light"> Name </th>
                  <td> <?php echo e($customerDetails->fname); ?> </td>
                </tr>
                <tr>
                    <th class="bg-primary text-light"> Contact Number </th>
                    <td> <?php echo e($customerDetails->mobile); ?> </td>
                </tr>
                <tr>
                    <th class="bg-primary text-light"> Email </th>
                    <td> <?php echo e($customerDetails->email); ?> </td>
                </tr>
                <tr>
                    <th class="bg-primary text-light"> Requirements </th>
                    <td> 
                        <?php
                            $customerRequirement = DB::table('customer_requirements')
                            ->where('user_id',$customerDetails->id)
                            ->first();
                        ?>

                        <?php if($customerRequirement): ?>
                            <?php echo e($customerRequirement->requirements); ?>

                        <?php else: ?>
                            No Requirements Mentioned
                        <?php endif; ?>
                    </td>
                </tr>
              
            </table>
          </div>
      </div>
    </div>
</div>


<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
            <div class="text-center mb-5">
                <h4>What Type of Service Are You Looking For?</h4>
            </div>
            <form action="updateCustomerReq" method="POST" autocomplete="on" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-2">
                    <label for="service">Select Services</label>
                    <select required id="service" class="services mb-2" style="color: black;width:100%;border-radius:5px;padding:5px;"  name="services" id="">
                        <option value="L">Lawyer</option>
                        <option value="CA">CA</option>
                        <option value="CS">CS</option>
                        <option value="CMA">CMA</option>
                    </select>
                </div>
                <div class="form-group mb-2">
                    <textarea required class="form-control" name="requirements" id="requirements" maxlength="150" minlength="20" rows="3" placeholder="Requirements/Needs "></textarea>
                </div>
                <div class="form-group mb-5">
                    <label class="lable"  for="Files">Upload Files</label>
                    <input id="Files" required multiple="multiple" type="file" name="files[]" title="upload file"  />
                </div>
                <div class="d-flex justify-content-between mb-5">
                    <div>
                        <input type="submit" class="btn-get btn btn-primary ml-auto" value="submit">
                    </div>
                </div>
            </form>
        </div>
      </div>
    </div>
</div>





<?php
    $serviceRequest = DB::table('services_requests')
    ->where(
        [
            'customer_id' => $customerDetails->id,
            'status'      => 1,
        ]
    )
    ->first();
?>

<?php
    $customerReq = DB::table('customer_requirements')
    ->where('user_id',$customerDetails->id)
    ->first();
?>



<?php if($customerDetails->lat !== NULL): ?>
    <?php if($serviceRequest): ?>
        <div class="row text-center">
            <div class="col-md-6 col-xl-4 grid-margin stretch-card">
                <?php
                    $serviceProviders = DB::table('members')
                    ->where('id',$serviceRequest->service_provider_id)
                    ->select(DB::raw("members.*,
                    ( 6371 * acos( cos( radians($customerDetails->lat) ) *
                    cos( radians( lat ) )
                    * cos( radians( longt ) - radians($customerDetails->longt)
                    ) + sin( radians($customerDetails->lat) ) *
                    sin( radians( lat ) ) )
                    ) AS distance"))
                    ->first();
                ?>
                <?php if($serviceProviders->lat): ?>
                    <div class="card ">
                        <div class="card-body">
                                <?php if($serviceProviders->profileImage == NULL): ?>
                                <img src="images/userPic.png" class="serviceProviderProfile" alt="Service Providers Profile Image">
                                <?php else: ?>
                                    <img src="/fileurtax/serviceprovider/<?php echo e($serviceProviders->email); ?>/<?php echo e($serviceProviders->profileImage); ?>" class="serviceProviderProfile" alt="Service Providers Profile Image">
                                <?php endif; ?>
                            <div class="event py-2">
                                <p class="mb-2 font-weight-medium">Name : <?php echo e($serviceProviders->fname); ?></p>
                                <?php if($serviceProviders->role == "L"): ?>
                                <p class="mb-1 font-weight-medium">Role : Lawyer</p>
                                <?php elseif($serviceProviders->role == "CA"): ?>
                                <p class="mb-1 font-weight-medium">Role : CA</p>
                                <?php elseif($serviceProviders->role == "CMA"): ?>
                                <p class="mb-1 font-weight-medium">Role : CMA</p>
                                <?php elseif($serviceProviders->role == "CS"): ?>
                                <p class="mb-1 font-weight-medium">Role : CS</p>
                                <?php endif; ?>
                                <p class="text-mute">
                                    <?php if(round($serviceProviders->distance) == 0): ?>
                                    <p class="mb-2 font-weight-medium">Distance : Within 1 Km</p>
                                    <?php else: ?>
                                    <p class="mb-2 font-weight-medium">Distance : Within <?php echo e(round($serviceProviders->distance)); ?> Km </p>
                                    <?php endif; ?>
                                </p>
                                <button type="button" disabled class="btn bg-secondary text-dark mb-2">Request Accepted</button>
                                <?php
                                    $servicerequest = DB::table('services_requests')->where('customer_id',$customerDetails->id)->first();
                                    // print_r($servicerequest);
                                ?>
                                <?php if($servicerequest->apptime == NULL): ?>
                                <button type="button" lid="<?php echo e($serviceProviders->id); ?>" custid="<?php echo e($customerDetails->id); ?>" layername="<?php echo e($serviceProviders->fname); ?>" customrename="<?php echo e($customerDetails->fname); ?>" class="btn bg-primary text-light bookAppointmentbtn mb-2">Book Appointment</button>
                                <?php else: ?>
                                <button type="button"  class="btn bg-secondary text-dark mb-2">Appointment Booked</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="row text-center">
            <?php if($customerReq): ?>
                <?php
                    $serviceProviders = DB::table('members')
                    ->where('role',$customerReq->parent_service)
                    ->select(DB::raw("members.*,
                    ( 6371 * acos( cos( radians($customerDetails->lat) ) *
                    cos( radians( lat ) )
                    * cos( radians( longt ) - radians($customerDetails->longt)
                    ) + sin( radians($customerDetails->lat) ) *
                    sin( radians( lat ) ) )
                    ) AS distance"))
                    ->orderBy('distance', 'asc')
                    ->get();
                ?>
                <?php $__currentLoopData = $serviceProviders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceProvider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($serviceProvider->lat): ?>
                        <div class="col-md-6 col-xl-4 grid-margin stretch-card">
                            
                            <div class="card text-center">
                                <div class="card-body">
                                    <?php if($serviceProvider->profileImage == NULL): ?>
                                        <img src="images/userPic.png" class="serviceProviderProfile" alt="Service Providers Profile Image">
                                    <?php else: ?>
                                    <img src="/fileurtax/serviceprovider/<?php echo e($serviceProvider->email); ?>/<?php echo e($serviceProvider->profileImage); ?>" class="serviceProviderProfile" alt="Service Providers Profile Image">
                                    <?php endif; ?>
                                
                                    <div class="event py-3">
                                        <p class="mb-2 font-weight-medium"><?php echo e($serviceProvider->fname); ?></p>
                                        <p class="text-mute">
                                            <?php if(round($serviceProvider->distance) == 0): ?>
                                                Within 1 Km
                                            <?php else: ?>
                                                Within <?php echo e(round($serviceProvider->distance)); ?> Km
                                            <?php endif; ?>
                                        </p>
                                        <form action="serviceRequest" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="customer_id" value="<?php echo e($customerDetails->id); ?>">
                                            <input type="hidden" name="service_provider_id" value="<?php echo e($serviceProvider->id); ?>">
                                            <?php
                                                $requestExists = DB::table('services_requests')->where(
                                                    [
                                                        'customer_id' => $customerDetails->id,
                                                        'service_provider_id' => $serviceProvider->id,
                                                        'status' => 0
                                                    ]
                                                    )->exists();
                        
                                                    $requestDeny = DB::table('services_requests')->where(
                                                    [
                                                        'customer_id' => $customerDetails->id,
                                                        'service_provider_id' => $serviceProvider->id,
                                                        'status' => -1
                                                    ]
                                                    )->exists();
                                            ?>
                                            <?php if(!$requestExists): ?>
                                                <?php if($requestDeny): ?>
                                                    <button type="button" class="btn bg-danger text-light">Request Denied</button>
                                                <?php else: ?>
                                                    <button type="submit" class="btn bg-primary text-light">Send Request</button>
                                                <?php endif; ?>
                                            <?php else: ?>

                                                <button type="button" class="btn bg-success text-light">Request Sent</button>
                                            <?php endif; ?>
                                    
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php else: ?>
    <div class="row text-center">
        <div class="col">
            <div class="spinner-grow text-primary" role="status"></div>
            <div class="spinner-grow text-secondary" role="status"></div>
            <div class="spinner-grow text-success" role="status"></div>
            <div class="spinner-grow text-danger" role="status"></div>
            <div class="spinner-grow text-warning" role="status"></div>
            <div class="spinner-grow text-info" role="status"></div>
            <div class="spinner-grow text-light" role="status"></div>
            <p>Plaese Enable Your Location to Get Best Lawyer Suggestions</p>
            <button onclick="updateCustomerLocation()" class="btn btn-primary">Enable</button>
        </div>
    </div>

    
    <script>
        function updateCustomerLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showCustomerPosition);
            } else { 
                alert("Geolocation is not supported by this browser.");
            }
        }
        function showCustomerPosition(position) {
            var lat = position.coords.latitude; 
            var longt = position.coords.longitude;
            $.ajax({
                url: 'updateCustomerLocation',
                method: 'POST',
                data: {
                    lat:lat,
                    longt:longt,
                    customer_id:'<?php echo e($customerDetails->id); ?>',
                    _token:'<?php echo e(csrf_token()); ?>',
                },
                success:function(status) {
                    window.location.reload();
                },
                error: function(status) {
                    window.location.reload();
                },
            });
            
        }
    </script>
<?php endif; ?>


<div class="modal fade" id="bookAppointmentmodel" tabindex="-1" aria-labelledby="bookAppointmentmodelLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background: #fc0765">
                <h5 class="modal-title text-white"><b>Book Appointment</b></h5>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="layername">lawyer Name</label>
                    <input type="text" disabled name="layer" id="layername" class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Customer Name</label>
                    <input type="text" disabled name="customer" id="customername"  class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Select Appointment Date</label>
                    <input type="date" name="customer" id="appdate" class="form-control">
                </div>
                <div class="form-group">
                    <label for="customername">Select Appointment Time</label>
                    <input type="time" name="customer" id="apptime" class="form-control">
                </div>

                <div class="form-group">
                    <label for="customername">Select Time Period </label>
                    <select name="appointmenttime" id="appointmenttime" style="color: black;width:100%;border-radius:5px;padding:5px;">
                        <option value="15" selected>15 Minutes</option>
                        <option value="30">30 Minutes</option>
                        <option value="60">60 Minutes</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="customername"> Appointment Charge</label>
                    <input type="text" disabled name="feecharge" id="feecharge" class="form-control" value="300">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger bookAppointmentmodelclose" >Cancel</button>
                <button type="button" class="btn btn-primary booknowbtn"  >Book Now</button>
            </div>
        </div>
    </div>
</div>



    
<script>
    $.ajax({
        url:'checkCustomserRequirement',
        type:'POST',
        data: {
        '_token':'<?php echo e(csrf_token()); ?>',
        user_id:'<?php echo e($customerDetails->id); ?>',
        },
        success: function(response) {
            if (response.data == 'Not Found') {
                $('#staticBackdrop').modal('show');
            }
        
        //$('#staticBackdrop').modal('hide'); 
        },
        error: function(error) {
        
        },
    });
</script>

<script>
    $(document).ready(function(){
        $(".bookAppointmentmodelclose").click(function(){
            $("#bookAppointmentmodel").modal('hide');
        });

        $(".bookAppointmentbtn").click(function(){
            var layername = $(this).attr("layername"); 
            var customrename = $(this).attr("customrename"); 
            var layerid = $(this).attr("lid"); 
            var customreid = $(this).attr("custid");
            $("#bookAppointmentmodel").modal('show');
            $("#layername").val(layername);
            $("#layername").attr("lid",layerid);
            $("#customername").attr("custid",customreid);
            $("#customername").val(customrename);
           
        })

        $("#appointmenttime").on("change",function(){
            if($("#appointmenttime").val() == "15"){
            $("#feecharge").val("300");
            }
            else if($("#appointmenttime").val() == "30"){
                $("#feecharge").val("600");
            }
            else if($("#appointmenttime").val() == "60"){
                $("#feecharge").val("900");
            }
        })

        $(".booknowbtn").click(function(){
            var layerid = $("#layername").attr("lid"); 
            var customreid = $("#customername").attr("custid"); 
            if($("#appdate").val() == "" && $("#apptime").val() == ""){
                alert("please fill app filed")
            }
            else{
            $("#bookAppointmentmodel").modal('hide');
            $.ajax({
                url: 'bookappointment',
                type: 'get',
                data: {
                    '_token': '<?php echo e(csrf_token()); ?>',
                    lid:layerid,
                    custid:customreid,
                    appdate:$("#appdate").val(),
                    apptime:$("#apptime").val(),
                    timeperiod:$("#appointmenttime").val(),
                    fee:$("#feecharge").val()
                },
                success: function(response) {
                    
                   
                    $("#bookAppointmenteditmodel").modal('hide');
                    window.location.href = "/customerDashboard";
                },
                error: function(error) {
                    
                },
            });
        }
        })
    });
</script><?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/components/customer/dashboard.blade.php ENDPATH**/ ?>