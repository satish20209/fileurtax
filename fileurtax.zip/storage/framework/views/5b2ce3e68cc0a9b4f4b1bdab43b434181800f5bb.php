<?php
    $laywerDetails =DB::table('members')
    ->where('email',session('layerAuth'))
    ->first();
?>

<?php
//---------------|-------------//
//   Status      |  Code      //
//---------------|-----------//
//   Sent        |  0       //
//---------------|---------//
//   Accepted    |  1     //
//---------------|-------//
//   Denied      |  -1  //
//---------------|-----//

    $serviceRequests = DB::table('services_requests')
    ->where(
        [
            'service_provider_id' => $laywerDetails->id,
            'status' => '0',
        ]
            )
        ->get();
    $serviceRequestsExists = DB::table('services_requests')
    ->where(
        [
            'service_provider_id' => $laywerDetails->id,
            'status' => '0',
        ]
            )
    ->exists();
?>
<div class="text-center mb-5">
    <h3>All Service Requests</h3>
</div>





  <div class="row text-center mt-5 mr-auto ml-auto">
            
            <?php if($serviceRequestsExists): ?>
                <?php $__currentLoopData = $serviceRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $customers = DB::table('members')->where('id',$serviceRequest->customer_id)->first();
                ?>
                <div class="col col-md-4 col-xl-4 d-flex align-items-center">
                <div class="card text-center m-3">
                    <div class="card-body">
                        <div class="event py-3">
                            <p class="mb-5 font-weight-bold"><?php echo e($customers->fname); ?></p>
                            <div class="d-flex align-items-center">
                                <form action="lawyerAcceptRequest" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="service_provider_id" value="<?php echo e($laywerDetails->id); ?>">
                                    <input type="hidden" name="customer_id" value="<?php echo e($customers->id); ?>">
                                    <button type="submit" class="btn btn-success text-light mr-3">Accept</button>
                                </form>
                                <form action="lawyerDenyRequest" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="service_provider_id" value="<?php echo e($laywerDetails->id); ?>">
                                    <input type="hidden" name="customer_id" value="<?php echo e($customers->id); ?>">
                                    <button type="submit" class="btn btn-danger text-light mr-3">Deny</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="text-center NotAvailable">
                    <p class="text-mute">No Service Request Recieved</p>
                </div>
            <?php endif; ?>

            
        
   
   

    
  </div>

  
  
  <?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/components/lawyer/recentServices.blade.php ENDPATH**/ ?>