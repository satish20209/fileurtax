

<div id="fafabox">
	<i class="fa fa-angle-right text-white iconchenge" style="font-size: 35px;"></i>
</div>
<div class="help-feedback-box">
	<div id="feedback" style="cursor: pointer">
		<p>Feedback</p>
	</div>  
</div>
   <!-- model for help -->
  <!-- Modal -->

  
   <div class="modal fade" id="helpmodel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered ">
      <div class="modal-content ">
         <div class="modal-header">
         <h5 class="ms-2 modal-title text-dark">Feedback</h5>
         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
		 <div class="modal-body p-4">
                    <!-- <h2></h2>  -->
                    <p> Please provide your feedback below: </p>
                    <form method="post" action="feedbacks">
                        <?php echo csrf_field(); ?>
						<?php
                            if(session('customerAuth')){
                                $user=DB::table('members')->where('email',session('customerAuth'))->first();
                                if($user){
                                    echo '
                                        <div class=" form-group">
                                            <label for="name"> Your Name:</label>
                                            <input type="text" class="name form-control" id="name" readonly name="name" value="'.$user->fname.'" required>
                                        </div>
                                        <div class=" form-group">
                                            <label for="email"> Email:</label>
                                            <input type="email" class="email form-control" id="email" readonly name="email" value="'.$user->email.'" required>
                                        </div>';
                                }
                            }else{
                            echo '
                                <div class=" form-group">
                                    <label for="name"> Your Name:</label>
                                    <input type="text" class="name form-control" id="name"  name="name"  required>
                                </div>
                                <div class=" form-group">
                                    <label for="email"> Email:</label>
                                    <input type="email" class="email form-control" id="email"  name="email"  required>
                                </div>';
                            }
                        ?>
                        
                        <div class="mt-2 row">
                            <div class="col-sm-12 form-group">
                                <label>How do you rate your overall experience?</label>
                                <p>
                                <span val="1" class="fa fa-star star checked"></span>
                                <span val="2" class="fa fa-star star "></span>
                                <span val="3" class="fa fa-star star "></span>
                                <span val="4" class="fa fa-star star"></span>
                                <span val="5" class="fa fa-star star"></span>
                                <input hidden class="rate" value="1" name="rate" type="text">
                                   
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <label for="comments"> Comments:</label>
                                <textarea class="message form-control" type="textarea" required name="message" id="comments" maxlength="150" minlength="20" placeholder="Your Comments" maxlength="6000" rows="7"></textarea>
                            </div>
                        </div>
                        
                        
                        
                        
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <button type="submit" class="w-100 mt-2 submit btn btn-lg btn-warning btn-block" >Submit </button>
                            </div>
                        </div>
                    </form>
                    <!-- <div id="success_message" style="width:100%; height:100%; display:none; "> <h3>Posted your feedback successfully!</h3> </div>
                    <div id="error_message" style="width:100%; height:100%; display:none; "> <h3>Error</h3> Sorry there was an error sending your form. </div> -->
		 </div>
      </div>
      </div>
   </div>
    <!-- end modal feedback form -->
<div>
   <!-- Banner Section -->
   <section class="banner-section">
		<!-- Social Nav -->
		<ul class="social-nav">
			<li class="facebook"><a href="https://www.facebook.com/Fileurtax-106473432117319"  class="bg-white" target="_blank"><span class="fa fa-facebook-f text-primary"></span></a></li>
			<li class="twitter"><a href="https://twitter.com/fileurtax" target="_blank"  class="bg-white"><span class="fa fa-twitter text-primary"></span></a></li>
			<li class="linkedin"><a href="https://www.linkedin.com/company/fileurtax/"  class="bg-white" target="_blank"><span class="fa fa-linkedin text-primary"></span></a></li>
			<li class="linkedin"><a href="https://www.youtube.com/channel/UCxthofo_PTYSelm-Gwju4pA/about" class="bg-white" target="_blank"><span class="fa fa-youtube text-danger"></span></a></li>
			<li class="linkedin"><a href="https://www.instagram.com/fileurtax/" target="_blank" class="bg-white"><span class="fa fa-instagram text-danger"></span></a></li>
		</ul>
		<div class="main-slider-carousel owl-carousel owl-theme">
            
            <div class="slide" style="background-image: url(images/main-slider/slider4.jpg);background:cover;">
				<div class="auto-container">
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="title">Chartered Accountant</div>
							<h1>Best Chartered Accountant</h1>
							<div class="text">Consult the Chartered Accountant, to resolve/file your Taxation.</div>
							<div class="btns-box">
								<a href="bookconsultation" class="theme-btn btn-style-one"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			
			<div class="slide" style="background-image: url(images/main-slider/slider2.png);background:cover;">
				<div class="auto-container">
					
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="title">Cost Management Accountant</div>
							<h1>Best Cost Management Accountant</h1>
							<div class="text">Our highly skilled and professional Cost Management Accountants help your profit boost up and minimise your cost in a very efficient way.</div>
							<div class="btns-box">
								<a href="bookconsultation" class="theme-btn btn-style-one"><span class="txt">book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>
			<div class="slide" style="background-image: url(images/main-slider/slider3.png);background:cover;">
				<div class="auto-container">
					
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="title">Company Secretary</div>
							<h1>Best Company Secretary</h1>
							<div class="text">A CS is responsible for maintaining and auditing the company’s tax returns, keeping records, advising the board of directors regarding the financial health of the company and ensuring that the company complies with legal and statutory regulations.</div>
							<div class="btns-box">
								<a href="bookconsultation" class="theme-btn btn-style-one"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>

			<div class="slide" style="background-image: url(images/main-slider/slider1.png);background:cover;">
				<div class="auto-container">
					
					<!-- Content Column -->
					<div class="content-column">
						<div class="inner-column">
							<div class="title">Legal Services</div>
							<h1>Legal Services</h1>
							<div class="text">A legal content writer will be able to explain complex legal matters to readers, which will help strengthen the connection between your company and a potential client and turn them into clients.</div>
							<div class="btns-box">
								<a href="bookconsultation" class="theme-btn btn-style-one"><span class="txt">Book Consultation <i class="arrow flaticon-right"></i></span></a>
							</div>
						</div>
					</div>
					
				</div>
			</div>

			
			
		</div>
		
	</section>
	<!-- End Banner Section -->
	
	<!-- Services Section -->
	<section class="services-section">
		<div class="auto-container">
			<div class="inner-container">
				<div class="row clearfix">
					
					<!-- Services Block -->
					<div class="services-block col-lg-6 col-md-12 col-sm-12">
						<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
							<div class="content">
								<div class="icon flaticon-file"></div>
								<h4><a href="bookconsultation">Chartered Accountant</a></h4>
								<div class="text">Consult the Chartered Accountant, to resolve/file your Taxation. Being the Member of the Institute of Accountants, he/she will help resolving all your Taxation requirements.</div>
							</div>
							<div class="d-flex justify-content-end">
								<a href="bookconsultation" style="background: #e1a122;" class="p-2 text-white rounded">Book Consulation <i class="flaticon-right"></i></a>
							</div>
							
						</div>
					</div>
					
					<!-- Services Block -->
					<div class="services-block col-lg-6 col-md-12 col-sm-12">
						<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
							<div class="content">
								<div class="icon flaticon-file-1"></div>
								<h4><a href="bookconsultation">Cost Management Accountant</a></h4>
								<div class="text">Our highly skilled and professional Cost Management Accountants help your profit boost up and minimise your cost in a very efficient way.</div>
							</div>
							<div class="d-flex justify-content-end">
								<a href="bookconsultation" style="background: #e1a122;" class="p-2 text-white rounded">Book Consulation <i class="flaticon-right"></i></a>
							</div>
						</div>
					</div>
					
					<div class="services-block col-lg-6 col-md-12 col-sm-12">
						<div class="inner-box wow fadeInRight" data-wow-delay="150ms" data-wow-duration="1500ms">
							<div class="content">
								<div class="icon flaticon-group"></div>
								<h4><a href="bookconsultation">Company Secretary</a></h4>
								<div class="text">A CS is responsible for maintaining and auditing the company’s tax returns, keeping records, advising the board of directors regarding the financial health of the company and ensuring that the company complies with legal and statutory regulations.</div>
							</div>
							<div class="d-flex justify-content-end">
								<a href="bookconsultation" style="background: #e1a122;" class="p-2 text-white rounded">Book Consulation <i class="flaticon-right"></i></a>
							</div>
						</div>
					</div>

					<!-- Services Block -->
					<div class="services-block col-lg-6 col-md-12 col-sm-12">
						<div class="inner-box wow fadeInLeft" data-wow-delay="150ms" data-wow-duration="1500ms">
							<div class="content">
								<div class="icon flaticon-umbrella-1"></div>
								<h4><a href="bookconsultation">Legal Services</a></h4>
								<div class="text">A legal content writer will be able to explain complex legal matters to readers, which will help strengthen the connection between your company and a potential client and turn them into clients.</div>
							</div>
							<div class="d-flex justify-content-end">
								<a href="bookconsultation" style="background: #e1a122;" class="p-2 text-white rounded">Book Consulation <i class="flaticon-right"></i></a>
							</div>
						</div>
					</div>
					
					<!-- Services Block -->
					
					
				</div>
			</div>
		</div>
	</section>
	<!-- our service start-->
	<section class="practice-section" style="background-image: url(images/background/pattern-2.png);background:cover;">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<h2>Our Services</h2>
			</div>
			<div class="inner-container">
				<div class="clearfix">
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #06b1ac">
							<div class="icon flaticon-car-1"></div>
							<h5><a href="/charteredaccountant">Chartered Accountant</a></h5>
							<div class="text">Consult the Chartered Accountant, to resolve/file your Taxation.</div>
							<a class="arrow flaticon-right-arrow-3" href="/charteredaccountant"></a>
						</div>
					</div>
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #007cc4">
							<div class="icon flaticon-briefcase"></div>
							<h5><a href="/costmanagementaccountant">Cost Management ACC.</a></h5>
							<div class="text">Our highly skilled and professional Cost Management Accountants.</div>
							<a class="arrow flaticon-right-arrow-3" href="/costmanagementaccountant"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #e39f02">
							<div class="icon flaticon-save-money"></div>
							<h5><a href="/companysecretary">Company Secretary</a></h5>
							<div class="text">A CS is responsible for maintaining and auditing the company’s tax.</div>
							<a class="arrow flaticon-right-arrow-3" href="/companysecretary"></a>
						</div>
					</div>
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #330ec4">
							<div class="icon flaticon-handcuffs-1"></div>
							<h5><a href="/legalservices">Legal Services</a></h5>
							<div class="text">A legal content writer will be able to explain complex legal matters.</div>
							<a class="arrow flaticon-right-arrow-3" href="/legalservices"></a>
						</div>
					</div>
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #b66803">
							<div class="icon flaticon-balance"></div>
							<h5><a href="/investment">Investment</a></h5>
							<div class="text">The investing of money or capital in order to gain profitable returns.</div>
							<a class="arrow flaticon-right-arrow-3" href="/investment"></a>
						</div>
					</div>
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #47389c">
							<div class="icon flaticon-law"></div>
							<h5><a href="/loan">Loan</a></h5>
							<div class="text">The loan request should clearly communicate the strategic goals</div>
							<a class="arrow flaticon-right-arrow-3" href="/loan"></a>
						</div>
					</div>
					<!-- Practice Block -->

					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #134c8d">
							<div class="icon flaticon-injury"></div>
							<h5><a href="/personalfinance">Personal Finance</a></h5>
							<div class="text">personal finance is the financial management which an individual.</div>
							<a class="arrow flaticon-right-arrow-3" href="/personalfinance"></a>
						</div>
					</div>
					
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #d90481">
							<div class="icon flaticon-notebook"></div>
							<h5><a href="bookconsultation">Other Services</a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<!-- our service end -->
	<!-- our service start-->
	<section class="practice-section" style="background-image: url(images/background/pattern-2.png);background:cover;">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<h2>Our Process</h2>
			</div>
			<div class="inner-container">
				<div class="clearfix">
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #06b1ac">
							<div class="icon"> 
								<img src="images/ourprocess/Planning.png" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="/charteredaccountant">Planning</a></h5>
							<div class="text">Consult the Chartered Accountant, to resolve/file your Taxation.</div>
							<a class="arrow flaticon-right-arrow-3" href="/charteredaccountant"></a>
						</div>
					</div>
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #007cc4">
							<div class="icon"> 
								<img src="images/ourprocess/Accounting.png" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="/costmanagementaccountant">Accounting</a></h5>
							<div class="text">Our highly skilled and professional Cost Management Accountants.</div>
							<a class="arrow flaticon-right-arrow-3" href="/costmanagementaccountant"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #e39f02">
							<div class="icon"> 
								<img src="images/ourprocess/Filling.jfif" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="/companysecretary">Filling </a></h5>
							<div class="text">A CS is responsible for maintaining and auditing the company’s tax.</div>
							<a class="arrow flaticon-right-arrow-3" href="/companysecretary"></a>
						</div>
					</div>
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #330ec4">
							<div class="icon"> 
								<img src="images/ourprocess/Awareness.jpg" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="/legalservices">Awareness </a></h5>
							<div class="text">A legal content writer will be able to explain complex legal matters.</div>
							<a class="arrow flaticon-right-arrow-3" href="/legalservices"></a>
						</div>
					</div>
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #b66803">
							<div class="icon"> 
								<img src="images/ourprocess/Projection.jpg" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="/investment">Projection </a></h5>
							<div class="text">The investing of money or capital in order to gain profitable returns.</div>
							<a class="arrow flaticon-right-arrow-3" href="/investment"></a>
						</div>
					</div>
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #47389c">
							<div class="icon"> 
								<img src="images/ourprocess/Implementation.jpg" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="/loan">Implementation </a></h5>
							<div class="text">The loan request should clearly communicate the strategic goals</div>
							<a class="arrow flaticon-right-arrow-3" href="/loan"></a>
						</div>
					</div>
					<!-- Practice Block -->

					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #134c8d">
							<div class="icon"> 
								<img src="images/ourprocess/Precautions.png" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="/personalfinance">Precautions </a></h5>
							<div class="text">personal finance is the financial management which an individual.</div>
							<a class="arrow flaticon-right-arrow-3" href="/personalfinance"></a>
						</div>
					</div>
					
					<!-- Practice Block -->
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #d90481">
							<div class="icon"> 
								<img src="images/ourprocess/Road map.png" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="bookconsultation">Road map</a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #2004d9">
							<div class="icon"> 
								<img src="images/ourprocess/Deliverables.png" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="bookconsultation">Deliverables</a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #04d9a7">
							<div class="icon"> 
								<img src="images/ourprocess/Impact.png" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="bookconsultation">Impact </a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #85a806">
							<div class="icon"> 
								<img src="images/ourprocess/Globalisation.jpg" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="bookconsultation">Globalisation</a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #a91700">
							<div class="icon"> 
								<img src="images/ourprocess/Track record.jpg" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="bookconsultation">Track record </a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #00aacc">
							<div class="icon"> 
								<img src="images/ourprocess/Justification.jpg" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="bookconsultation">Justification</a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #7204d9">
							<div class="icon"> 
								<img src="images/ourprocess/Process oriented.png" style="width:100px;border-radius:50%;height:100px;" alt="">
							</div>
							<h5><a href="bookconsultation">Process oriented</a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #d96004">
							<div class="icon"> 
								<img src="images/ourprocess/Organised.jpg" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="bookconsultation">Organised</a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					<div class="practice-block col-lg-3 col-md-6 col-sm-12">
						<div class="inner-box" style="background: #0447d9">
							<div class="icon"> 
								<img src="images/ourprocess/Track record.jpg" style="width:100px;border-radius:50%;height:100px; alt="">
							</div>
							<h5><a href="bookconsultation">Track record </a></h5>
							<div class="text">If you are seeking for any other services which is not listed you can.</div>
							<a class="arrow flaticon-right-arrow-3" href="bookconsultation"></a>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<!-- our service end -->
<!-- Clients Section -->
<section class="clients-section style-two">
	<div class="auto-container">
		<!-- Sec Title -->
		<div class="sec-title centered">
			<h2>TRUSTED COMPANIES</h2>
			<div class="text">For no one hates or runs away from pleasure itself because pleasure is harsh, but because it results in great pain<br> those who do not know how to follow pleasure with reason</div>
		</div>
		<div class="inner-container">
			<div class="sponsors-outer">
				<!--Sponsors Carousel-->
				<ul class="sponsors-carousel owl-carousel owl-theme">
					<li class="slide-item"><figure class="image-box"><a href="https://shivila.com" target="_blank"><img src="images/logo/shivila.jpg" alt="shivila"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Heera goods carrier-logos_black.png" alt="Heera goods carrier-logos_black"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Achyutam enterprise.png" alt="Achyutam enterprise"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Dina distributor-logos_black.png" alt="Dina distributor-logos_black"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Kausturi enterprises-logos.jpeg" alt="Kausturi enterprises-logos"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/KMD.png" alt="KDM"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Mondal Bros-logos_black.png" alt="Mondal Bros-logos_black"></a></figure></li>
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Vish technologies.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Adita traders.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Amit drugs and chemist.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Ayantika institute of technology.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Dayal agriculture.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/G N power and turbo.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/ILAshree marketers.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Krishni chemical.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Podder & sons.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Prabha designers.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Priti hospital.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Shashi properties.png" alt="Vish technologies"></a></figure></li>				
					<li class="slide-item"><figure class="image-box"><a href="/" target="_blank"><img src="images/logo/Vaibhavsupplier.png" alt="Vish technologies"></a></figure></li>				
				
				</ul>
				<!--End Sponsors Carousel-->
			</div>
		</div>
	</div>
</section>
<!-- End Clients Section -->

	
		<div class="sec-title centered mt-5">
			<h2>WHY CHOOSE US</h2>
		</div>
		<div class="p-3">
			<div class="row">
				<div class="col-1">
				</div>
				<div class="col-md-5 col-12">
					<img class="me-auto" src="images/ourprocess/whychooseus.png" alt="">
				</div>
				<div class="col-md-5 col-12">
					<p>We are a company who take cares of your fillings and legal part. When you are doing business you focus on that as when you are linked with us then nothing to worry about accounting and legality part .it will be manage by us. We provide services to client who was not even aware how much government schemes can help them which we make them understand and implement for them as well in there file. All legal cases we manage for the company so that they do not face any challenges in there business. We always make sure that client gets all benefits of taxation and we should pass them whenever required. Are services and unique which are all covered under one roof so client don't have to deal with different vendors as all services are provided by us to door step. We have high technology which can always keep client updated for their company tax , audit ,compliance and legal part. We implement all client requirements so that he can do their business easily without hesitation and freely.we always focus on delivery on time so no penalty is imposed.we always try to understand clients need and requirements and according to that we give them the best suggestion with easy price..</p>
				</div>
				<div class="col-1">
				</div>
			</div> 
		</div>
		
	

	<!-- Testimonail Section -->
	<section class="testimonial-section" style="background-image: url(images/background/pattern-3.png)">
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<h2>What Our CLients Said</h2>
			</div>
			<div class="inner-container">
				<div class="single-item-carousel owl-carousel owl-theme">
					
					<!-- Testimonial Block -->
					<div class="testimonial-block">
						<div class="inner-box" style="background: #06b1ac">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Clients constantly request you for advice to solve their problems. You’ve become quite the go-to person with our customers.</div>
							<div class="name">Raj Kumar</div>
						</div>
					</div>
					
					<!-- Testimonial Block -->
					<div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Feeling like they are really interested in the case being consulted, and the good attitude to see solutions and not problems.</div>
							<div class="name">Yogesh Kumar</div>
						</div>
					</div>
					
					<!-- Testimonial Block -->
					<div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Without minimizing my case because it was for a short period, my first impression is to come back and recommend other people. I was very welcome and well served professionally.</div>
							<div class="name">Arpan Kumar</div>
						</div>
					</div>

					<div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">They are highly knowledgeable in the legal matter, they maintain good communication with me, and I understand them.</div>
							<div class="name">RatiPriya</div>
						</div>
					</div>
					<div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Great customer service. Even when there was a problem with paperwork the employees continued helping us and fixed the issue.</div>
							<div class="name">nakul</div>
						</div>
					</div>


					<div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">We were provided excellent customer service. All responses were prompt and professional. Clearly, the upfront statement on our policy stated it was limited which told us that our preliminary research was not well thought out.</div>
							<div class="name">Ankit</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Get a lot of bad press, but in my experience customer services has been nothing short of excellent.</div>
							<div class="name">Monu</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Excellent customer service! Whenever I needed something they were there for me. Thank you guys.</div>
							<div class="name">rahul</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Very polite and helpful customer service. Response was very satisfactory, given the current health emergency.</div>
							<div class="name">anshul</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Great customer service, no hold time when you call. Rates are good.</div>
							<div class="name">Aditya</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Great customer service. Didn’t need to use my policy but excellent at answering questions.</div>
							<div class="name">Harsh</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Great customer service very knowledgeable and helpful. Policy was specific to my needs.</div>
							<div class="name">Ritik</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Stores always nice and clean, friendly customer service always helping and showing around if i cannot find something.</div>
							<div class="name">Manyank</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">I truly love the top notch friendly and very professional customer service I've received from fileurtax</div>
							<div class="name">manoj</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Customer service is obviously their strategy and it shows. I have referred others already.</div>
							<div class="name">Priyanka</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Great customer service. Even when there was a problem with paperwork the employees continued helping us and fixed the issue. Very patient workers and quick, easy and painless process.</div>
							<div class="name">Sanjib</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">A fantastic organisation! Great cutomer support from beginning to end of the process. The team are really informed and go the extra mile at every stage. I would recommend them unreservedly.</div>
							<div class="name">Sandeep</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Great service, efficient communication and a really easy way to get a mortgage with lots of help and support to get the right deal.</div>
							<div class="name">Santosh</div>
					</div>
					</div><div class="testimonial-block">
						<div class="inner-box">
							<div class="author-image">
								<img src="images/guest-user.png" alt="laywerProfile" style="width:101px;border-radius:50%; " />
							</div>
							<span class="quote-icon flaticon-quote-1"></span>
							<div class="text">Great customer service! The man I spoke with was very helpful in answering questions as well as helping in finding the best hotel for my husband and I.</div>
							<div class="name">Sanjay</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</section>
	<!-- End Testimonail Section -->
</div><?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/components/home/section.blade.php ENDPATH**/ ?>