
<div class="page-wrapper">	
	<!-- Page Title -->
    <section class="page-title style-two" style="background-image:url(images/background/1.jpg)">
    	<div class="auto-container">
			<h1>Our Blog</h1>
			<ul class="page-breadcrumb">
				<li><a href="/">Home</a></li>
				<li>Blog</li>
			</ul>
        </div>
    </section>
    <!-- End Page Title -->
	
	<!-- Sidebar Page Container -->
    <div class="sidebar-page-container">
    	<div class="auto-container">
        	<div class="row clearfix">
				
				<!-- Content Side -->
                <div class="content-side col-lg-8 col-md-12 col-sm-12">
                	<div class="blog-classic">
						<?php
						$blogs=DB::table('blogs')->paginate(2);
						// print_r($blogs);
						?>
						<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					
						<!-- News Block -->
						<div class="news-block"  blogId="<?php echo e($blog->id); ?>">
							<div class="inner-box">
								<div class="image">
									<a href="read_blog?id=<?php echo e($blog->id); ?>" target="_blank"><img src="https://fileurtax-jobaroundyou.s3.ap-south-1.amazonaws.com/fileurtax/blogs/<?php echo e($blog->thumbnail); ?>" alt="blog image" /></a>
									<div class="category">Business</div>
									<ul class="post-meta">
										<li><a href="read_blog?id=<?php echo e($blog->id); ?>"><span class="icon flaticon-timetable"></span><?php echo e($blog->created_at); ?></a></li>
										<li><a href="read_blog?id=<?php echo e($blog->id); ?>"><span class="icon flaticon-email"></span>Comments 03</a></li>
										<li><a href="read_blog?id=<?php echo e($blog->id); ?>"><span class="icon flaticon-user-2"></span>Admin</a></li>
									</ul>
								</div>
								<div class="lower-content">
									<h3><a href="read_blog?id=<?php echo e($blog->id); ?>"><?php echo e($blog->blogName); ?></a></h3>
									<div class="text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. </div>
									<div class="btn-box">
										<a href="read_blog?id=<?php echo e($blog->id); ?>" class="theme-btn btn-style-two"><span class="txt">Learn More</span></a>
									</div>
								</div>
							</div>
						</div>

						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<!--end News Block -->
					</div>
					
					<!--Post Share Options-->
					<div class="text-center">
						<div class="d-flex justify-content-center">
							<?php echo e($blogs->links()); ?>

						</div>
						
					</div>
					
				</div>
				
				<!-- Sidebar Side -->
                <div class="sidebar-side col-lg-4 col-md-12 col-sm-12">
                	<aside class="sidebar sticky-top">
						<div class="sidebar-inner">
						
							<!-- Search -->
							<div class="sidebar-widget search-box">
								<form method="post">
									<div class="form-group">
										<input type="search" name="search-field" value="" placeholder="Search ....." required>
										<button type="button"><span class="icon fa fa-search"></span></button>
									</div>
								</form>
							</div>
							
							<!--Blog Category Widget-->
							<div class="sidebar-widget sidebar-blog-category">
								<div class="widget-content">
									<div class="sidebar-title">
										<h5>Categories</h5>
									</div>
									<ul class="cat-list-two">
										<li><a href="#">Consulting <span>(0)</span></a></li>
										<li><a href="#">Life Style<span>(0)</span></a></li>
										<li><a href="#">Technology<span>(0)</span></a></li>
									</ul>
								</div>
							</div>
							
							<!-- Popular Post Widget -->
							<div class="sidebar-widget popular-posts">
                                <div class="widget-content">
                                    <div class="sidebar-title">
                                        <h5>latest posts</h5>
                                    </div>
                                    <?php
                                    $latest = DB::table('blogs')->orderBy('id','desc')->limit(3)->get();
                                    
                                    ?>
                                    <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <article class="post">
                                        <figure class="post-thumb"><img src="https://fileurtax-jobaroundyou.s3.ap-south-1.amazonaws.com/fileurtax/blogs/<?php echo e($lts->thumbnail); ?>" alt=""><a href="read_blog?id=<?php echo e($lts->id); ?>" class="overlay-box"></a>
                                        </figure>
                                        <div class="text"><a href="read_blog?id=<?php echo e($lts->id); ?>"><?php echo e($lts->title); ?></a></div>
                                        <div class="post-info"><?php echo e($lts->created_at); ?></div>
                                    </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    

                                    
                                </div>
                            </div>
							
							<!-- Tags Widget -->
							
							
						</div>
					</aside>
				</div>
				
			</div>
		</div>
	</div>
</div>
<!--End pagewrapper--><?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/components/home/show_blog.blade.php ENDPATH**/ ?>