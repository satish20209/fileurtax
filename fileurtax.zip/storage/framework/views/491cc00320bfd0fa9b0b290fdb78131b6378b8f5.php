<?php $__env->startSection("title"); ?>
At FileUrTax, choose the package that is aligned with your needs.
<?php $__env->stopSection(); ?>

<?php $__env->startSection("description"); ?>
: Find suitable packages for company lawyers, e-filling of taxes, or holding tax-related consultations.

<?php $__env->stopSection(); ?>
<?php $__env->startSection("keywords"); ?>
e filing of taxes,holding tax,queens counsel,company lawyer
<?php $__env->stopSection(); ?>

<?php if (isset($component)) { $__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Topbar::class, []); ?>
<?php $component->withName('home.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8)): ?>
<?php $component = $__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8; ?>
<?php unset($__componentOriginal9f868c09235baa8f8154555e3c9dc1932fd915f8); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Header::class, []); ?>
<?php $component->withName('home.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93)): ?>
<?php $component = $__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93; ?>
<?php unset($__componentOriginalddb8cc4e2f22b77a413566197bae68e831b19f93); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalceab412f96a841948b01cdc2734ffcc681db7c08 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Packages::class, []); ?>
<?php $component->withName('home.packages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalceab412f96a841948b01cdc2734ffcc681db7c08)): ?>
<?php $component = $__componentOriginalceab412f96a841948b01cdc2734ffcc681db7c08; ?>
<?php unset($__componentOriginalceab412f96a841948b01cdc2734ffcc681db7c08); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal623176770b884771a62630739c42e1bd0e3c713f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home\Footer::class, []); ?>
<?php $component->withName('home.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal623176770b884771a62630739c42e1bd0e3c713f)): ?>
<?php $component = $__componentOriginal623176770b884771a62630739c42e1bd0e3c713f; ?>
<?php unset($__componentOriginal623176770b884771a62630739c42e1bd0e3c713f); ?>
<?php endif; ?><?php /**PATH D:\important code all\fileurtax\fileurtaxlive\resources\views/packages.blade.php ENDPATH**/ ?>