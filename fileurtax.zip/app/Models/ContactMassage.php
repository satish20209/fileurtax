<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContactMassage extends Model
{
    // protected $table = 'contact_massages';
    public $fillable =
    [
        'name',
        'email',
        'mobile',
        'message',
    ];
    public $timestamps = true;
    use HasFactory;
}