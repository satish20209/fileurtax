<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChildService extends Model
{
    protected $table = 'child_services';
    public $fillable = 
    [
        'childService',
        'parentService',
    ];
    public $timestamps = false;
    use HasFactory;
}
