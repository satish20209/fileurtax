<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServiceUpdate extends Model
{
    protected $table = 'service_updates';
    public $fillable = [
        'status',
        'date'
    ];
    public $timestamps = false;
    use HasFactory;
}
