<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServiceproviderLawyer extends Model
{
    public $fillable = [
        'fname',
        'mobile',
        'email',
        'gender',
        'practincingSince',
        'amount',
        'secondary_practice_area',
        'country',
        'barEnrollmentNumber',
        'language',
        'practice_state',
        'state',
        'enrollment_state',
        'practice_Areas_primary',
        'practice_courts',
        'city',
        'address',
        'pincode',
        'abouts',
        'facebook',
        'twitter',
        'linkedin',
        'publication_areas_1',
        'publication_areas_2',
        'publication_areas_3',
        'monday',
        'tuesday',
        'wednesday',
        'thursday',
        'friday',
        'saturday',
        'sunday',
        'lat',
        'longt',
        'aadhaarcard',
        'pancard',
        'password',
    ];
    public $timestamps = false;
    use HasFactory;
}
