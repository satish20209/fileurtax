<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServicesRequest extends Model
{
    protected $fillable = [
        'customer_id',
        'service_provider_id',
        'status',
        'accept',
        'requestDate',
        'appdate',
        'apptime',
    ];

    public $timestamps = false;

    use HasFactory;
}
