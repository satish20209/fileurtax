<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bid extends Model
{
    // bid duble time appear
    protected $fillable = [
    'quotationid',
    'amount',
    'consultantId',
    ];
    public $timestamps = false;
    use HasFactory;
}
