<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bookconsultaion extends Model
{
    public $fillable =
    [
        
        'country',
        'mobile',
        'email',
        'fname',
        'lname',
        'state',
        'city',
        'docs',
        'docs_type',
        'docs_language',
        'plane',
        'date',
        'time',
    ];
    public $timestamps = true;
    use HasFactory;
}
