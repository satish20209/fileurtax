<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RunningService extends Model
{
    protected $table = 'running_services';
    public $fillable = [
        'userId',
        'serviceProviderId',
        'status',
    ];
    public $timestamps = false;
    use HasFactory;
}
