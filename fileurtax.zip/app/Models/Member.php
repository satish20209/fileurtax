<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    protected $table = 'members';
    protected $fillable = [
        'id',
        'fname',
        'lname',
        'role',
        'mobile',
        'email',
        'password',
        'dob',
        'experience',
        'salary',
        'callback',
        'profileImage',
    ];
    public $timestamps = false;
    use HasFactory;
}
