<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuperAdmin extends Model
{
    protected $table = 'super_admins';
    protected $fillable = [
    'email',
    'password'
    ];
    public $timestamps = false;
    use HasFactory;
}
