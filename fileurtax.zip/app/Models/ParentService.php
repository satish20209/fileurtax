<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ParentService extends Model
{
    protected $table = 'parent_services';
    public $fillable = [
        'parentService',
    ];
    public $timestamps = false;
    use HasFactory;
}
