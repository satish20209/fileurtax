<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServiceProviderClient extends Model
{
    protected $table='service_provider_clients';
    protected $fillable =
    [
        'fname',
        'lname',
        'email',
        'password',
        'mobile',
        'dob',
        'qualification',
        'parentService',
        'services',
        'experience',
        'image',
        'salary_range',
    ];
    public $timestamps = false;
    use HasFactory;
}
