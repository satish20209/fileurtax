<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class Raj implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    private $msg;
    private $user_id;
    private $channel_id;
    private $sendar_idd;
    private $name;
    private $fileId;
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($msg,$user_id,$channel_id,$sendar_idd,$name,$fileId)
    {
        $this->msg = $msg;
        $this->user_id = $user_id;
        $this->channel_id = $channel_id;
        $this->sendar_idd =$sendar_idd;
        $this->name = $name;
        $this->fileId=$fileId;

    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new Channel('chat.'.$this->channel_id.'.'.$this->user_id);
    }

    public function broadcastAs()
    {
        return "raj";
    }

    public function broadcastWith()
    {
        return ['msg'=>$this->msg,'chanel'=>$this->channel_id,'user_id'=>$this->user_id,'sendar'=>$this->sendar_idd,'filename'=>$this->name,'fileId'=>$this->fileId];
    }


}
