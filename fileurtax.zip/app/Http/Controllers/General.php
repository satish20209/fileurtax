<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\Member;
use Illuminate\Support\Facades\Storage;
class General extends Controller
{
   
    
    public function welcome(){
        return view('welcome');
    }
    public function aboutus(){
        return view('aboutus');
    }
    public function packages(){
        return view('packages');
    }
    public function quotation(){
        return view('quotation');
    }
    public function contact(){
        return view('contact');
    }
    public function disclaimerfun(){
        return view('disclaimer');
    }
    
    public function upload_files(Request $request){
        $file_name = $request->all();
        $image = $request->file('img_chat');
        $name = 'profile_pic'.'.'.$image->getClientOriginalExtension();
        $destinationPath = 'fileurtax/testingchat/'.$name;
        // $send_data = Storage::disk('s3')->put($destinationPath, file_get_contents($image));
        return response()->json(['status'=>200,'data'=>$file_name,'img'=>$name,'senddata'=>$send_data]);
        // try {
        //     Storage::disk('s3')->put($destinationPath, $aadhar_final);
        // } catch(S3 $e) {
        //     $errorMessage =  $e->getAwsErrorMessage();
        // if($errorMessage){
        //     return back()->with('error',"Internal server error ! Please Try Again ");
        // }
        // }
    }

    public function charteredAccountant() {
        return view('services.charteredAccountant');
        }
        public function CostManagementAccountant() {
        return view('services.CostManagementAccountant');
        }
        public function LegalServices() {
        return view('services.LegalServices');
        }
        public function CompanySecretary() {
        return view('services.CompanySecretary');
        }
        public function PersonalFinance() {
        return view('services.PersonalFinance');
        }
        public function Loan() {
        return view('services.Loan');
        }
        public function Investment() {
        return view('services.Investment');
        }
        public function OtherServices() {
        return view('services.OtherServices');
        }
    
    //Check Customer Requirement
 


 public function checkemail(Request $req){
     $memobj = Member::where('email',$req->email )->first();
     if($memobj){
         return response()->json(['status'=>200,'data'=>'exist']);
     }else{
         return response()->json(['status'=>400,'data'=>'not Exist']);
     }

 }

 public function customerQuotations() {
     if (session()->has('customerAuth')) {
     return view('customer.customerQuotations');
     }else {
     return redirect('login');
     }
 }

// scr
 public function resetphone(Request $request){
        $phone=$request->phone;
        $rr=substr($phone, 3);     
        $userdata=DB::table('service_provider_clients')->where('mobile',$rr)->first();
        if( $userdata){
            session()->put('f_phone',$rr);
            return response()->json(["success" => "1"]);
        }
      else{

          return response()->json(["error" => "0"]);
      }
 }

public function updatepassword(Request $req){
    if(session()->has('f_phone')){
        $pass=$req->pass;
        $cpass=$req->cpass;
        if($pass==$cpass){
            $resetpassword = ServiceProviderClient::where('mobile', '=',session('f_phone'))->first();
            $ccpassword=Hash::make($req->cpass);
        $resetpassword->password=$ccpassword;
        $resetpassword->update();
        $req->session()->forget('f_phone');
        return redirect('/login')->with('success','passwordupdated sucessfully,Please login');
        }
        else{
            return back()->with('error','password and confirm password dont match');
        }
    }
    else{
        return back()->with('error','confirm your mobile verify first');
    }
}
// regsp cntlr
public function updateCustomerLocation(Request $request) {
     $lat = $request->lat;
     $longt= $request->longt;
     $customer_id = $request->customer_id;
     DB::table('members')->where('id',$customer_id)->update([
     'lat' => $lat,
     'longt' => $longt,
     ]);
     return response()->json(['status' => 'success', 'code' => 200]);
 }


 public function get_data_PD(Request $req){
     $data=DB::table('members')->where('email',$req->email)->first(['profileImage','fname','mobile']);
     if($data){
         return response()->json(['status'=>200,'data'=>$data]);
     }else{
         return response()->json(['status'=>400,'data'=>'something went wrong']);
     }
   

 }

// maybe this function unused
    public function register_submit(Request $req){
        $fname=$req->fname.$req->lname;
        
        $mobile=$req->mobile;
        $password=$req->password;
        $dob=$req->dob;
        $email=$req->email;
        $experience=$req->experience;
        $picture=$req->picture;
        $role=$req->role;
        $radio=$req->radio;
        print_r($radio);
        print_r($email);

        if ($req->hasFile('picture')) {
            
            $image = $req->file('picture');
            $name = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/images');
            $image->move($destinationPath, $name);
            
        }else{
            $name="";
        }
        // print_r($name);
    
        if(!DB::table('registerserviceprovider')->where('email',$email)->first()){
                if(DB::table('registerserviceprovider')->insert(array('fname'=>$fname,'mobile'=>$mobile,'email'=>$email,'experience'=>$experience,'role'=>$role,'dob'=>$dob,'salaryRange'=>$radio,'password'=>$password,'profileImage'=>$name))){
                    return redirect('/login');
                }
        }else{
            
            echo "<script>alert('You have already registerd Please Login')</script>";
            
            return redirect('/login');
        }

    }
    
    

}


