<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Session;

use Socialite;

use Mail;
class UserController extends Controller
{
	// getinfo controller
	public function insert_mobile(Request $req){
        // $user=0;
        $data= $req->mobile;
        $chek=DB::table('users')->where('mobile',$data)->get();
        
        if(!count($chek)){
            $user=DB::table('users')->insert(array('mobile'=>$data));
          
        }else{
            
            $user=1;            
        }
        if(!session()->has('mobile')){
            $session=session()->put('mobile',$data);
            setcookie('mobile', base64_encode($data), time() + 30 * 24 * 60 * 60);
            // echo 'ss';
        }
        $email=DB::table('users')->where('mobile',$data)->get(['email'])->first->email; 
                 
        if($email){
            $email=$email->email;
            if (!session("email")) {
                $sessionn=session()->put('email',$email);
            }
        }
        
        // print_r(session('mobile'));
        // print_r(session('email'));
        if($user){
         return response()->json(['status'=>200,'data'=>session('mobile')]);
        }
        else{
            return response()->json(['status'=>400,'data'=>'something went wrong']);
        }



    }
    
    public function details_sub(Request $req){
        if(!DB::table('users')->where('email',$req->email)->first()){
            $user=DB::table('users')->where('mobile',session("mobile"))->update(array('name'=>$req->name,'email'=>$req->email));
            
            $file_names=[];
        $files = $req->file('files');

        if($req->hasFile('files')){
          
            foreach ($files as $file) {
                $name = time(). $file->getClientOriginalName();
                $file->move(public_path() . '/customer_files/', $name);
                array_push($file_names,$name);
            }
        }
            
        $str="";
        foreach($file_names as $file) {
            $str=$str.','.$file;
        }
        
        
        $f_name=substr($str,1,strlen($str));
            
        $services=$req->services;
        $child_service=$req->child_service;
        $requirements=$req->requirements;
        
        $files=$f_name;
        $status=$req->status;
        $user_id=DB::table('users')->where('mobile',session('mobile'))->first('id')->id;
        if(DB::table('customer_requirements')->insert(array('parent_service'=>$services,'child_service'=>$child_service,'requirements'=>$requirements,'files'=>$files,'status'=>$status,'user_id'=>$user_id))){
            //  DB::table('users')->where('mobile',session("mobile"))->update(array('service'=>$services));
            return redirect("/customerDashboard");
        }else{
            echo ("<script>alert('something went wrong!')</script>");
        }









            if($user){
                if (!session("email")) {
                    $sessionn=session()->put('email',$req->email);
                }
            if(session("duplicati_email")) {
                Session::forget('duplicati_email');
            }
            
            return redirect('/');
            }
        }
        else{
            if (!session("duplicati_email")) {
                $sessionn=session()->put('duplicati_email',$req->email);
            }
            return redirect('/');
        } 
    }
    public function mail(){
        return view("conformation_mail");
    }

    public function userLocation(Request $req) {
        if($req->has('lat') && $req->has('longt')) {
            $update_location = DB::table('users')
                                ->where('mobile',session('mobile'))
                                ->update(
                                    [
                                        'lat' => $req->lat,
                                        'longt' => $req->longt,
                                    ]
                                );
            if($update_location) {
                return response()->json(['status' => 'Location Updated']);
            }else {
                return response()->json(['status' => 'Location Not Updated']);
            }
        }
    }

    // social media controller
    public function redirectGoogle(){
		return sociaLite::driver('google')->redirect();
	}
	public function resgoogle(){
    	$user=Socialite::driver("google")->stateless()->user();
        $data=DB::table('users')->where('mobile',session("mobile"))->update(array('name'=>$user['name'],'email'=>$user['email']));
        if($data){
            if(!session()->has('email')){

				$session= session()->put('email', $user['email']);
                $email=$user['email'];
                Mail::send('conformation_mail', [], function ($m) use ($email) {
                    $m->from('hr@shivila.com', 'Shivila');
                    $m->to($email)->subject('conformaton mail !');
                });
				return redirect('/');
            }
        return redirect('/');
        }
		return redirect('/');
	}

	public function redirectinstagram(){
		return Socialite::driver("instagram")->redirect();
	}

	public function resinstagram(){
		$users=Socialite::driver("instagram")->stateless()->user();
		return redirect('/');
	}


	public function redirectfacebook(){
		return sociaLite::driver('facebook')->stateless()->redirect();
	}

	public function resfacebook(){
		$user=Socialite::driver("facebook")->stateless()->user();

		$username=$user->name;
		if(!$user->email){
			$useremail='_';
		}else{
			$useremail=$user->email;
			Mail::send('conformation_mail', [], function ($m) use ($useremail) {
				$m->from('hr@shivila.com', 'Shivila');
				$m->to($useremail)->subject('conformaton mail !');
			});
		}

		echo session()->get('mobile'),$username,$useremail;
		$data= DB::table('users')->where('mobile',session()->get('mobile'))->update(array('name'=>$username,'email'=>$useremail));
		echo $data;
		if($data){
			if(!session()->has('email')){
			$session= session()->put('email', $useremail);
			}
			return redirect('/');
		}
    }



    public function redirectlinkedin(){
		return sociaLite::driver('linkedin')->redirect();
	}

	public function reslinkedin(){
    	$user=Socialite::driver("linkedin")->stateless()->user();
        $data=DB::table('users')->where('mobile',session("mobile"))->update(array('name'=>$user->name,'email'=>$user->email));
        // print_r($data);
        if($data){
            if(!session()->has('email')){
				$session = session()->put('email', $user->email);
                $email=$user->email;
                Mail::send('conformation_mail', [], function ($m) use ($email) {
                    $m->from('hr@shivila.com', 'Shivila');
                    $m->to($email)->subject('conformaton mail !');
                });
            }
        return redirect('/');
        }
	}

	public function restwitter(){
    	$user=Socialite::driver("twitter")->user();
    	echo "<pre>";
    	print_r($user);

	}
	public function redirecttwitter(){
		return sociaLite::driver('twitter')->redirect();

	}
}
