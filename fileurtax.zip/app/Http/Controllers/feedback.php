<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class feedback extends Controller
{
    // submit feedback data
    public function feedbacks(Request $req){
        $name=$req->name;
        $message=$req->message;
        $email=$req->email;
        $rate=$req->rate;
        
        
        if(DB::table('feedback')->insert(array('name'=>$name,'email'=>$email,'message'=>$message,'rate'=>$rate,'status'=>0))){
            return redirect('/')->with('success','thanks for you feedback');
            
        }else{
            return redirect('/')->with('info','Something went wrong!!');
        }
    }
    // return feedback view
    public function feedback (Request $req){
        return view('feedback');
    }
    // return feedback data
    public function get_feedback(){
        $data=DB::table('feedback')->get();
        return response()->json(['status' => '200', 'data' => $data]);
    }
    // return feedback message 
    public function get_feedback_msg(Request $req){
        $msg=DB::table('feedback')->where('id',$req->id)->first('message');
        return response()->json(['status' => '200', 'data' => $msg]);
    }
    // change feedback status 
    public function change_status_feedback(Request $req){
        $sts=DB::table('feedback')->where('id',$req->id)->first('status');
        if($sts->status=='1'){
            $temp=DB::table('feedback')->where('id',$req->id)->update(['status'=>0]);
        }else{
            $temp=DB::table('feedback')->where('id',$req->id)->update(['status'=>1]);
        }
        return response()->json(['status' => '200', 'data' =>$sts]);
    }
    public function count_feedback(){
        $temp=count(DB::table('feedback')->get());
        return response()->json(['status' => '200', 'data' =>$temp]);
    }
}
