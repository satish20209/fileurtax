<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Help;
use App\Models\Member;
use Illuminate\Support\Facades\Mail;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
class HelpController extends Controller
{
    public function helpcustomerview(){
        if (session()->has('customerAuth')) {
            return view('customer.helpcustomerview');
        }else {
            return redirect('/login');
        }
    }
    public function help(Request $request){
       
        $all_data = $request->all();
        $userid = Member::where("email",$request->users_id)->first();
        $all_data['users_id'] = $userid->id;
        $success = Help::create($all_data);
        $email= Member::where('id',$userid->id)->first()->email;
        $idticket = $request->ticket_id;
       $sendmailstatus = Mail::send('ClientServiceProvider.ticketcode', ['ticket_id'=>$idticket], function($message) use($email){
            $message->to($email)->subject
            ('Fileurtax Support Ticket Id');
            $message->from('info@fileurtax.com','FILEURTAX');
        });
        if($success)
        {
            // return response()->json(['emailcode'=>$request->ticket_id]);
            return back()->with('success','Request Submit Success Check your Email');
        }
    }

    public function support(){
        $data=  Help::get();
        $finalData = [];
        foreach($data as  $allData){
            array_push($finalData,$allData);
        }
        return response()->json(['data'=>$finalData],200)->header('Content-Type', 'application/json');
    }

    public function supportname($id){
        $data= Member::where('id',$id)->first();
        return response()->json(['username'=>$data->fname],200)->header('Content-Type', 'application/json');
    }
}
