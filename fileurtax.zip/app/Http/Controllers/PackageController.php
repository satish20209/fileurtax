<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PackageController extends Controller
{
	public function action(Request $req){
        $email=$req->email;
        $data=DB::table('members')->where('email',$email)->first();
        $name=$data->fname;
        $ammount=$req->amt;
        $mobile=$data->mobile;
        $parent_id=$req->parent_id;
        $package_name=$req->package_name;
        if(DB::table('packages')->insert(array('package_name'=>$package_name,'parent_package'=>$parent_id))){
            $id=DB::table('packages')->orderBy('id', 'DESC')->first()->id;
            $data=DB::table('paymentes')->insert(array('package_id'=>$id,'mobile'=>$mobile,'user_email'=>$email,'name'=>$name,"amount"=>$req->amt,"status"=>'pending'));
            $pyment_id=$id=DB::table('paymentes')->orderBy('id', 'DESC')->first()->id;
            return response()->json(['status'=>200,'data'=>'succes','id'=>$pyment_id]);
        }else{
            return response()->json(['status'=>400,'data'=>'error']);
        }
    }
    public function action_success(Request $req){
        DB::table('paymentes')->where('id',$req->payment_id)->update(array('status'=>'success','txn_id'=>$req->txn_id));
            return response()->json(['status'=>200,'data'=>'succes']);
    }
}
