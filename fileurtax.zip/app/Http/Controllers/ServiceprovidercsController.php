<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Hash;
use Storage;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
class ServiceprovidercsController extends Controller
{
	public function csDenyRequest(Request $request) {
        //---------------|-------------//
        // Status | Code //
        //---------------|-----------//
        // Sent | 0 //
        //---------------|---------//
        // Accepted | 1 //
        //---------------|-------//
        // Denied | -1 //
        //---------------|-----//
        $customer_id = $request->customer_id;
        $service_provider_id = $request->service_provider_id;
        DB::table('services_requests')->where(
        [
        'service_provider_id' => $service_provider_id,
        'customer_id' => $customer_id,
        ]
        )
        ->update([
        'status' => -1,
        ]);
        return redirect('csDashboard');
    }
    public function registerlawyersignupcs(Request $req){
        $fname=$req->fname;
        $mobile=$req->mobile;
        $email=$req->email;
        $gender=$req->gender;
        $registrationNumber=$req->registrationNumber;
        $practincingSince=$req->practincingSince;
        $amount=$req->amount;
        $secondary_practice_area=$req->secondary_practice_area;
        $country=$req->country;
        $barEnrollmentNumber=$req->barEnrollmentNumber;
        $language=$req->language;
        $recognitions=$req->recognitions;
        $state=$req->state;
        $enrollment_state=$req->enrollment_state;
        $practice_Areas_primary=$req->practice_Areas_primary;
        $practice_courts=$req->practice_courts;
        $city=$req->city;
        $address=$req->address;
        $pincode=$req->pincode;
        $description=$req->description;
        $facebook=$req->facebook;
        $twitter=$req->twitter;
        $linkedin=$req->linkedin;
        $publication_areas_1=$req->publication_areas_1;
        $publication_areas_2=$req->publication_areas_2;
        $publication_areas_3=$req->publication_areas_3;
        $monday=$req->monday;
        $tuesday=$req->tuesday;
        $wednesday=$req->wednesday;
        $thursday=$req->thursday;
        $friday=$req->friday;
        $saturday=$req->saturday;
        $sunday=$req->sunday;
        $lat=$req->lat;
        $longt=$req->longt;
        $aadhaarcard=$req->aadhaarcard;
        $pancard=$req->pancard;
        $experience=$req->experience;


        $imageName=null;
        $aadhar_imageName=null;
        $pan_imageName=null;
        
        if($req->firmid){
            $photo = $req->firmid;
            $image_64 = $photo; //your base64 encoded data
            $extension = explode('/', explode(':', substr($image_64, 0, strpos($image_64, ';')))[1])[1];   // .jpg .png .pdf
            $replace = substr($image_64, 0, strpos($image_64, ',')+1); 
            // find substring fro replace here eg: data:image/png;base64,
            $image = str_replace($replace, '', $image_64); 
            $image = str_replace(' ', '+', $image); 
            $imageName = 'certificate'.'.'.$extension;
            $final = base64_decode($image);
            $destinationPath = 'fileurtax/serviceprovider/'.$email.'/'.$imageName;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, $final);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
                if($errorMessage){
                    return back()->with('error',"pancard Internal server error ! Please Try Again ");
                }
            }
            // $success = file_put_contents("customer_files/".$imageName, $final);
        }
        if($req->aadhar_img){
            $aadhar_photo = $req->aadhar_img;
            $aadhar_image_64 = $aadhar_photo; //your base64 encoded data
            $extension = explode('/', explode(':', substr($aadhar_image_64, 0, strpos($aadhar_image_64, ';')))[1])[1];   // .jpg .png .pdf
            $replace = substr($aadhar_image_64, 0, strpos($aadhar_image_64, ',')+1); 
            // find substring fro replace here eg: data:image/png;base64,
            $aadhar_image = str_replace($replace, '', $aadhar_image_64); 
            $aadhar_image = str_replace(' ', '+', $aadhar_image); 
            $aadhar_imageName = 'aadhar'.'.'.$extension;
            $aadhar_final = base64_decode($aadhar_image);
            $destinationPath = 'fileurtax/serviceprovider/'.$email.'/'.$aadhar_imageName;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, $aadhar_final);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
                if($errorMessage){
                    return back()->with('error',"pancard Internal server error ! Please Try Again ");
                }
            }
            // $aadhar_success = file_put_contents("customer_files/".$aadhar_imageName, $aadhar_final);
        }
        if($req->pan_img){
            $pan_photo = $req->pan_img;
            $pan_image_64 = $pan_photo; //your base64 encoded data
            $extension = explode('/', explode(':', substr($pan_image_64, 0, strpos($pan_image_64, ';')))[1])[1];   // .jpg .png .pdf
            $replace = substr($pan_image_64, 0, strpos($pan_image_64, ',')+1); 
            // find substring fro replace here eg: data:image/png;base64,
            $pan_image = str_replace($replace, '', $pan_image_64); 
            $pan_image = str_replace(' ', '+', $pan_image); 
            $pan_imageName = 'pancard'.'.'.$extension;
            $pan_final = base64_decode($pan_image);
            $destinationPath = 'fileurtax/serviceprovider/'.$email.'/'.$pan_imageName;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, $pan_final);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
                if($errorMessage){
                    return back()->with('error',"pancard Internal server error ! Please Try Again ");
                }
            }
            // $pan_success = file_put_contents("customer_files/".$pan_imageName, $pan_final);
        }




        $user_id=DB::table('members')->where('email',$email)->first()->id;
        if(DB::table('members')->where('email',$email)->update(array('gender'=>$gender,'fname'=>$fname,'mobile'=>$mobile,'lat'=>$lat,'longt'=>$longt))){
            
        }

        if(DB::table('serviceprovidercs')->insert(array('pancard'=>$pancard,'aadhaarcard'=>$aadhaarcard,'experience'=>$experience,'recognitions'=>$recognitions,'userId'=>$user_id,'registrationNumber'=>$registrationNumber, 'country'=>$country,'state'=>$state,'city'=>$city,'address'=>$address,'pincode'=>$pincode,'description'=>$description,'facebook'=>$facebook,'twitter'=>$twitter,'linkedin'=>$linkedin,'publication_areas_1'=>$publication_areas_1,'publication_areas_2'=>$publication_areas_2,'publication_areas_3'=>$publication_areas_3,'monday'=>$monday,'tuesday'=>$tuesday,'wednesday'=>$wednesday,'thursday'=>$thursday,'friday'=>$friday,'saturday'=>$saturday,'sunday'=>$sunday,'registrationCertificate'=>$imageName,'aadharpic'=>$aadhar_imageName,'pancardpic'=>$pan_imageName,'services'=>$req->services))){

            return response()->json(['status'=>200,'data'=>'success']);

        }else{

            return response()->json(['status'=>500,'data'=>'something went wrong']);   
        }
    }
	public function cscustomerDetails(Request $request) {
        $customer_id = $request->customer_id;
        return view('CS.customerDetails')->with('customer_id', $customer_id);
    }
	public function register_CS_form(){
        $res=Http::withHeaders([
            'api-token'=>'qSNLEDb9OOJ9-CHiL04BIL4Hhi18zhE5XUT3fY78W0hIcJfxYnf-KjL8hBvzka40or4',
            'user-email'=>'rathouryogesh40@gmail.com'
            ])->get('https://www.universal-tutorial.com/api/getaccesstoken');
        $data=(array)json_decode($res->body());
        if(isset($data['auth_token'])){
            $auth_token=$data['auth_token'];
            $country_res=Http::withHeaders([
            'Authorization'=>'Bearer '.$auth_token,
            ])->get('https://www.universal-tutorial.com/api/states/india');
            $country=(array)json_decode($country_res->body());
            // print_r($auth_token);components\registerserviceprovider-component.blade.php
            if(session()->has('csAuth')){
                $user_id=DB::table('members')->where('email',session('csAuth'))->first()->id;
                if(!DB::table('serviceprovidercs')->where('userId',$user_id)->first()){
                    return view('serviceproviderregister.csdetails',['token'=>$auth_token,'country'=>$country]);
                }else{
                    
                    return redirect('csDashboard');
                }
                
            }else{
                return redirect('/login');
            }
        }else{
            
            return redirect('register_CS');
            
            
            
        }
    }
    public function csQuotation() {
        if (session()->has('csAuth')) {
        return view('CS.csQuotation');
        }else {
        return redirect('login');
        }
    }
    public function cshelp() {
        if (session()->has('csAuth')) {
        return view('CS.cshelpview');
        }else {
        return redirect('login');
        }
    }

    
    public function csUpdate(Request $req){
        $name=$req->name;
        $dob=$req->dob;
        $salary_range=$req->salary_range;
        $experience=$req->experience;

        if ($req->hasFile('picture')) {
            $image = $req->file('picture');
            $imgname = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('csAuth').'/'.$imgname;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, file_get_contents($image));
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
                if($errorMessage){
                    return back()->with('error',"pancard Internal server error ! Please Try Again ");
                }
            }
            DB::table('members')->where('email',session('csAuth'))->update(array('experience'=>$experience,'fname'=>$name,'profileImage'=>$imgname,'dob'=>$dob,'salary'=>$salary_range));
           return redirect('/csDashboard');
        }else{
            DB::table('members')->where('email',session('csAuth'))->update(array('experience'=>$experience,'fname'=>$name,'dob'=>$dob,'salary'=>$salary_range));
            return redirect('/csDashboard');
        }
    }
    public function csSetting(){
      if (session()->has('csAuth')) {
        return view('CS.settings');
      }else {
        return redirect('login');
      }
    }
    public function csAcceptRequest(Request $request) {
        //---------------|-------------//
        // Status | Code //
        //---------------|-----------//
        // Sent | 0 //
        //---------------|---------//
        // Accepted | 1 //
        //---------------|-------//
        // Denied | -1 //
        //---------------|-----//
        $customer_id = $request->customer_id;
        $service_provider_id = $request->service_provider_id;
        DB::table('services_requests')->where(
        [
        'service_provider_id' => $service_provider_id,
        'customer_id' => $customer_id,
        ]
        )
        ->update([
        'status' => 1,
        ]);
        return redirect('csDashboard');
    }
    public function csDashboard() {
       
        if (session()->has('csAuth')) {
            return view('CS.csDashboard');
        }else {
            return redirect('login');
        }
    }
    public function csServiceRequest() {
        if (session()->has('csAuth')) {
            return view('CS.csServiceRequest');
        }else {
            return redirect('login');
        }
    }
    public function csLogOut() {
        session()->forget('csAuth');
        return redirect('login');
    }
    public function csActiveServices() {
        if (session()->has('csAuth')) {
            return view('CS.csActiveServices');
        }else {
            return redirect('login');
        }
    }


    public function update_cstab_1(Request $req){
        
        if ($req->hasFile('picture')) {

            $image = $req->file('picture');
            $imgname = 'profile'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('csAuth').'/'.$imgname;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, file_get_contents($image));
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
                if($errorMessage){
                    return back()->with('error',"pancard Internal server error ! Please Try Again ");
                }
            }
            DB::table('members')->where('email',session('csAuth'))->update(array('profileImage'=>$imgname));
           
        }

        DB::table('members')->where('email',session('csAuth'))->update(['fname'=>$req->fname,'gender'=>$req->gender]);
        $id=DB::table('members')->where('email',session('csAuth'))->first('id')->id;
        DB::table('serviceprovidercs')->where('userId',$id)->update(['aadhaarcard'=>$req->aadhar_card,'pancard'=>$req->pancard]);     
        return redirect('/UpdateCs');
    }
    
    public function update_cstab_2(Request $req){
        $award=$req->award;
        $reg_no=$req->reg_no;
        $industry=$req->industry;
        $state=$req->state;
        $city=$req->city;
        $address=$req->address;
        $pincode=$req->pincode;
        $id=DB::table('members')->where('email',session('csAuth'))->first('id')->id;

        DB::table('serviceprovidercs')->where('userId',$id)->update(['recognitions'=>$award,
        'registrationNumber'=>$reg_no,'city'=>$city,'state'=>$state,'experience'=>$industry,'address'=>$address,'pincode'=>$pincode ]);
        return redirect('/UpdateCs');
    }
    public function update_cstab_3(Request $req){

        $userid=DB::table('members')->where('email',session('csAuth'))->first('id')->id;
        if ($req->hasFile('certificate')) {
            $image = $req->file('certificate');
            // $imgname = time().'.'.$image->getClientOriginalExtension();
            $imageName = 'certificate'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('csAuth').'/'.$imageName;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, $image);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
                if($errorMessage){
                    return back()->with('error',"pancard Internal server error ! Please Try Again ");
                }
            }
            
            DB::table('serviceprovidercs')->where('userId',$userid)->update(array('registrationCertificate'=>$imageName));
            

        }
        if ($req->hasFile('aadhar')) {
            $image = $req->file('aadhar');
            // $imgname = time().'.'.$image->getClientOriginalExtension();
            $imageName = 'aadhar'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('csAuth').'/'.$imageName;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, $image);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
                if($errorMessage){
                    return back()->with('error',"pancard Internal server error ! Please Try Again ");
                }
            }
            // $userid=DB::table('members')->where('email',session('layerAuth'))->first('id')->id;
            DB::table('serviceprovidercs')->where('userId',$userid)->update(array('aadharpic'=>$imageName));
            

        }
        if ($req->hasFile('pancard')) {
            $image = $req->file('pancard');
            // $imgname = time().'.'.$image->getClientOriginalExtension();
            $imageName = 'pancard'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('csAuth').'/'.$imageName;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, $image);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
                if($errorMessage){
                    return back()->with('error',"pancard Internal server error ! Please Try Again ");
                }
            }
            // $userid=DB::table('members')->where('email',session('layerAuth'))->first('id')->id;
            DB::table('serviceprovidercs')->where('userId',$userid)->update(array('pancardpic'=>$imageName));
            
            
            
        }
        return redirect('/csDashboard');
        
    }




    public function requestPayment() {
        if (session()->has('csAuth')) {
        return view('CS.requestPayment');
        }else {
        return redirect('login');
        }
    }
    public function csRequestPayment(Request $req){
            if (session()->has('csAuth')) {
                DB::table('paymentrequest')->insert(array('consultationId'=>$req->consultation_id,'customerId'=>$req->customer_id,'status'=>0,'requestDate'=>Carbon::now('Asia/Kolkata'),'paymentStatus'=>0));
            }
            return redirect('/csrequestPayment');
        }

}
