<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ContactMassage;
use Illuminate\Support\Facades\DB;
use Session;

class ContactMassageController extends Controller
{
	public function contact(Request $request){

       $success =  ContactMassage::create($request->all());
       if ($success) {

        $session=session()->put('successMessage',"Message Sent Successfully ! We will contact You soon.");
        return redirect('/contact');
       }
       else{
           $session=session()->put('faildMessae',"Message Sent Field Please Try Again !");
           return redirect('/contact');
       }
    }
}
