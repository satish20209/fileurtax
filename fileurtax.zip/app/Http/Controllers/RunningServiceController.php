<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\runningService;

class RunningServiceController extends Controller
{
	public function takeAction(Request $request) {
        $userId = $request->userId;
        $startService = new runningService;
        $startService->userId = $request->userId;
        $startService->serviceProviderId = session('session_service_provider');
        $startService->status = $request->status;
        $startService->save();
        return redirect()->back()->with(['userId' => $userId]);
    }

    public function closeService(Request $request) {
        $userId = $request->userId;
        $status = $request->status;
        $serviceProviderId = session('session_service_provider');
        $updateStatus = runningService::where(
            [
                'userId' => $userId,
                'serviceProviderId' => $serviceProviderId,
            ]
        )
        ->update(
            [
                'status' => $status,
            ]
        );
        return redirect()->back();
    }

    public function allUpdates() {
        if(session()->has('session_service_provider')) {
            return view('ClientServiceProvider.allUpdates');
        }else {
            return redirect('login');
        }
    }
}
