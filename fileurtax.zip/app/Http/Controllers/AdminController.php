<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Member;
use App\Models\ServicesRequest;
use Hash;

class AdminController extends Controller
{
    public function termsandconditions(){
        return view('termsandconditions');
    }
    public function adminhelp(){
        if(session()->has('admin_email_session'))
        {
            return view('admin.adminhelp');
        }else{
            return view('admin.adminLogin');
           }
    }
    
	public function adminLloginViewpage(){
        if(session()->has('admin_email_session'))
        {
            return view('admin.admindashboard');
        }else{
            return view('admin.adminLogin');
           }
    }
	public function adminchat(){
        if(session()->has('admin_email_session'))
        {
            return view('admin.admin');
        }else{
            return view('admin.adminLogin');
           }
    }
    public function loginAdmin(Request $req){
        if(session()->has('admin_email_session')){
            return redirect('/adminlogin');
        }
        else{
            $email=$req->admin_email;
            $password=$req->admin_password;
            $user=DB::table('admins')->where('admin_email',$email)->first();
            if(is_null($user)){
                return response()->json(['status'=>404,'response'=>"User Name Not Found !"],404);
            }
            else{
                $userPass=$user->admin_password;
                if(Hash::check($password,$userPass)){
                    $session=session()->put('admin_email_session',$email);
                    return response()->json(['status'=>200,'response'=>"Login Successfull !"],200);
                }else{
                    return response()->json(['status'=>404,'response'=>"Paasword Not Matched !"],404);
                }
            }
        }
    }

    public function flush(Request $request) {
        $request->session()->flush();
        return redirect('/adminlogin');
    }
    public function service_provider_req_status(Request $req){
        DB::table('services_requests')->where('id',$req->id)->update(array('accept'=>1));
        return response()->json(['status'=>200,'data'=>$req->id]);
    }

    public function service_provider_req_status_desable(Request $req){
        DB::table('services_requests')->where('id',$req->id)->update(array('accept'=>NULL));
        return response()->json(['status'=>200,'data'=>$req->id]);
    }
    
    public function adminviewcustomer(){
        if(session()->has('admin_email_session'))
        {
            return view('admin.customersView');
        }else{
            return view('admin.adminLogin');
        }
    }
    public function adminviewconsultant(){
        if(session()->has('admin_email_session'))
        {
            return view('admin.consultantView');
        }else{
            return view('admin.adminLogin');
        }
        
 
    }
    public function adminviewrequest(){
        if(session()->has('admin_email_session'))
        {
            return view('admin.serviceprviderRequests');
        }else{
            return view('admin.adminLogin');
        }
    }
    public function adminfeedback(){
        if(session()->has('admin_email_session'))
        {
            return view('admin.feedback');
        }else{
            return view('admin.adminLogin');
        }
        
    
    }
    public function adminblog(){
        if(session()->has('admin_email_session'))
        {
            return view('admin.blog');
        }else{
            return view('admin.adminLogin');
        }
    }

    public function viewhelp(Request $req)
    {
        $data = DB::table('helps')->where('users_id',$req->id)->first();
        return response()->json(['data'=>$data]);
    }
    public function helpsolve(Request $req)
    {
        // $data = DB::table('helps')->where('users_id',$req->id)->first();
        $data = DB::table('helps')->where('users_id',$req->id)->update(array('status'=>1));
        if($data){
            return response()->json(['data'=>"success"]);
        }else{
            return response()->json(['data'=>"Somthing Went Wrong!"]);
        }
        
    }
}
