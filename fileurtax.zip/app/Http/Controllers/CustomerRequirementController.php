<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServicesRequest;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class CustomerRequirementController extends Controller
{
	public function customerDashboard() {
        if (session()->has('customerAuth')) {
            return view('customer.customerDashboard');
        }else {
            return redirect('/login');
        }
    }
	public function makepayment() {
        if (session()->has('customerAuth')) {
            return view('customer.makepayment');
        }else {
            return redirect('/login');
        }
    }

    public function serviceRequest(Request $request) {
        $customer_id = $request->customer_id;
        $service_provider_id = $request->service_provider_id;
        $insertData = DB::table('services_requests')->insert([
            'customer_id' => $customer_id,
            'service_provider_id' => $service_provider_id,
            'status' => 0,
            'requestDate' => Carbon::now('Asia/Kolkata')
        ]);
        return redirect('customerDashboard');
    }

    public function bookappointment(Request $request){
        $uptsuccess = ServicesRequest::where(['customer_id'=> $request->custid , 'service_provider_id'=>$request->lid])->update(['apptime' => $request->apptime,'appdate'=>$request->appdate,'timeperiod'=>$request->timeperiod,'fee'=>$request->fee]);
        if($uptsuccess){
            return response()->json(['status'=>200,'response'=>"Appointment Book Successfull"],200);
        }else{
            return response()->json(['status'=>500,'response'=>"Somting went Wrong!"],500);
        }
    }
    
    public function bookedappointment(Request $request){
        if (session()->has('customerAuth')) {
            return view('customer.bookappointment');
        }else {
            return redirect('/login');
        }
        
    }
    public function viewbookedappointment(Request $request){
        if (session()->has('layerAuth')) {
            return view('lawyer.bookappointment');
        }else {
            return redirect('/login');
        }
    }
    public function csviewbookedappointment(Request $request){
        if (session()->has('csAuth')) {
            return view('CS.bookappointment');
        }else {
            return redirect('/login');
        }
    }
    public function caviewbookedappointment(Request $request){
        if (session()->has('caAuth')) {
            return view('CA.bookappointment');
        }else {
            return redirect('/login');
        }
    }
    public function cmaviewbookedappointment(Request $request){
        if (session()->has('cmaAuth')) {
            return view('CMA.bookappointment');
        }else {
            return redirect('/login');
        }
    }
    // customer controller
	public function customerRequirement(){
        return view('customerRequirement');
    }
    public function customerRequirement_reg(Request $request){
        $file_names=[];
        $files = $request->file('files');

        if($request->hasFile('files')){
          
            foreach ($files as $file) {
                $name = time(). $file->getClientOriginalName();
                // $file->move(public_path() . '/customer_files/', $name);
                $path = Storage::disk('fileurtax')->put('images', $request->image);
                $path = Storage::disk('fileurtax')->url($path);
                array_push($file_names,$name);
            }
        }
            
        $str="";
        foreach($file_names as $file) {
            $str=$str.','.$file;
        }
        
        
        $f_name=substr($str,1,strlen($str));
            
        $services=$request->services;
        $child_service=$request->child_service;
        $requirements=$request->requirements;
        $phone=$request->phone;
        $files=$f_name;
        // $files="1";
        $status=$request->status;
        $user_id=DB::table('users')->where('mobile',session('mobile'))->first('id')->id;
        if(DB::table('customer_requirements')->insert(array('parent_service'=>$services,'child_service'=>$child_service,'requirements'=>$requirements,'files'=>$files,'status'=>$status,'user_id'=>$user_id))){
            //  DB::table('users')->where('mobile',session("mobile"))->update(array('service'=>$services));
            return redirect("/customerDashboard");
        }else{
            echo ("<script>alert('something went wrong!')</script>");
        }
        
    }
    public function get_clint_service(Request $req){
        $child_service=DB::table('child_services')->where('parentService',$req->parent_id)->get();
        

        if($child_service){
            return response()->json(['status'=>200,'child_service'=>$child_service]);
        }else{
            return response()->json(['status'=>400,'child_service'=>$child_service]);
        }
    }

    public function updateCustomerReq(Request $request) {
                $file_names=[];
                $files = $request->file('files');
                if($request->hasFile('files')){

                foreach ($files as $file) {
                    // $name = time(). $file->getClientOriginalName();
                    // $file->move(public_path() . '/customer_files/', $name);
                    $email = session('customerAuth');
                    $name = 'cstmrFiles'.time().'.'.$file->getClientOriginalExtension();
                    $destinationPath = 'fileurtax/customer_files/'.$email.'/'.$name;
                    Storage::disk('s3')->put($destinationPath, file_get_contents($file));
                    array_push($file_names,$name);
                }
                }
                $str="";
                foreach($file_names as $file) {
                $str=$str.','.$file;
                }
                $f_name=substr($str,1,strlen($str));
                $service=$request->services;
                $requirements=$request->requirements;
                $files=$f_name;
                $customerDetails = DB::table('members')->where('email',session('customerAuth'))->first();
                $insertData = DB::table('customer_requirements')->insert(
                [
                'parent_service' => $service,
                'child_service' => $service,
                'requirements' => $requirements,
                'files' => $files,
                'status' => 'Not Mentioned',
                'user_id' => $customerDetails->id,
                ]
                );
                return redirect('customerDashboard');
    }


    public function checkCustomserRequirement(Request $request){
        $user_id = $request->user_id;
        $customerRequirement = DB::table('customer_requirements')
        ->where('user_id',$user_id)
        ->exists();
        if (!$customerRequirement) {
        return response()->json(
        [
        'code'=> 200,
        'status' => 'success',
        'data' => 'Not Found',
        ]
        );
        }else {
        return response()->json(
        [
        'code'=> 200,
        'status' => 'success',
        'data' => 'Found',
        ]
        );
        }
    }

 
   public function acceptConsultantPaymentReq(Request $req) {
       $customer_id=$req->customer_id;
       $consultation_id=$req->consultation_id;
       DB::table('paymentrequest')->where([
                               'customerId'=> $customer_id,
                               'consultationId' => $consultation_id,
                               ])->update(['status'=>1]);
       return redirect('/customermakepayment');
   }
   public function customer_payment(Request $req){
       $txn_id=$req->txn_id;
       $payment_id=$req->payment_id;
       $data=DB::table('members')->where('id',$payment_id)->first();
       DB::table('paymentes')->insert(array('package_id'=>$payment_id,'name'=>$data->fname,'user_email'=>$data->email,'amount'=>$req->amt,'cnslCustmr'=>1));
       DB::table('paymentrequest')->where([
           'consultationId'=>$req->cnslId,
           'customerId'=>$payment_id,
           ])->update(['paymentStatus'=>1]);
       
       return response()->json(['status'=>200,'data'=>['u'=>$req->cnslId,'c'=>$payment_id]]);

   }
   public function denyConsultantPaymentReq(Request $req){
       $customer_id=$req->customer_id;
       $consultation_id=$req->consultation_id;
       DB::table('paymentrequest')->where([
                               'customerId'=> $customer_id,
                               'consultationId' => $consultation_id,
                               ])->update(['status'=>-1]);
       return redirect('/customermakepayment');
   }


}
