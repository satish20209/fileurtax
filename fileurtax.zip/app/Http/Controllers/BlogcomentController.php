<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blogcoment;
class BlogcomentController extends Controller
{
    public function comments(Request $request){
        Blogcoment::create($request->all());
        return back()->with('success','Thanks For Your Comment');
        // 52.66.220.96
    }
}
