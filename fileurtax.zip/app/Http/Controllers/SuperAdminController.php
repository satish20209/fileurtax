<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SuperAdmin;
use Hash;
use Illuminate\Support\Facades\DB;

class SuperAdminController extends Controller
{
    public function login() {
        if(session()->has('session_service_provider') || session()->has('admin') || session()->has('superAdmin')) {
            return redirect('/dashboard');
        }else {
            return view('superAdmin.login');
        }
    }
    public function superAdminDashboard() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminDashboard');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminAuth(Request $request) {
        $email = $request->email;
        $password = $request->password;
        $mailExist = SuperAdmin::where('email',$email)
        ->exists();
        if ($mailExist) {
            $superAdmin = $mailExist = SuperAdmin::where('email',$email)
            ->first();
            if (Hash::check($password,$superAdmin->password)) {
                session()->put('superAdmin',$email);
                return response()->json([
                    'code' => 200,
                    'status' => 'success',
                    'redirect' => 'superAdminDashboard',
                ]);
            }else {
                return response()->json([
                    'code' => 200,
                    'status' => 'success',
                    'passwordStatus' => 'Password Not Matched',
                ]);
            }
        }else {
            return response()->json([
                'code' => 200,
                'status' => 'success',
                'emailStatus' => 'Email Not Registered',
            ]);
        }
    }

    public function superAdminLogOut() {
        session()->forget('superAdmin');
        return redirect('superadminlogin');
    }

    public function superAdminPackages() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminPackages');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminConsulations() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminConsulations');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminSales() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminSales');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminLeads() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminLeads');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminProfile() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminProfile');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superadminPassword(Request $request) {
        $password = $request->password;
        $newPassword = SuperAdmin::where('email',session('superAdmin'))
        ->update(
            [
                'password' => Hash::make($password),
            ]
        );
        if ($newPassword) {
            session()->forget('superAdmin');
            return redirect('superadminlogin');
        }
    }

    public function superAdminViewAdmins() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminViewAdmins');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminAddAdmins(Request $request) {
        $name = $request->name;
        $email = $request->email;
        $password = $request->password;
        $image = 'images/laywerProfile.jpg';
        $newAdmin = DB::table('admins')
        ->insert([
            'name' => $name,
            'admin_password' => Hash::make($password),
            'admin_email' => $email,
            'image' => $image,
        ]);
        return redirect('superAdminViewAdmins');
    }

    public function superAdminDeleteAdmins(Request $request) {
        $adminId = $request->adminId;
        $deleteAdmin = DB::table('admins')
        ->where('id',$adminId)
        ->delete();
        return redirect('superAdminViewAdmins');
    }

    public function superAdminViewCustomers() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminViewCustomers');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminViewConsultants() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminViewConsultants');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminViewQuotations() {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminViewQuotations');
        }else {
            return redirect('superadminlogin');
        }
    }

    public function superAdminSalesPage() {
        if (session()->has('superAdmin')) {
        return view('superAdmin.superAdminSalesPage');
        }else {
        return redirect('superadminlogin');
        }
    }
    
    public function consultantProfile(Request $request) {
            if (session()->has('superAdmin')) {
            return view('superAdmin.consultantProfile');
            }else {
            return redirect('superadminlogin');
            }
    }

    public function customerProfile(Request $request) {
        if (session()->has('superAdmin')) {
        return view('superAdmin.customerProfile');
        }else {
        return redirect('superadminlogin');
        }
    }


    public function update_customer_details(Request $req) {
    
        $fname=$req->fname;
        $email=$req->email;
        $mobile=$req->mobile;
        $parent_service=$req->parent_service;
        $requirements=$req->requirements;
        DB::table('members')->where('id',$req->id)->update(array('fname'=>$fname,'email'=>$email,'mobile'=>$mobile));
        DB::table('customer_requirements')->where('user_id',$req->id)->update(array('parent_service'=>$parent_service,'requirements'=>$requirements));
        return response()->json(['status'=>200,'data'=>$parent_service]);
    }
    
    public function delete_customer_details(Request $req) {
        
        
        DB::table('members')->where('id',$req->id)->delete();
        DB::table('customer_requirements')->where('user_id',$req->id)->delete();
        DB::table('services_requests')->where('customer_id',$req->id)->delete();
        
        return response()->json(['status'=>200,'data'=>'success']);
    }
}
