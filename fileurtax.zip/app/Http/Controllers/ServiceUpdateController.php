<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\serviceUpdate;

class ServiceUpdateController extends Controller
{
	public function statusUpdate(Request $request) {
        $serviceStatus = $request->serviceStatus;
        $date = $request->date;
        $userId = $request->userId;
        $serviceProviderId = session('session_service_provider');
        $requestValidated = $request->validate(
            [
                'serviceStatus' => 'required',
                'date' => 'required',
            ]
        );
        if($requestValidated) {
            $updateServiceStatus = new serviceUpdate;
            $updateServiceStatus->status = $request->serviceStatus;
            $updateServiceStatus->date = $request->date;
            $updateServiceStatus->userId = $request->userId;
            $updateServiceStatus->serviceProviderId = $serviceProviderId;
            $updateServiceStatus->save();
        }
        if($updateServiceStatus->save()) {
            $seviceUpdate = serviceUpdate::where(
                    [
                        'userId' => $request->userId,
                        'serviceProviderId'=> $serviceProviderId,
                    ]
                    )
                    ->orderBy('id','DESC')
                    ->first();
            $updateBlade = view('ClientServiceProvider.appendServiceUpdates',compact('seviceUpdate'))->render();
            return response()->json(['seviceUpdate' => $updateBlade]);
        }

    }
}
