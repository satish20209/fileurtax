<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ServicesRequestController extends Controller
{
    //
}
