<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PaymenteController extends Controller
{
    public function action(Request $req){
            
            // date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
            // $date= date('d-m-Y H:i:s');
            if(DB::table('paymentes')->where('user_email',$req->email)->first()){
                DB::table('paymentes')->where('user_email',$req->email)->update(array('name'=>$req->name,"amount"=>$req->amt,"payment_status"=>'pending'));
                return response()->json(['status'=>200,'data'=>'succes']);
            }else{
                
                if(DB::table('paymentes')->insert(array('user_email'=>$req->email,'name'=>$req->name,"amount"=>$req->amt,"payment_status"=>'pending','payment_date' => Carbon::now('Asia/Kolkata')))){
                    return response()->json(['status'=>200,'data'=>'succes']);
                }else{
                    return response()->json(['status'=>400,'data'=>'error']);
                }
            }
            
          
            
        }
        public function action_success(Request $req){        
            if(DB::table('paymentes')->where('name',$req->name)->update(array('status'=>'success','txn_id'=>$req->payment_id))){
                return response()->json(['status'=>200,'data'=>'succes']);
            }else{
                return response()->json(['status'=>400,'data'=>'error']);
            }        
        }
     
        public function recipt(Request $req){
            $data = array(
                'username'=>$req->username,
                'user_mobile'=>$req->user_mobile,
                'package_name'=>$req->package_name,
                'amt'=>$req->amt,
                'email'=>$req->email,
                'payment_id'=>$req->payment_id,
            );
            return response()->json(['status'=>200,'data'=>$data]);
            
                // $pdf = PDF::loadView("receipt",compact('data'))->setPaper('a4'); 
                // $fileName = "filename.pdf";
                // return $pdf->download($fileName);
            
            
        }
}
