<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Askquotation;
use App\Models\Member;
class AskquotationController extends Controller
{
    public function askQuotationfun(Request $request){

        $customer = Member::where('email',session('customerAuth'))
        ->first();
        $success = new Askquotation;
        $success->name = $customer->fname;
        $success->email = $customer->email;
        $success->mobile = $customer->mobile;
        $success->message = $request->message;
        $success->quotation_price = $request->quotation_price;
        $success->services = $request->services;
        $quotationed = $success->save();
        if ($quotationed) {
 
         $session=session()->put('successMessage',"Message sent successfully! We will contact You soon.");
         return redirect('/quotation');
        }
        else{
            $session=session()->put('faildMessae',"Message Send Field Please Try Again !");
            return redirect('/quotation');
        }

    }
}
