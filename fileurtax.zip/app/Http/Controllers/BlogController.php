<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Blog;
use Illuminate\Support\Arr;

class BlogController extends Controller
{
    function blogs(){
        return view('show_blog');
    }


    function submit_blog (Request $req){
        $blog_name=$req->blog_name;
        $create=Carbon::now('Asia/Kolkata');
        if ($req->hasFile('thumbnail')) {
            $image = $req->file('thumbnail');
            $name = time().'blog_title.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/blogs/'.$name;
            Storage::disk('fileurtax')->put($destinationPath, file_get_contents($image));
        }
        
        DB::table("blogs")->insert(array('content'=>$req->content,'title'=>$req->title_name,'thumbnail'=>$name,'blogName'=>$blog_name,'created_at'=>$create));
         return redirect('adminlogin');
    }
    public function get_all_blogs(){
        $data=DB::table('blogs')->get();
        return response()->json(['status'=>200,'data'=>$data]); 

    }
    public function viewBlog(Request $req){
        return view('viewBlog');
    }
    public function read_blogs(Request $req){
        return view('/viewBlog');
        
    }
    public function updateblog( Request $req){
        $id=$req->blog_id;
        $blog_name=$req->blog_name;
        $name="";
        $create=Carbon::now('Asia/Kolkata');
        if ($req->hasFile('thumbnail')) {
            $image = $req->file('thumbnail');
            $name = time().'blog_title.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/blogs/'.$name;
            Storage::disk('fileurtax')->put($destinationPath, file_get_contents($image));
        }
        if($name){
            DB::table("blogs")->where('id',$id)->update(array('content'=>$req->content,'title'=>$req->title_name,'thumbnail'=>$name,'blogName'=>$blog_name,'created_at'=>$create));
        }else{
            DB::table("blogs")->where('id',$id)->update(array('content'=>$req->content,'title'=>$req->title_name,'blogName'=>$blog_name,'created_at'=>$create));
        }
         return redirect('adminlogin');
    }
    public function deleteBlog(Request $req){
        DB::table('blogs')->where("id",$req->id)->delete();
        return response()->json(['status'=>200],200);
    }
}
