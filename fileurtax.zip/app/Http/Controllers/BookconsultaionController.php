<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Bookconsultaion;
use Http;
class BookconsultaionController extends Controller
{
   	public function index(){
        return view('bookconsultation');
    }
    public function get_city(Request $req){
        $city_res=Http::withHeaders([
            'Authorization'=>'Bearer '.$req->token,
            ])->get('https://www.universal-tutorial.com/api/cities/'.$req->city);
        $city=json_decode($city_res->body());
        return response()->json(['status'=>200,'data'=>$city]);       
    }
    public function bookconsultaionfun(Request $request){

        $success =  Bookconsultaion::create($request->all());
        if ($success) {
            $session=session()->put('successMessage',"Consultation Book Success ! We will contact You soon.");
            return redirect('/bookconsultation');
        }
        else{
            $session=session()->put('faildMessae',"Message Send Field Please Try Again !");
            return redirect('/bookconsultation');
        }
    }
}
