<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ChildServiceController extends Controller
{
	public function selectChildService(Request $request){
        $childServiceOption = $request->childServiceOption;
        $validate_child_service = $request->validate([
            'childServiceOption' => 'required',
        ]);

        if ($validate_child_service) {
            $child_service_update = ServiceProviderClient::where('id', session('session_service_provider'))->update([
                'services' => $childServiceOption,
            ]);
        }
        if ($child_service_update) {
            return view('ClientServiceProvider.dashboard');
        }
    }

    public function selectOtherChildService(Request $request) {
        $selectOtherChildService = $request->selectOtherChildService;
            $validateChildService = $request->validate(
            [
            'selectOtherChildService' => 'required'
            ]
            );
        if ($validateChildService){
            $insertChildService = ChildService::insertGetId(
            [
            'childService' => $selectOtherChildService,
            'parentService' => session('selectParentService'),
            ]
            );
            $child_service_update = ServiceProviderClient::where('id', session('session_service_provider'))->update([
            'services' => $insertChildService,
            ]);
            
            if ($child_service_update) {
                return redirect('dashboard');
            }
		}
	}
}
