<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use App\Models\ServiceProviderClient;
use Illuminate\Support\Facades\DB;
use Hash;
use Mail;

class ServiceProviderClientController extends Controller
{
	public function index() {
	            return view('index');
	}

    public function login() {
            if(session()->has('session_service_provider') || session()->has('admin') || session()->has('superAdmin')) {
                return redirect('/dashboard');
            }else {
                return view('superAdmin.login');
            }
        }

    // public function serviceProviderRegister(Request $request) {
    //     $validated = $request->validate(
    //         [
    //             'fname' => 'required',
    //             'lname' => 'required',
    //             'email' => 'required|email|unique:service_provider_clients|unique:users',
    //             'password' => 'required',
    //             'mobile' => 'required',
    //             'dob' => 'required',
    //             'qualification' => 'required',
    //         ]
    //     );
    //     if($validated) {
    //         $newServiceProvider = new ServiceProviderClient;
    //         $newServiceProvider->fname = $request->fname;
    //         $newServiceProvider->lname = $request->lname;
    //         $newServiceProvider->email = $request->email;
    //         $newServiceProvider->mobile = $request->mobile;
    //         $newServiceProvider->dob = $request->dob;
    //         $newServiceProvider->qualification = $request->qualification;
    //         $newServiceProvider->password = Hash::make($request->password);
    //         $registrationSuccess = $newServiceProvider->save();
    //     }
    //     if($registrationSuccess) {
    //         return response()->json(['success'=>'Form is successfully submitted!']);
    //     }
    // }
    public function serviceProviderRegister(Request $request) {
        $validated = $request->validate(
            [
                'fname' => 'required',
                'lname' => 'required',
                'email' => 'required|email|unique:service_provider_clients|unique:users',
                'password' => 'required',
                'mobile' => 'required',
                'dob' => 'required',
                'qualification' => 'required',
            ]
        );
        if($validated) {
          
         
            $newServiceProvider = new ServiceProviderClient;
            $newServiceProvider->fname = $request->fname;
            $newServiceProvider->lname = $request->lname;
            $newServiceProvider->email = $request->email;
            $newServiceProvider->mobile = $request->mobile;

            $newServiceProvider->experience = $request->experience;
            $newServiceProvider->salary_range = $request->radio;
            $newServiceProvider->dob = $request->dob;
            $newServiceProvider->qualification = $request->qualification;
            $newServiceProvider->password = Hash::make($request->password);

            if($request->hasfile('picture')){
                $file=$request->file('picture');
                $extention=$file->getClientOriginalExtension();
                $filename=time().'.'.$extention;
                $file->move('images/ServiceProvoderClint/Profile/',$filename);
                $newServiceProvider->image = $request->picture;
                $newServiceProvider->image=$filename;
                
    
            }


            $registrationSuccess = $newServiceProvider->save();
        }
        if($registrationSuccess) {
            return response()->json(['success'=>'Form is successfully submitted!']);
        }
    }


    public function serviceProviderLogin(Request $request) {
        $login_form_validated = $request->validate(
            [
                'email_login' => 'required|email|exists:service_provider_clients,email',
                'password_login' => 'required',
            ]
        );
        if($login_form_validated) {
            $service_provider_details = ServiceProviderClient::where('email',$request->email_login)->first();
            $check_password = Hash::check($request->password_login,$service_provider_details->password);
            if($check_password) {
                $session_service_provider = session()->put('session_service_provider',$service_provider_details->id);
                if($service_provider_details->services === NULL) {
                    return response()->json(['login_status' => 'Logged in and Need Service Update']);
                }else {
                    $session=session()->put('serviceProviderEmail',$request->email_login);
                    return response()->json(['login_status' => 'Successfully Log In']);
                }

            }else {
                return response()->json(['login_status' => 'Password Not Match']);
            }
        }
    }


    public function serviceProviderLocation(Request $request) {
        if($request->has('lat') && $request->has('longt')) {
            $update_location = ServiceProviderClient::where('id',session('session_service_provider'))
                                ->update(
                                    [
                                        'lat' => $request->lat,
                                        'longt' => $request->longt,
                                    ]
                                );
            if($update_location) {
                return response()->json(['status' => 'Location Updated']);
            }else {
                return response()->json(['status' => 'Location Not Updated']);
            }
        }
    }

    public function services(Request $request) {
        if(session()->has('session_service_provider')) {
            $serviceDetails = DB::table('users')
                    ->where('serviceProvider',session('session_service_provider'))
                    ->paginate(6);
            if ($request->ajax()) {
                $view = view('ClientServiceProvider.appendServices',compact('serviceDetails'))->render();
                return response()->json(['html'=>$view]);
            }
            return view('ClientServiceProvider.services',['serviceDetails'=> $serviceDetails]);
        }else {
            return redirect('login');
        }
    }

    public function serviceDetails($serviceId) {
        if(session()->has('session_service_provider')) {
            return view('ClientServiceProvider.serviceDetails',['userId' => $serviceId]);
        }else {
            return redirect('login');
        }
    }

    public function serviceProviderlogout() {
        session()->forget('session_service_provider');
        return redirect('login');
    }
    
    public function get_profile_info(Request $req) {
        $email=session('serviceProviderEmail');
        $data=DB::table('service_provider_clients')->where('email',$email)->first();
        // print_r($data);
        if($data){
            return response()->json(['status' => '200','Data'=>$data]);
        }else{
            return response()->json(['status' => '400','Data'=>'something went wrong']);
        } 
    }
    public function update_profile_info(Request $request) {
        $email=session('serviceProviderEmail');
        $data=DB::table('service_provider_clients')->where('email',$email)->update([
                'fname' => $request->fname,
                'lname' => $request->lname,
                'image' => $request->image,
            ]
        );;
        // print_r($data);
        if($data){
            return response()->json(['status' => '200','Data'=>$data]);
        }else{
            return response()->json(['status' => '400','Data'=>$data]);
        } 
    }
    // public function emailVerify(Request $request) {
    //     $email = $request->email;
    //     $emailValidate = $request->validate(
    //     [
    //     'email' => 'email|required',
    //     ]
    //     );
    //     $checkEmail = ServiceProviderClient::where('email',$email)->exists();
    //     if ($emailValidate) {
    //     if (!$checkEmail) {
    //     $emailCode = ['code'=>rand(100000,999999)];
    //     $insertCode = DB::table('email_verification')->insert(
    //     [
    //     'email' => $email,
    //     'verificationCode' => $emailCode['code'],
    //     ]
    //     );
    //     $request->session()->put('newEmail',$email);
    //     Mail::send('ClientServiceProvider.mailVerification', ['emailCode'=>$emailCode], function($message) use($email){
    //     $message->to($email)->subject
    //     ('FileUrTax Mail Verification Code');
    //     $message->from('imaluopp@gmail.com','FILEURTAX');
    //     });
    //     return response()->json(['emailcode'=>$emailCode]);//'status'=>'Email not registered',
    //     }else {
    //     return response()->json(['status'=>'Email Already registered']);
    //     }
    //     }
    // }

    // public function emailCodeVerify(Request $request) {
    //     $code = $request->emailCode;
    //     $email=session('newEmail');
    //     $getCodeFromDB = DB::table('email_verification')->where('email',$email)
    //     ->orderBy('id','desc')
    //     ->first();
    //     if ($code == $getCodeFromDB->verificationCode) {
    //     return response()->json(['status'=>'Verification Complete']);
    //     }else {
    //     return response()->json(['status'=>'Unable to Verify']);
    //     }
    // }
}