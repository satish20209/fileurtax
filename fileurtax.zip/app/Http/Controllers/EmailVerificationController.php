<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServiceProviderClient;
use Illuminate\Support\Facades\DB;
use Hash;
use Mail;

class EmailVerificationController extends Controller
{
	public function emailVerify(Request $request) {
        $email = $request->email;
        $emailValidate = $request->validate(
        [
        'email' => 'email|required',
        ]
        );
        $checkEmail = ServiceProviderClient::where('email',$email)->exists();
        if ($emailValidate) {
        if (!$checkEmail) {
        $emailCode = ['code'=>rand(100000,999999)];
        $insertCode = DB::table('email_verifications')->insert(
        [
        'email' => $email,
        'verificationCode' => $emailCode['code'],
        ]
        );
        $request->session()->put('newEmail',$email);
        Mail::send('ClientServiceProvider.mailVerification', ['emailCode'=>$emailCode], function($message) use($email){
        $message->to($email)->subject
        ('FileUrTax Mail Verification Code');
        $message->from('info@fileurtax.com','FILEURTAX');
        });
        return response()->json(['emailcode'=>$emailCode]);//'status'=>'Email not registered',
        }else {
        return response()->json(['status'=>'Email Already registered']);
        }
        }
    }

    public function emailCodeVerify(Request $request) {
        $code = $request->emailCode;
        $email=session('newEmail');
        $getCodeFromDB = DB::table('email_verifications')->where('email',$email)
        ->orderBy('id','desc')
        ->first();
        if ($code == $getCodeFromDB->verificationCode) {
        return response()->json(['status'=>'Verification Complete']);
        }else {
        return response()->json(['status'=>'Unable to Verify']);
        }
    }

    public function deleteemail( Request $request)
    {
        $deleteemail = DB::table('email_verifications')->where('email',$request['email'])->delete();
        if ($deleteemail) {
            return $request['email']."delete success";
        }else{
            return "delete faild";
        }
        
    }
}
