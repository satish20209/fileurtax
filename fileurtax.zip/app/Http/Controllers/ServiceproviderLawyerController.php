<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Storage;
use Aws\S3\Exception\S3Exception as S3;
use Illuminate\Support\Carbon;
class ServiceproviderLawyerController extends Controller
{
    public function layerSetting(){
      if (session()->has('layerAuth')) {
        return view('lawyer.settings');
      }else {
        return redirect('login');
      }
    }
    public function helplawyer(){
      if (session()->has('layerAuth')) {
        return view('lawyer.helplawyerview');
      }else {
        return redirect('login');
      }
    }
    public function lawyerAcceptRequest(Request $request) {
            //---------------|-------------//
            // Status | Code //
            //---------------|-----------//
            // Sent | 0 //
            //---------------|---------//
            // Accepted | 1 //
            //---------------|-------//
            // Denied | -1 //
            //---------------|-----//
            $customer_id = $request->customer_id;
            $service_provider_id = $request->service_provider_id;
            DB::table('services_requests')->where(
            [
            'service_provider_id' => $service_provider_id,
            'customer_id' => $customer_id,
            ]
            )
            ->update([
            'status' => 1,
            ]);
            return redirect('lawyerDashboard');
    }
    
    public function lawyerDashboard() {
        if (session()->has('layerAuth')) {
            return view('lawyer.lawyerDashboard');
        }else {
            return redirect('login');
        }
    }
    public function index(){
        $res=Http::withHeaders([
            'api-token'=>'qSNLEDb9OOJ9-CHiL04BIL4Hhi18zhE5XUT3fY78W0hIcJfxYnf-KjL8hBvzka40or4',
            'user-email'=>'rathouryogesh40@gmail.com'
            ])->get('https://www.universal-tutorial.com/api/getaccesstoken');
        $data=(array)json_decode($res->body());
        if(isset($data['auth_token'])){
            $auth_token=$data['auth_token'];
            $country_res=Http::withHeaders([
            'Authorization'=>'Bearer '.$auth_token,
            ])->get('https://www.universal-tutorial.com/api/states/india');
            $country=(array)json_decode($country_res->body());
            
            if(session()->has('layerAuth')){
                $user_id=DB::table('members')->where('email',session('layerAuth'))->first()->id;
                if(!DB::table('serviceprovider_lawyers')->where('userId',$user_id)->first()){
                    return view('serviceproviderregister.lawyerdetails',['token'=>$auth_token,'country'=>$country]);;
                }else{
                    
                    return redirect('lawyerDashboard');
                }
                
            }else{
                // return redirect('/loginpage');
            }
        }else{
            
            return redirect('register_lawyer');    
        }
    }
    public function customerDetails(Request $request) {
        $customer_id = $request->customer_id;
        return view('lawyer.customerDetails')->with('customer_id', $customer_id);
    }
    public function recentServices() {
        if (session()->has('layerAuth')) {
            return view('lawyer.recentServices');
        }else {
            return redirect('login');
        }
    }
    public function laywerLogOut() {
        session()->forget('layerAuth');
        return redirect('login');
    }
    public function lawyerDenyRequest(Request $request) {
        //---------------|-------------//
        // Status | Code //
        //---------------|-----------//
        // Sent | 0 //
        //---------------|---------//
        // Accepted | 1 //
        //---------------|-------//
        // Denied | -1 //
        //---------------|-----//
        $customer_id = $request->customer_id;
        $service_provider_id = $request->service_provider_id;
        DB::table('services_requests')->where(
        [
        'service_provider_id' => $service_provider_id,
        'customer_id' => $customer_id,
        ]
        )
        ->update([
        'status' => -1,
        ]);
        return redirect('lawyerDashboard');
    }
    public function viewlogin(){
        if(session()->has('layerAuth')){
            return redirect('lawyerDashboard');
        }else{
            return view('login-lawyer');
        }   
    }
    public function runningServices(){
        if (session()->has('layerAuth')) {
            return view('lawyer.runningServices');
        }else {
            return redirect('login');
        }
    }
    public function registerspfun(Request $req){
        $fname=$req->fname;
        $mobile=$req->mobile;
        $email=$req->email;
        $gender=$req->gender;
        $practincingSince=$req->practincingSince;
        $amount=$req->amount;
        $secondary_practice_area=$req->secondary_practice_area;
        $country=$req->country;
        $barEnrollmentNumber=$req->barEnrollmentNumber;
        $language=$req->language;
        $practice_state=$req->practice_state;
        $state=$req->state;
        $enrollment_state=$req->enrollment_state;
        $practice_Areas_primary=$req->practice_Areas_primary;
        $practice_courts=$req->practice_courts;
        $city=$req->city;
       $address=$req->address;
        $pincode=$req->pincode;
        $abouts=$req->abouts;
        $facebook=$req->facebook;
        $twitter=$req->twitter;
        $linkedin=$req->linkedin;
        $publication_areas_1=$req->publication_areas_1;
        $publication_areas_2=$req->publication_areas_2;
        $publication_areas_3=$req->publication_areas_3;
        $monday=$req->monday;
        $tuesday=$req->tuesday;
        $wednesday=$req->wednesday;
        $thursday=$req->thursday;
        $friday=$req->friday;
        $saturday=$req->saturday;
        $sunday=$req->sunday;
        $lat=$req->lat;
        $longt=$req->longt;
        $aadhaarcard=$req->aadhaarcard;
        $pancard=$req->pancard;
        $imageName=null;
        $aadhar_imageName=null;
        $pan_imageName=null;
        
        if($req->barid){
            $photo = $req->barid;
            $image_64 = $photo; //your base64 encoded data
            $extension = explode('/', explode(':', substr($image_64, 0, strpos($image_64, ';')))[1])[1];   // .jpg .png .pdf
            $replace = substr($image_64, 0, strpos($image_64, ',')+1); 
            // find substring fro replace here eg: data:image/png;base64,
            $image = str_replace($replace, '', $image_64); 
            $image = str_replace(' ', '+', $image); 
            $imageName = 'certificate'.'.'.$extension;
            $final = base64_decode($image);
            $destinationPath = 'fileurtax/serviceprovider/'.$email.'/'.$imageName;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, $final);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
            if($errorMessage){
                return back()->with('error',"Internal server error ! Please Try Again ");
            }
            }
            // $success = file_put_contents("customer_files/".$imageName, $final);
        }
        if($req->aadhar_img){
            $aadhar_photo = $req->aadhar_img;
            $aadhar_image_64 = $aadhar_photo; //your base64 encoded data
            $extension = explode('/', explode(':', substr($aadhar_image_64, 0, strpos($aadhar_image_64, ';')))[1])[1];   // .jpg .png .pdf
            $replace = substr($aadhar_image_64, 0, strpos($aadhar_image_64, ',')+1); 
            // find substring fro replace here eg: data:image/png;base64,
            $aadhar_image = str_replace($replace, '', $aadhar_image_64); 
            $aadhar_image = str_replace(' ', '+', $aadhar_image); 
            $aadhar_imageName = 'aadhar'.'.'.$extension;
            $aadhar_final = base64_decode($aadhar_image);
            $destinationPath = 'fileurtax/serviceprovider/'.$email.'/'.$aadhar_imageName;
            try {
                Storage::disk('fileurtax')->put($destinationPath, $aadhar_final);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
            if($errorMessage){
                return back()->with('error',"Internal server error ! Please Try Again ");
            }
            }
            
            // $aadhar_success = file_put_contents("customer_files/".$aadhar_imageName, $aadhar_final);
        }
        if($req->pan_img){
            $pan_photo = $req->pan_img;
            $pan_image_64 = $pan_photo; //your base64 encoded data
            $extension = explode('/', explode(':', substr($pan_image_64, 0, strpos($pan_image_64, ';')))[1])[1];   // .jpg .png .pdf
            $replace = substr($pan_image_64, 0, strpos($pan_image_64, ',')+1); 
            // find substring fro replace here eg: data:image/png;base64,
            $pan_image = str_replace($replace, '', $pan_image_64); 
            $pan_image = str_replace(' ', '+', $pan_image); 
            $pan_imageName = 'pancard'.'.'.$extension;
            $pan_final = base64_decode($pan_image);
            $destinationPath = 'fileurtax/serviceprovider/'.$email.'/'.$pan_imageName;
            
            try {
                Storage::disk('fileurtax')->put($destinationPath, $pan_final);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
            if($errorMessage){
                return back()->with('error',"Internal server error ! Please Try Again ");
            }
            }
            // $pan_success = file_put_contents("customer_files/".$pan_imageName, $pan_final);
        }
        
            

        $user_id=DB::table('members')->where('email',$email)->first()->id;
        if(DB::table('members')->where('email',$email)->update(array('gender'=>$gender,'fname'=>$fname,'mobile'=>$mobile,'lat'=>$lat,'longt'=>$longt))){
            
        }
        if(DB::table('serviceprovider_lawyers')->insert(array('practice_state'=>$practice_state,'language'=>$language,'barEnrollmentNumber'=>$barEnrollmentNumber,'practincingSince'=>$practincingSince,'amount'=>$amount,'secondary_practice_area'=>$secondary_practice_area,'country'=>$country,'state'=>$state,'enrollment_state'=>$enrollment_state,'practice_Areas_primary'=>$practice_Areas_primary,'practice_courts'=>$practice_courts,'city'=>$city,'address'=>$address,'pincode'=>$pincode,'abouts'=>$abouts,'facebook'=>$facebook,'twitter'=>$twitter,'linkedin'=>$linkedin,'publication_areas_1'=>$publication_areas_1,'publication_areas_2'=>$publication_areas_2,'publication_areas_3'=>$publication_areas_3,'monday'=>$monday,'tuesday'=>$tuesday,'wednesday'=>$wednesday,'thursday'=>$thursday,'friday'=>$friday,'saturday'=>$saturday,'sunday'=>$sunday,'aadhaarcard'=>$aadhaarcard,'pancard'=>$pancard,'userId'=>$user_id,'barCouncildD'=>$imageName,'aadharpic'=>$aadhar_imageName,'pancardpic'=>$pan_imageName))){
    
            return response()->json(['status'=>200,'data'=>'success']);
        }
        else{
            return response()->json(['status'=>500,'data'=>'something went wrong']);   
        }
    }
    public function lawyerQuotation() {
        if (session()->has('layerAuth')) {
        return view('lawyer.lawyerQuotation');
        }else {
        return redirect('login');
        }
    }
    public function update_lyr_tab_1(Request $req){
        if ($req->hasFile('picture')) {
            $image = $req->file('picture');
            $imgname = 'profile'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('layerAuth').'/'.$imgname;
            try {
                Storage::disk('fileurtax')->put($destinationPath, file_get_contents($image));
            } catch(S3 $e) {
                return $e->getAwsErrorMessage();
            }
            DB::table('members')->where('email',session('layerAuth'))->update(array('profileImage'=>$imgname));
        }
        DB::table('members')->where('email',session('layerAuth'))->update(['fname'=>$req->fname,'gender'=>$req->gender,'experience'=>$req->experience,'salary'=>$req->salary]);
        $id=DB::table('members')->where('email',session('layerAuth'))->first('id')->id;
        DB::table('serviceprovider_lawyers')->where('userId',$id)->update(['aadhaarcard'=>$req->aadhar_card,'pancard'=>$req->pancard]);     
        return redirect('/UpdateLawyer');
    }
    public function update_lyr_tab_2(Request $req){
        $practincingSince=$req->practincingSince;
        $practice_courts=$req->practice_courts;
        $bar_number=$req->bar_number;
        $fee_amt=$req->fee_amt;
        $bar_state=$req->bar_state;
        $language= $req->language;
        $practice_Areas_primary=$req->practice_Areas_primary;
        $secondary_practice_area=$req->secondary_practice_area;
        $practice_state=$req->practice_state;
        $country=$req->country;
        $state=$req->state;
        $city=$req->city;
        $address=$req->address;
        $pincode=$req->pincode;
       
        $id=DB::table('members')->where('email',session('layerAuth'))->first('id')->id;
        DB::table('serviceprovider_lawyers')->where('userId',$id)->update([
            'practincingSince'=> $practincingSince,'amount'=> $fee_amt,'secondary_practice_area'=> $secondary_practice_area,'country'=> $country,
            'barEnrollmentNumber'=> $bar_number,'language'=> $language,'practice_state'=> $practice_state,
            'state'=> $state,'enrollment_state'=> $bar_state,'practice_Areas_primary'=> $practice_Areas_primary,
            'practice_courts'=> $practice_courts,'pincode'=> $pincode,'city'=> $city,'address'=> $address,       
        ]);
        return redirect("/UpdateLawyer");
    }
    public function update_Ltab_3(Request $req){
        $userid=DB::table('members')->where('email',session('layerAuth'))->first('id')->id;
        if ($req->hasFile('bar_council')) {
            $image = $req->file('bar_council');
            // $imgname = time().'.'.$image->getClientOriginalExtension();
            $imageName = 'certificate'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('layerAuth').'/'.$imageName;
            try {
                Storage::disk('fileurtax')->put($destinationPath, $image);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
            if($errorMessage){
                return back()->with('error',"id Internal server error ! Please Try Again ");
            }
            }
            
            
            DB::table('serviceprovider_lawyers')->where('userId',$userid)->update(array('barCouncildD'=>$imageName));
            

        }if ($req->hasFile('aadhar')) {
            $image = $req->file('aadhar');
            // $imgname = time().'.'.$image->getClientOriginalExtension();
            $imageName = 'aadhar'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('layerAuth').'/'.$imageName;
            try {
                Storage::disk('fileurtax')->put($destinationPath, $image);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
            if($errorMessage){
                return back()->with('error',"aaddar Internal server error ! Please Try Again ");
            }
            }
            // $userid=DB::table('members')->where('email',session('layerAuth'))->first('id')->id;
            DB::table('serviceprovider_lawyers')->where('userId',$userid)->update(array('aadharpic'=>$imageName));
            

        }
        if ($req->hasFile('pancard')) {
            $image = $req->file('pancard');
            // $imgname = time().'.'.$image->getClientOriginalExtension();
            $imageName = 'pancard'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.session('layerAuth').'/'.$imageName;
            try {
                Storage::disk('fileurtax')->put($destinationPath, $image);
            } catch(S3 $e) {
                $errorMessage =  $e->getAwsErrorMessage();
            if($errorMessage){
                return back()->with('error',"pancard Internal server error ! Please Try Again ");
            }
            }
            DB::table('serviceprovider_lawyers')->where('userId',$userid)->update(array('pancardpic'=>$imageName));
            
            
            
        }
        return redirect('/lawyerDashboard');
        
    }
     
    public function requestPayment(){
        if (session()->has('layerAuth')) {
            return view('lawyer.requestPayment');
        }else {
            return redirect('login');
        }
    }
    public function lyerrequestPayment(Request $req) {
        if (session()->has('layerAuth')) {
            DB::table('paymentrequest')->insert(array('consultationId'=>$req->consultation_id,'customerId'=>$req->customer_id,'status'=>0,'requestDate'=>Carbon::now('Asia/Kolkata'),'paymentStatus'=>0));
        }
        return redirect('/requestPayment');
    }
    
}
