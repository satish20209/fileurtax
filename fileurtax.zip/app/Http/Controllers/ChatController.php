<?php
// cp .env.example .env
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Events\Raj;
use App\Models\Chat;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class ChatController extends Controller
{
    public function chatview(Request $request)
    {if(session('caAuth')){
        return view('chat.chat');
    }elseif (session('csAuth')) {
        return view('chat.chat');
    }
    elseif (session('cmaAuth')) {
        return view('chat.chat');
    }
    elseif (session('layerAuth')) {
        return view('chat.chat');
    }
    elseif (session('customerAuth')){
        return view('chat.chat');
        
    }else{
        return redirect('login');
    }
        
    }
    public function showserviceprovider(Request $request)
    {
        return view('chat.uchat');
    }
    public function showcustomer(Request $request)
    {
        return view('chat.spchat');
    }
    public function chatmsg(Request $request)
    { 
        $alldata=$request->all();
        $name = $request->filechat;
        $channel_id = $request->from;
        $user_id = $request->to;
        $msg = $request->msg;
        $sendar_idd=$request->sender;
        $alldata['chanelId']=$channel_id.'-'.$user_id;
        $alldata['msg'] = $msg ? $msg : " ";
        $id=Chat::create($alldata);
        $fileId= $id ? $id->id : " ";
        event(new Raj($msg,$user_id,$channel_id,$sendar_idd,$name,$fileId));
        return null;         
    }

    public function signin(){
        if(session('caAuth')){
            return redirect('caDashboard');
        }elseif (session('csAuth')) {
            return redirect('csDashboard');
        }
        elseif (session('cmaAuth')) {
            return redirect('cmaDashboard');
        }
        elseif (session('layerAuth')) {
            return redirect('lawyerDashboard');
        }
        elseif (session('customerAuth')){
            return redirect("/customerDashboard");
            
        }else{
            return view('signin');
        }
 
    }
    public function signup(){
        if(session('caAuth')){
            return redirect('caDashboard');
        }elseif (session('csAuth')) {
            return redirect('csDashboard');
        }
        elseif (session('cmaAuth')) {
            return redirect('cmaDashboard');
        }
        elseif (session('layerAuth')) {
            return redirect('lawyerDashboard');
        }
        elseif (session('customerAuth')){
            return redirect("/customerDashboard");
            
        }else{
            return view('signup');
        }
        
    }
    public function ChatFilenameData(Request $req){
        $data=DB::table('chats')->where('id',$req->id)->first(['filechat','chanelId']);
        return response()->json(['status'=>200,'data'=>$data]);
    }

    public function filedownload($chid, $keyid){
        $headers = [
            'Content-Type'        => 'application/jpeg',
            'Content-Disposition' => 'attachment; filename="'.$keyid.'"',
        ];
        return \Response::make(Storage::disk('fileurtax')->get('fileurtax/chat/'.$chid.'/'.$keyid), 200, $headers);
    }
    public function fileupload(Request $request){

        $file = $request->file('chatfile');
         $filename = $request->filename;
         // File upload location
         $location = $request->foldername;
         // Upload file
         $file->move($location,$filename);        
    }
}
