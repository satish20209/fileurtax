<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ParentService;
use App\Models\ChildService;
use App\Models\ServiceProviderClient;
use Response;

class ParentServiceController extends Controller
{
    public function selectParentService(Request $request) {
            $validate_parent_service = $request->validate(
                [
                    'selectParentService' => 'required',
                ]
            );

            $selectParentService = $request->selectParentService;
            $parent_service_session = $request->session()->put('selectParentService',$selectParentService);
            $getChildServices_exists = ChildService::where('parentService',$request->selectParentService)->exists();
            $getChildServices = ChildService::where('parentService',$request->selectParentService)->get();

            if($validate_parent_service ) {
                $update_parent_service = ServiceProviderClient::where('id',session('session_service_provider'))
                                        ->update(
                                            [
                                                'parentService' => $request->selectParentService,
                                            ]
                                        );
                if($getChildServices_exists) {
                    return response()->json(['response' => $getChildServices]);
                }
                //return view('login',compact('getChildServices',$getChildServices));
            }
    }
}
