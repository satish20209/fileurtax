<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Enrollment;

class EnrollmentController extends Controller
{
	public function enrollLawyers() {
        return view('lawyer.enrollLawyers');
    }


    public function enrollCA() {
        return view('CA.enrollCA');
    }

    public function enrollCS() {
        return view('CS.enrollCS');
    }

    public function enrollCMA() {
        return view('CMA.enrollCMA');
    }

    public function enrollData(Request $request) {
        $validation = $request->validate([
            'email' => 'required|email|unique:enroll_consultants'
        ]);
        if ($validation) {
            $name = $request->name;
            $email = $request->name;
            $phone = $request->phone;
            return response()->json([
                'status' => 'Data Validated',
                'code' => 200,
                'data' => $request->all(),
            ]);
        }else {
            return response()->json([
                'status' => 'Data Validation Failed',
                'code' => 400,
            ]);
        }
        
    }

    public function enrollDataStore(Request $request) {
        $name = $request->userName;
        $email = $request->userEmail;
        $phone = $request->userPhone;
        $role = $request->role;
        $insertData = Enrollment::insert(
            [
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'role' => $role,
            ]
        );
        if ($insertData) {
            return response()->json([
                'status' => 'Enrollment Successful',
                'code' => 200,
            ]);
        }else {
            return response()->json([
                'status' => 'Enrollment Not Successful',
                'code' => 400,
            ]);
        }
    }
}
