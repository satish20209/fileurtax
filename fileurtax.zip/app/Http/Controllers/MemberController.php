<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Models\Member;
use Illuminate\Support\Facades\DB;
use App\Models\Registerserviceproviders;
use Hash;
use Mail;
use Storage;

class MemberController extends Controller
{
	public function membersignup(Request $req){
        $fname=$req->fname." ".$req->lname;
        $mobile=$req->mobile;
        $password=$req->password;
        $dob=$req->dob;
        $email=$req->email;
        $experience=$req->experience;
        $picture=$req->picture;
        $role=$req->role;
        $radio=$req->radio;
        $callback=$req->callback;
        if($callback=='checked'){
            $callback=1;
        }else{
            $callback=0;
        }
            if ($req->hasFile('picture')) {
            
                // s3 code 
            // $image = $req->file('picture');
            // $name = time().'.'.$image->getClientOriginalExtension();
            // $destinationPath = public_path('image/customer_files');
            // Storage::disk('s3')->put($destinationPath, file_get_contents($image));

            // local code 
            $image = $req->file('picture');
            $name = 'profile_pic'.'.'.$image->getClientOriginalExtension();
            $destinationPath = 'fileurtax/serviceprovider/'.$email.'/'.$name;
            Storage::disk('fileurtax')->put($destinationPath, file_get_contents($image));
           
            

         
            
           
            }else{
                $name = NULL;
            }
            if(DB::table('members')->insert(array('callback'=>$callback,'fname'=>$fname,'mobile'=>$mobile,'email'=>$email,'experience'=>$experience,'role'=>$role,'dob'=>$dob,'salary'=>$radio,'password'=>$password,'profileImage'=>$name))){

                return redirect('/login');
            }
            else{
                
                echo "<script>alert('You have already registerd Please Login')</script>";
                
                return redirect('/login');
            }
    }

    public function login(Request $req){
        $email=$req->email;
        $password=$req->password;
        $data=DB::table('members')->where('email',$email)->first();
        //  print_r($email);
        //  exit();
        if($data){
            
            $pass=DB::table('members')->where('email',$email)->first()->password;
            if($password==$pass){
            
            
            $role=DB::table('members')->where('email',$email)->first(['role'])->role;
            if (session()->has('check_quotation')) {
                    

                if(time() - session('check_quotation') >= 300){
                    $req->session()->forget('check_quotation');
                    
                }else{
                    $temp_ar=['L'=>'layerAuth','CA'=>'caAuth','CS'=>'csAuth','CMA'=>'cmaAuth','C'=>'customerAuth'];
                    foreach($temp_ar as $key => $val){
                        if($role==$key){
                            $ss=session()->put($val, $email);
                        }
                    }

                    $req->session()->forget('check_quotation');
                    return response()->json(['status'=>200,'response'=>"quotation"],200);

                }
                
            }
            if($role=="L"){

                $ss=session()->put('layerAuth', $email);
                return response()->json(['status'=>200,'response'=>"register_lawyer"],200);
                // return redirect('register_lawyer');

            }else if($role=="CA"){

                $ss=session()->put('caAuth', $email);
                return response()->json(['status'=>200,'response'=>"registerca"],200);
                // return redirect('registerca');

            }else if($role=="CS"){

                $ss=session()->put('csAuth', $email);
                return response()->json(['status'=>200,'response'=>"register_CS"],200);
                // return redirect('register_CS');

            }else if($role=="CMA"){

                $ss=session()->put('cmaAuth', $email);


                return response()->json(['status'=>200,'response'=>"register_CMA"],200);
                // return redirect('register_CMA');

            }else if($role=="C"){

                $ss=session()->put('customerAuth', $email);
                return response()->json(['status'=>200,'response'=>"customerDashboard"],200);
                // return redirect('customerDashboard');

            }
            }else{
                return response()->json(['status'=>404,'response'=>"Paasword Not Matched !"],404);
            }
        }else{
            return response()->json(['status'=>404,'response'=>"User Name Not Found !"],404);
        } 

    }
    public function customerLogOut(Request $request) {
        $request->session()->flush();
        return redirect('login');
    }
    public function updatepassword(Request $request) {
        $res = Member::where("email",$request->email)->update(['password'=>$request->password]);
        if ($res) {
            return response()->json(['status'=>200,'response'=>"Password reset success"],200);
        }else{
            return response()->json(['status'=>500,'response'=>$request->email],500);
        }
    }
   
}
