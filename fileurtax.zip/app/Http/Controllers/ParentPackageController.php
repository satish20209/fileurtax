<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class ParentPackageController extends Controller
{
    
}
