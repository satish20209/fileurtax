<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bid;

class BidController extends Controller
{
	public function bidSubmit(Request $request) {
        $quotationid = $request->quotationid;
        $consultantId = $request->consultantId;
        $amount = $request->amount;
        $bid  = new Bid;
        $bid->quotationid = $quotationid;
        $bid->consultantId = $consultantId;
        $bid->amount = $amount;
        $bidded = $bid->save();
        return redirect()->back();
    }

    public function viewBids(Request $request) {
        if (session()->has('customerAuth')) {
            return view('customer.viewBids');
        }else {
            return redirect('login');
        }
    }
    
    public function superAdminBids(Request $request) {
        if (session()->has('superAdmin')) {
            return view('superAdmin.superAdminViewBids');
        }else{
            return redirect('login');
        }
    }
}
