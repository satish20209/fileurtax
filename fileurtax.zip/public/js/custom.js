// $(document).ready(function() {
//     $(".practice-block .inner-box").each(function() {
//         var a = ["#06b1ac", "#007cc4", "#330ec4", "#e39f02", "#134c8d", "#47389c", "#b66803", "#d90481"][Math.floor(8 * Math.random())];
//         $(this).css({
//             "background-color": a
//         })
//     }), $(".practice-block .inner-box").each(function() {
//         var a = ["#06b1ac", "#007cc4", "#330ec4", "#e39f02", "#134c8d", "#47389c", "#b66803", "#d90481"][Math.floor(8 * Math.random())];
//         $(this).hover(function() {
//             $(this).css({
//                 "background-color": a
//             })
//         })
//     }), $(".practice-block .inner-box").each(function() {
//         var a = ["#06b1ac", "#007cc4", "#330ec4", "#e39f02", "#134c8d", "#47389c", "#b66803", "#d90481"][Math.floor(8 * Math.random())];
//         $(this).mouseleave(function() {
//             $(this).css({
//                 "background-color": a
//             })
//         })
//     })
// })