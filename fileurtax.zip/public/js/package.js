$(document).ready(function () {
    $(".buy-now-a").on("click", function (g) {
        g.preventDefault();
        var c = this.parentElement.parentElement,
            e = c.getElementsByTagName("P")[0].innerHTML.split(" ")[1],
            d = c.parentElement.getElementsByTagName("H5")[0].innerHTML,
            a = c.parentElement.parentElement.parentElement.parentElement.getAttribute("id"),
            i = e,
            d = d,
            h = $("#email").val(),
            b = "";
        "registerbusiness" == a || "registerbusiness" == a || "registerbusiness" == a || "registerbusiness" == a
            ? (b = 1)
            : "protectyourintellectualporperty" == a || "protectyourintellectualporperty" == a || "protectyourintellectualporperty" == a || "protectyourintellectualporperty" == a
            ? (b = 3)
            : "easytaxregistrationsandfilling" == a || "easytaxregistrationsandfilling" == a || "easytaxregistrationsandfilling" == a || "easytaxregistrationsandfilling" == a
            ? (b = 4)
            : ("mandatorycompliances" == a || "mandatorycompliances" == a || "mandatorycompliances" == a || "mandatorycompliances" == a) && (b = 5);
        var f = { package_name: d, amt: e, email: h, parent_id: b, _token: $("body").attr("token") };
        f.email ||   sessionStorage.setItem("lasttime", Math.round(date = new Date().getTime() / (1000*60)));sessionStorage.getItem("lasttime") ? (window.location.href = "/login") : console.log() ,
            $.ajax({
                type: "POST",
                url: "/process_package",
                data: f,
                dataType: "json",
                beforeSend: function () {
                    $(".loader-icon").removeClass("d-none");
                },
                success: function (a, b) {
                    if (200 == a.status) 
                    var c = a.id;
                    var options = {
                        "key": "rzp_live_6hXmEuiPgjqSaA", // Enter the Key ID generated from the Dashboard
                        "amount": 100*1, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                        "currency": "INR",
                        "name": "Fileurtax",
                        "description": "Packages Transaction",
                        "image": "https://example.com/your_logo",
                        // "order_id": "order_IluGWxBm9U8zJ8", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                        "handler": function (response){
                            alert(response.razorpay_payment_id);
                            alert(response.razorpay_order_id);
                            alert(response.razorpay_signature)
                        },
                        "prefill": {
                            "name": "Gaurav Kumar",
                            "email": "rakesh112solanki@gmail.com",
                            "contact": "9617388086"
                        },
                        "notes": {
                            "address": "West Bengal Kolkata 700028"
                        },
                        "theme": {
                            "color": "#3399cc"
                        },
                        headers: 
                        {
                            "authorization" : "Fileurtax"
                        },
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.on('payment.failed', function (response){
                            alert(response.error.code);
                            alert(response.error.description);
                            alert(response.error.source);
                            alert(response.error.step);
                            alert(response.error.reason);
                            alert(response.error.metadata.order_id);
                            alert(response.error.metadata.payment_id);
                    });
                    
                    rzp1.open();
                    e.preventDefault();
                },
            });
    });
});


// handler: function (a) {
//     jQuery.ajax({
//         type: "get",
//         url: "process_success_package",
//         data: "txn_id=" + a.razorpay_payment_id + "&payment_id=" + c,
//         success: function (b, f) {
//             var c = { txn: a.razorpay_payment_id, email: h, name: d, amt: i },
//                 e = JSON.stringify(c);
//             sessionStorage.setItem("data", e), 200 == b.status ? (window.location.href = "payment_success") : (window.location.href = "payment_failed");
//         },
//     });
// },