function run() {
    alert("run")
    var i;
    var j = parseInt(document.getElementById("timef").value);
    
    var times = document.getElementById("times");
    $("#times").html("")
    for (i = j; i < 720; i++) {
        var k = i + 30;
        k = k / 60;
        $("#times").append('<option value="' + k + '">' + k + '</option>');
        i = i + 30;
    }
}
function getServiceProviderLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        alert("Geolocation is not supported by this browser.");
    }
}
window.onload = function(){
    getServiceProviderLocation();
    
}
function showPosition(position) {
    var lat = position.coords.latitude; 
    var longt = position.coords.longitude;
    $(".lat").val(lat);
    $(".longt").val(longt);
    
}

$(document).ready(function() {
    let timer;
    document.addEventListener('input', e => {
        const el = e.target;

        if (el.matches('[data-color]')) {
            clearTimeout(timer);
            timer = setTimeout(() => {
                document.documentElement.style.setProperty(`--color-${el.dataset.color}`, el
                    .value);
            }, 500)
        }
    })

})

$(".step-one-next").click(function(e){
    e.preventDefault()
    $(".required-notice").remove();
        if($(".fname").val().trim() == "")
        {
        $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i> Full name can`t empty</small>').insertAfter($(".fnamelabel"))
        }

        if($(".mobile").val().trim() == "")
            {
            $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i> Mobile Number can`t empty</small>').insertAfter($(".mobilelabel"))
            }
        if($(".email").val().trim() == "")
            {
            $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i> Email can`t empty</small>').insertAfter($(".emaillabel"))
            }
        if($("input[name=gender]:checked").val() != "male" && $("input[name=gender]:checked").val() != "female" && $("input[name=gender]:checked").val() != "other" )
            {
            $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i> Please Select Gender</small>').insertAfter($(".genderlabel"))
            }
            if($(".pancard").val() == "")
            {
            $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>PAN Card can`t empty</small>').insertAfter($(".pancardlabel"))
            }
        if($(".aadhaarcard").val() == "")
            {
            $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Aadhaar Card can`t empty</small>').insertAfter($(".aadhaarcardlabel"))
            }else{
                if($(".required-notice").val() != ""){
                    $(".step-one-conn").addClass("d-none");
                    $(".step-two-conn").removeClass("d-none");
                }else{
                    return false;
                }
                

            }

})



$(".step-two-next").click(function(e){
        e.preventDefault();
        if($(".practincingSince").val() == "")
        {
        $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i> Please Select Practincing Since</small>').insertAfter($(".practincingSincelabel"))
        }
            if($(".amount").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i> Fees Amount can`t empty</small>').insertAfter($(".amountlabel"))
                }
            if($(".secondary_practice_area").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Please Select Secondary Practice Area</small>').insertAfter($(".secondary_practice_arealabel"))
                }
            if($(".language").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Please Select Language</small>').insertAfter($(".languagelabel"))
                }
            if($(".practice_state").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Please Select Practice State</small>').insertAfter($(".practice_statelabel"))
                }
            if($(".state").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Please Select  State</small>').insertAfter($(".statelabel"))
                }

            if($(".enrollment_state").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Please Select  Enrollment State</small>').insertAfter($(".enrollment_statelabel"))
                }
            if($(".practice_Areas_primary").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Please Select  Practice Areas Primary</small>').insertAfter($(".practice_Areas_primarylabel"))
                }
            if($(".practice_courts").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Please Select Practice Courts</small>').insertAfter($(".practice_courtslabel"))
                }
            if($(".city").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Please Select City</small>').insertAfter($(".citylabel"))
                }
            if($(".address").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Address can`t empty</small>').insertAfter($(".addresslabel"))
                }
            if($(".pincode").val() == "")
                {
                $('<small class="text-danger required-notice mb-2"> <i class="fa fa-warning"></i>Pincode can`t empty</small>').insertAfter($(".pincodelabel"))
                }
                else{
                    if($(".required-notice").val() != "")
                    {
                        $(".step-two-conn").addClass("d-none");
                        $(".step-three-conn").removeClass("d-none");
                    }
                    else{
                        return false;
                    }
        
    }
})

//back btn
$(".step-one-back").click(function(){
    $(".step-one-conn").removeClass("d-none");
    $(".step-two-conn").addClass("d-none");
})

$(".step-two-back").click(function(){
    $(".step-three-conn").addClass("d-none");
    $(".step-two-conn").removeClass("d-none");
})

$(".step-three-back").click(function(){
    
    $(".step-for-conn").addClass("d-none");
    $(".step-three-conn").removeClass("d-none");
})
$(".step-for-back").click(function(){
   
    $(".step-five-conn").addClass("d-none");
    $(".step-for-conn").removeClass("d-none");
})
$(".step-five-back").click(function(){
    
    $(".step-six-conn").addClass("d-none");
    $(".step-five-conn").removeClass("d-none");
})
$(".step-six-back").click(function(){
  
    $(".step-seven-conn").addClass("d-none");
    $(".step-six-conn").removeClass("d-none");
})

//next btn 
$(".step-three-next").click(function(){
    $(".step-three-conn").addClass("d-none");
    $(".step-for-conn").removeClass("d-none");
})
$(".step-for-next").click(function(){
    $(".step-for-conn").addClass("d-none");
    $(".step-five-conn").removeClass("d-none");
})
$(".step-five-next").click(function(){
    $(".step-five-conn").addClass("d-none");
    $(".step-six-conn").removeClass("d-none");
})
$(".step-six-next").click(function(){
    $(".step-six-conn").addClass("d-none");
    $(".step-seven-conn").removeClass("d-none");
})
$(document).ready(function() {
   
    $.ajax({
        type: 'get',
        url: '/get_data_PD',
        data: {'email':$('.get_email').val()},
        dataType: 'json',
        beforeSend: function() {
            $(".loader-icon").removeClass('d-none');
        },
        success: function(data, response) {
            
            if(data.status==200){
                
                $(".fname").val(data.data.fname);
                $(".mobile").val(data.data.mobile)
                $(".email").val($('.get_email').val())
                if(data.data.profileImage){
                    $(".profileImage").attr("src","/fileurtax/serviceprovider/"+$('.get_email').val()+"/"+data.data.profileImage)
                }else{
                    $(".profileImage").attr("src","images/laywerProfile.jpg");
                }
               
            }
            //    
           
        }
    });
});
   
    $(document).ready(function() {


        $(".barCouncildD").on("change",function(){
            var barcouncil = document.querySelector('.barCouncildD')['files'][0];
            if(barcouncil.size/1024 <= 300 ){
                var reader =  new FileReader(barcouncil);
            // reader.readAsDataURL(file);
            reader.onload =function () {
                sessionStorage.setItem("img",reader.result);
            }
            }else{
                alert("Upload less then 300kb file");
            }
            reader.readAsDataURL(barcouncil);
        })
        $(".aadhar_file").on("change",function(){
            var aadharfile = document.querySelector('.aadhar_file')['files'][0];
            if(aadharfile.size/1024 <= 300 ){
                var reader =  new FileReader(aadharfile);
            // reader.readAsDataURL(file);
            reader.onload =function () {
                sessionStorage.setItem("aadhar_img",reader.result);
            }
            }else{
                alert("Upload less then 300kb file");
            }
            reader.readAsDataURL(aadharfile);
        })

        $(".pancard_file").on("change",function(){
            var pancardfile = document.querySelector('.pancard_file')['files'][0];
            if(pancardfile.size/1024 <= 300 ){
                var reader =  new FileReader(pancardfile);
            // reader.readAsDataURL(file);
            reader.onload =function () {
                sessionStorage.setItem("pan_img",reader.result);
            }
            }else{
                alert("Upload less then 300kb file");
            }
            reader.readAsDataURL(pancardfile);
        })

        $('.form_submit').click(function() {
            
            var monday = "",
                tuesday = "",
                wednesday = "",
                thursday = "",
                friday = "",
                saturday = "",
                sunday = "";
            if ($('.monday').is(':checked')) {
                var inputs = $(".mon_slot_1");
                var mon = []
                for (var i = 0; i < inputs.length; i++) {
                    mon.push($(inputs[i]).val());
                    
                }
                var inputs = $(".mon_slot_2");
                for (var i = 0; i < inputs.length; i++) {
                    mon.push($(inputs[i]).val());
                }
                if (mon[2] != "") {
                    monday = mon[0] + '_' + mon[1] + '-' + mon[2] + '_' + mon[3];
                } else {
                    monday = mon[0] + '_' + mon[1] + '-';
                }
               
            } else {
                monday = "";
            }
            if ($('.tuesday').is(':checked')) {
                var inputs = $(".tue_slot_1");
                var tue = [];
                for (var i = 0; i < inputs.length; i++) {
                    tue.push($(inputs[i]).val());
                }
                var inputs = $(".tue_slot_2");
                for (var i = 0; i < inputs.length; i++) {
                    tue.push($(inputs[i]).val());
                }
                if (tue[2] != "") {
                    tuesday = tue[0] + '_' + tue[1] + '-' + tue[2] + '_' + tue[3];
                } else {
                    tuesday = tue[0] + '_' + tue[1] + '-';
                }
                
            } else {
                tuesday = "";
            }

            if ($('.wednesday').is(':checked')) {

                var inputs = $(".wed_slot_1");
                var wed = [];
                for (var i = 0; i < inputs.length; i++) {
                    wed.push($(inputs[i]).val());
                }
                var inputs = $(".wed_slot_2");
                for (var i = 0; i < inputs.length; i++) {
                    wed.push($(inputs[i]).val());
                }
                if (wed[2] != "") {
                    wednesday = wed[0] + '_' + wed[1] + '-' + wed[2] + '_' + wed[3];
                } else {
                    wednesday = wed[0] + '_' + wed[1] + '-';
                }

                
            } else {
                wednesday = "";
            }
            if ($('.thursday').is(':checked')) {
                var inputs = $(".thu_slot_1");
                var thu = [];
                for (var i = 0; i < inputs.length; i++) {
                    thu.push($(inputs[i]).val());
                }
                var inputs = $(".thu_slot_2");
                for (var i = 0; i < inputs.length; i++) {
                    thu.push($(inputs[i]).val());
                }
                if (thu[2] != "") {
                    thursday = thu[0] + '_' + thu[1] + '-' + thu[2] + '_' + thu[3];
                } else {
                    thursday = thu[0] + '_' + thu[1] + '-';
                }
                
            } else {
                thursday = "";
            }
            if ($('.friday').is(':checked')) {
                var inputs = $(".fri_slot_1");
                var fri = [];
                for (var i = 0; i < inputs.length; i++) {
                    fri.push($(inputs[i]).val());
                }
                var inputs = $(".fri_slot_2");
                for (var i = 0; i < inputs.length; i++) {
                    fri.push($(inputs[i]).val());
                }
                if (fri[2] != "") {
                    friday = fri[0] + '_' + fri[1] + '-' + fri[2] + '_' + fri[3];
                } else {
                    friday = fri[0] + '_' + fri[1] + '-';
                }

               
            } else {
                friday = "";
            }
            if ($('.saturday').is(':checked')) {
                var inputs = $(".sat_slot_1");
                var sat = [];
                for (var i = 0; i < inputs.length; i++) {
                    sat.push($(inputs[i]).val());
                }
                var inputs = $(".sat_slot_2");
                for (var i = 0; i < inputs.length; i++) {
                    sat.push($(inputs[i]).val());
                }
                if (sat[2] != "") {
                    saturday = sat[0] + '_' + sat[1] + '-' + sat[2] + '_' + sat[3];
                } else {
                    saturday = sat[0] + '_' + sat[1] + '-';
                }
                
            } else {
                saturday = "";
            }
            if ($('.sunday').is(':checked')) {
                var inputs = $(".sun_slot_1");
                var sun = [];
                for (var i = 0; i < inputs.length; i++) {
                    sun.push($(inputs[i]).val());
                }
                var inputs = $(".sun_slot_2");
                for (var i = 0; i < inputs.length; i++) {
                    sun.push($(inputs[i]).val());
                }
                if (sun[2] != "") {
                    sunday = sun[0] + '_' + sun[1] + '-' + sun[2] + '_' + sun[3];
                } else {
                    sunday = sun[0] + '_' + sun[1] + '-';
                }
                
            } else {
                sunday = "";
            }

            // service checkbox validation
            var val = [];
            $('.serviceselect').each(function(i){
                if($(this).is(':checked')){
                    val[i] =  $(this).val();
                }
            });
            var barEnrollmentNumber;
            if($(".barEnrollmentNumber").val() == ""){
                barEnrollmentNumber  = " ";
            }else{
            barEnrollmentNumber = $(".barEnrollmentNumber").val();
            }
            var services =  val.join(",");
            // end service checkbox validation

            var fname = $(".fname").val();
            var mobile = $(".mobile").val();
            var email = $(".email").val();
            var gender = $("input[name=gender]:checked").val();
            var practincingSince = $(".practincingSince").val();
            var amount = $(".amount").val();
            var secondary_practice_area = $(".secondary_practice_area").val();
            var country = $(".country").val();
            var language = $(".language").val();
            var practice_state = $(".practice_state").val();
            var state = $(".state").val();
            var enrollment_state = $(".enrollment_state").val();
            var practice_Areas_primary = $(".practice_Areas_primary").val();
            var practice_courts = $(".practice_courts").val();
            var city = $(".city").val();
            var address = $(".address").val();
            var pincode = $(".pincode").val();
            var abouts = $(".abouts").val();
            var facebook = $(".facebook").val();
            var twitter = $(".twitter").val();
            var linkedin = $(".linkedin").val();
            var publication_areas_1 = $(".publication_areas_1").val();
            var publication_areas_2 = $(".publication_areas_2").val();
            var publication_areas_3 = $(".publication_areas_3").val();
            var lat = $(".lat").val();
            var longt = $(".longt").val();
            var aadhaarcard = $(".aadhaarcard").val();
            var pancard = $(".pancard").val();
            var recognitions = $(".recognitions").val();

                var data = {
                    'recognitions': recognitions,
                    'fname': fname,
                    'mobile': mobile,
                    'email': email,
                    'gender': gender,
                    'practincingSince': practincingSince,
                    'amount': amount,
                    'secondary_practice_area': secondary_practice_area,
                    'country': country,
                    'registrationNumber': barEnrollmentNumber,
                    'language': language,
                    'practice_state': practice_state,
                    'state': state,
                    'experience': enrollment_state,
                    'practice_Areas_primary': practice_Areas_primary,
                    'practice_courts': practice_courts,
                    'city': city,
                    'address': address,
                    'pincode': pincode,
                    'description': abouts,
                    'facebook': facebook,
                    'twitter': twitter,
                    'linkedin': linkedin,
                    'publication_areas_1': publication_areas_1,
                    'publication_areas_2': publication_areas_2,
                    'publication_areas_3': publication_areas_3,
                    'monday': monday,
                    'tuesday': tuesday,
                    'wednesday': wednesday,
                    'thursday': thursday,
                    'friday': friday,
                    'saturday': saturday,
                    'sunday': sunday,
                    'lat': lat,
                    'longt': longt,
                    'aadhaarcard': aadhaarcard,
                    'pancard': pancard,
                    '_token': $("body").attr('token'),
                    'firmid':sessionStorage.getItem('img'),
                    'aadhar_img':sessionStorage.getItem('aadhar_img'),
                    'pan_img':sessionStorage.getItem('pan_img'),
                    'services':services
                }
                $.ajax({
                    type: 'post',
                    url: '/registerlawyersignupca',
                    data: data,
                    dataType: 'json',
                    beforeSend: function() {
                        $(".form_submit").html('<span>Please Wait </span><i class="fa fa-spinner fa-spin text-white" style="font-size:24px"></i>');
                    },
                    success: function(data, response) {
                        $(".form_submit").html("Submit")
                        if(data.status==200){
                            sessionStorage.clear();
                            window.location.href = '/caDashboard';
                        }else{
                            alert('something went wrong');
                            window.location.href = '/loginpage';
                        }
                    }
                });
            
            
        })
    })

    $(".field").on("input",function(){
        $(".required-notice").addClass("d-none");
        // $(".required-notice").html('');
        // $(".required-notice").remove();
    })

    $("select").on("change",function(){
        $(".required-notice").addClass("d-none");
        $(".required-notice").html('');
        $(".required-notice").remove();
    })

    $(document).ready(function() {
        $('#kgRatingModal').modal('show');
        $("#hideKgModal").click(function() {
            $("#kgRatingModal").modal("hide");
        });

        $('.jq_first_half_from').timepicker({
            'timeFormat': 'h:i a',
            'minTime': '10:00',
            'maxTime': '12:30',
            'showDuration': false,
            'step': '30',
            'disableTextInput': true,
            'disableTouchKeyboard': true,
        }).keydown(function(event) {
            if (event.keyCode == 8 || event.keyCode == 46) {
                event.preventDefault();
            }
        });

        $('.jq_first_half_to').timepicker({
            'timeFormat': 'h:i a',
            'minTime': '10:30',
            'maxTime': '13:00',
            'showDuration': false,
            'step': '30',
            'disableTextInput': true,
            'disableTouchKeyboard': true,
        }).keydown(function(event) {
            if (event.keyCode == 8 || event.keyCode == 46) {
                event.preventDefault();
            }
        });

        $(".jq_first_half_from").on('change', function() {
            var day = $(this).attr('day');

            var time = $(this).val();
            var minsToAdd = 30;
            var newTime = new Date(new Date("1970/01/01 " + time).getTime() + minsToAdd * 60000)
                .toLocaleTimeString('en-UK', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                });

            // set time picker
            $("#jq_first_half_" + day).val('');
            $("#jq_first_half_" + day).timepicker('option', {
                'minTime': newTime,
                'maxTime': '13:00'
            });
        });

        $('.jq_second_half_from').timepicker({
            'timeFormat': 'h:i a',
            'minTime': '14:00',
            'maxTime': '22:30',
            'showDuration': false,
            'step': '30',
            'disableTextInput': true,
            'disableTouchKeyboard': true,
        }).keydown(function(event) {
            if (event.keyCode == 8 || event.keyCode == 46) {
                event.preventDefault();
            }
        });

        $('.jq_second_half_to').timepicker({
            'timeFormat': 'h:i a',
            'minTime': '14:30',
            'maxTime': '23:00',
            'showDuration': false,
            'step': '30',
            'disableTextInput': true,
            'disableTouchKeyboard': true,
        }).keydown(function(event) {
            if (event.keyCode == 8 || event.keyCode == 46) {
                event.preventDefault();
            }
        });

        $(".jq_second_half_from").on('change', function() {
            var day = $(this).attr('day');

            var time = $(this).val();
            var minsToAdd = 30;
            var newTime = new Date(new Date("1970/01/01 " + time).getTime() + minsToAdd * 60000)
                .toLocaleTimeString('en-UK', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                });

            // set time picker
            $("#jq_second_half_" + day).val('');
            $("#jq_second_half_" + day).timepicker('option', {
                'minTime': newTime,
                'maxTime': '23:00'
            });
        });

        var preSelectedDates = "";
        preSelectedDates = (preSelectedDates !== "") ? preSelectedDates.split(',') : '';

        var selectedDates = (preSelectedDates !== "") ? preSelectedDates : new Array();
        $('#datetimepicker').multiDatesPicker({
            minDate: 0,
            maxDate: 90,
            onSelect: function(dateStr) {
                if (selectedDates.includes(dateStr)) {
                    var index = selectedDates.indexOf(dateStr);

                    if (index !== -1) {
                        selectedDates.splice(index, 1);
                    }
                } else {
                    selectedDates.push(dateStr);
                }

                $("#userOffDate").val(selectedDates).trigger('change');
            }
        });

        if (typeof selectedDates !== 'undefined' && selectedDates.length > 0) {
            $('#datetimepicker').multiDatesPicker('addDates', selectedDates)
        }

        $(".languages").multiselect({
            buttonWidth: '100%',
            menuWidth: '100%',
            noneSelectedText: 'Select languages',
            selectedList: 5,
        }).multiselectfilter();

        $(".practising_courts").multiselect({
            buttonWidth: '100%',
            menuWidth: '100%',
            noneSelectedText: 'Select Practising Courts',
            selectedList: 3,
        }).multiselectfilter();

        // Primary Practice area (multi-select)
        var primarywarning = $("#primary-practice");
        $(".practice_areas").multiselect({
            buttonWidth: '100%',
            menuWidth: '100%',
            noneSelectedText: 'Select Practice Areas (Primary)',
            selectedList: 1,
            maxSelected: 3,
            click: function(event, ui) {
                if ($(this).multiselect("widget").find("input:checked").length > 3) {
                    toastr.error("Only Three Primary Practice areas can be selected", "", {
                        positionClass: "toast-top-center"
                    });
                    return false;
                }
            }
        }).multiselectfilter();

        // Secondary Practice area (multi-select)
        $(".secondary_practice_areas").multiselect({
            buttonWidth: '100%',
            menuWidth: '100%',
            noneSelectedText: 'Select Practice Areas (Secondary)',
            selectedList: 1,
            maxSelected: 2,
            click: function(event, ui) {
                if ($(this).multiselect("widget").find("input:checked").length > 2) {
                    toastr.error("Only two Secondary Practice areas can be selected", "", {
                        positionClass: "toast-top-center"
                    });
                    return false;
                }
            }
        }).multiselectfilter();





        function get_selected(class_name) {
            var select = [];

            $.each($("." + class_name + " option:selected"), function() {
                select.push($(this).val());
            });

            return select;
        }






        $('#barCouncilImage').change(function(e) {
            $(".input-file-trigger").text("Update file");
            $(".file-return").html(e.target.files[0].name);
        });

        let cropper = '';
        let cropperModalId = '#cropperModal';
        let $jsPhotoUploadInput = $('#filePhoto');
        let dwn = document.querySelector('.profile_image');

        $jsPhotoUploadInput.on('click', function() {
            this.value = null;
        });

        $jsPhotoUploadInput.on('change', function() {
            var files = this.files;

            var name = files[0].name;
            var ext = name.split('.').pop().toLowerCase();

            var f = files[0];
            var fsize = f.size || f.fileSize;
            if (jQuery.inArray(ext, ['png', 'jpg', 'jpeg', 'jfif', 'heic']) == -1) {
                toastr.error('Invalid Image File. Support formats: png, jpg, jpeg, jfif');
            } else if (fsize > 5000000) {
                toastr.error('The profile image can not be more than 5MB');
            } else {
                if (files.length > 0) {
                    var photo = files[0];
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        var image = $('.js-avatar-preview')[0];

                        image.src = event.target.result;
                        cropper = new Cropper(image, {
                            viewMode: 1,
                            aspectRatio: 1 / 1.17,
                            minContainerWidth: 290,
                            minContainerHeight: 337,
                            minCropBoxWidth: 290,
                            minCropBoxHeight: 337,
                            rotatable: false,
                            zoomable: false,
                            checkOrientation: false,
                            cropBoxResizable: false
                        });

                        $(cropperModalId).modal();
                    };

                    reader.readAsDataURL(photo);
                }
            }
        });

        $('.js-save-cropped-avatar').on('click', function(event) {
            event.preventDefault();

            const canvas = cropper.getCroppedCanvas();
            const base64encodedImage = canvas.toDataURL();

            $('.profile_image').attr('src', base64encodedImage)
            $(cropperModalId).modal('hide');

            // Store base64 Image
            var base64data = base64encodedImage;

            cropper.destroy();
            $jsPhotoUploadInput.replaceWith($jsPhotoUploadInput.val('').clone(true))
            $('.uploader.one').addClass('hide');
            $('.uploader.two, .upload-pos').removeClass('hide');
        });

        $('.close').click(function() {
            cropper.destroy();
            $jsPhotoUploadInput.replaceWith($jsPhotoUploadInput.val('').clone(true))
        });

        $(".custom-checkbox").click(function() {
            var checked = $(this).find('input').is(":checked");
            if (!checked) {
                $(this).nextAll().find('input').val('');
                $(this).nextAll().find('input').attr('disabled', 'disabled');
            } else {
                $(this).nextAll().find('input').removeAttr('disabled');
            }
        });
    });


    // save unfinished  form
    var sessionUserId = '';
    $('input, textarea, checkbox, radio, select, #userOffDate').on('change', function() {
        var columnName = $(this).attr("name");
        var value = $(this).val();
        if (columnName === 'accept_terms_conditions') {
            if ($('#accept_terms_conditions').is(':checked')) {
                value = 'on';
            } else {
                value = 'off';
            }
        }
        if ($(this).hasClass("weeklyPlan")) {
            var data = $('.weeklyPlanAll').map(function() {
                let week = getWeeklyPlanArray();
                return [{

                    mon: {
                        wp_mon: $(this).find('[name="wp_mon"]').val(),
                        wp_mon_time: week.mon,
                    },
                    tue: {
                        wp_tue: $(this).find('[name="wp_tue"]').val(),
                        wp_tue_time: week.tue,
                    },
                    wed: {
                        wp_wed: $(this).find('[name="wp_wed"]').val(),
                        wp_wed_time: week.wed,
                    },
                    thu: {
                        wp_thu: $(this).find('[name="wp_thu"]').val(),
                        wp_thu_time: week.thu,
                    },
                    fri: {
                        wp_fri: $(this).find('[name="wp_fri"]').val(),
                        wp_fri_time: week.fri,
                    },
                    sat: {
                        wp_sat: $(this).find('[name="wp_sat"]').val(),
                        wp_sat_time: week.sat,
                    },
                    sun: {
                        wp_sun: $(this).find('[name="wp_sun"]').val(),
                        wp_sun_time: week.sun,
                    }

                }];
            }).get();


        }
    });

    function getWeeklyPlanArray() {
        let wpMon = [];
        $('[name="wp[mon][]"]').each(function() {
            wpMon.push($(this).val());
        });

        let wpTue = [];
        $('[name="wp[tue][]"]').each(function() {
            wpTue.push($(this).val());
        });

        let wpwed = [];
        $('[name="wp[wed][]"]').each(function() {
            wpwed.push($(this).val());
        });

        let wpthu = [];
        $('[name="wp[thu][]"]').each(function() {
            wpthu.push($(this).val());
        });

        let wpfri = [];
        $('[name="wp[fri][]"]').each(function() {
            wpfri.push($(this).val());
        });

        let wpsat = [];
        $('[name="wp[sat][]"]').each(function() {
            wpsat.push($(this).val());
        });

        let wpsun = [];
        $('[name="wp[sun][]"]').each(function() {
            wpsun.push($(this).val());
        });
        return {
            mon: wpMon,
            tue: wpTue,
            wed: wpwed,
            thu: wpthu,
            fri: wpfri,
            sat: wpsat,
            sun: wpsun
        };
    }

   


    $(document).ready(function() {
        $('.mobile').on('keypress', function(e) {
            var $this = $(this);
            var regex = new RegExp("^[0-9\b]+$");
            var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
            // for 10 digit number only
            if ($this.val().length > 9) {
                e.preventDefault();
                return false;
            }
            if (e.charCode < 54 && e.charCode > 47) {
                if ($this.val().length == 0) {
                    // warning for validate mobile number
                    e.preventDefault();
                    return false;
                } else {
                    return true;
                }

            }
            if (regex.test(str)) {
                return true;
            }
            e.preventDefault();
            return false;
        });
        $('.aadhaarcard').on('keypress', function(e) {
            var $this = $(this);
            var regex = new RegExp("^[0-9\b]+$");
            var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
            // for 10 digit number only
            if ($this.val().length > 11) {
                e.preventDefault();
                return false;
            }
        });
    });
    
    $(document).ready(function() {
        $('.pancard').on('input', function(e) {
           var pancard_val = $('.pancard').val();
            var regex = /([A-Z]){5}([0-9]){4}([A-Z]){1}$/;
        if (regex.test(pancard_val.toUpperCase())) {
            
            $(".required-notice-pancard").html("");
        } else {
            $(".required-notice-pancard").html("");
            $('<small class="text-danger required-notice-pancard mb-2"> <i class="fa fa-warning"></i>Please Enter Valid PAN Card</small>').insertAfter($(".pancardlabel"))
        }
        });


    });
$(document).ready(function(){
    $('.state').on('change', function() {
        
        var data = {
            token: $('#token').val(),
            state: $(".state option:selected").val()
        
        };
        
        $.ajax({
            type: "GET",
            url: "/get_city/" + data.state,

            data: data,

            beforeSend: function() {
                $(".loader-icon").removeClass('d-none');
            },
            success: function(data, response) {

                if (data.status == 200) {
                    var data = data.data;
                    $('.city').html('');
                    $('.city').append("<option value='0' selected>Select City</option>");

                    $(data).each(function(index, value) {
                        
                        $('.city').append("<option  value=" + value.city_name + ">" + value
                            .city_name + "</option>");
                    });
                }
            }
        });
    });
})
