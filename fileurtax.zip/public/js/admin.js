$(document).ready(function () {
    // start point
$(".support-btn").click(function () {
    $.ajax({
        type: "GET",
        url: "/support",
        dataType: "json",
        beforeSend: function () {
            $(".loader-icon").removeClass("d-none"), $(".service_pr_body").html(""), $(".service_pr_head").html("");
        },
        success: function (data, b) {
                $(".userdata-display").html(""),
                $(".service_pr_body").html(""),
                $(".service_pr_head").html(""),
                $(".service_pr_head").html('<tr><th scope="col">Ticket Id</th><th scope="col">Subject</th><th scope="col">Request Type</th><th scope="col">Mobile</th>'),
                $(data.data).each(function (index, value) {
                    $.ajax({
                        type: "GET",
                        url: "/supportname/"+value.users_id,
                        dataType: "json",
                        beforeSend: function () {
                            $(".loader-icon").removeClass("d-none"), $(".service_pr_body").html(""), $(".service_pr_head").html("");
                        },
                        success : function(username){
                            $(".heading").html("Support"),
                            $(".userdata-display").append('<tr><td scope="row">'+value.ticket_id+'</td><td>' +value.subject +'</td><td>' +value.requesttype +'</a></td><td>'+username.username+"</a></td></tr>");
                        }
                    });
                    
                });
        },
    });
});

$(".delete_blog").each(function(){
    $(this).click(function(){
        $.ajax({
            type: "GET",
            url: "/deleteBlog",
            data:{id:$(this).attr('id')},
            dataType: "json",
            success: function (data, response){
                window.location.href="/adminblog"
            }
        })
        
    })
    
})

$(".helpview").click(function(){
    $.ajax({
        type: "GET",
        url: "/viewhelp",
        data:{id:$(this).attr('custid')},
        success: function (res){
            console.log(res);
           var viewdata = `<div class="modal fade" id="viewhelpmodal" tabindex="-1" aria-labelledby="viewhelpmodal" aria-hidden="true">
           <div class="modal-dialog modal-dialog-centered">
             <div class="modal-content">
               <div class="modal-header">
                 <h5 class="modal-title" id="viewhelpmodal">Customer Ticket</h5>
                 <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
               </div>
               <div class="modal-body">
                 <p>Request Type : `+res.data.requesttype+`</p>
                 <p>subject : `+res.data.subject+`</p>
                 <p>Ticket Id : `+res.data.ticket_id+`</p>
                 <p>Message : `+res.data.description+`</p>
               </div>
               <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" solveid="`+res.data.users_id+`" class="btn btn-primary helpsolve">Solve</button>
               </div>
             </div>
           </div>
         </div>`;
         $(".viewhelpmodal").append(viewdata);
         $('#viewhelpmodal').modal('show');
         $(".helpsolve").click(function(){
            $.ajax({
                type: "GET",
                url: "/helpsolve",
                data:{id:$(this).attr('solveid')},
                success: function (response){
                    console.log();
                    if(response.data == "success"){
                        window.location.href = "/adminhelp";
                    }else{
                        alert(response.data);
                    }
                }
            })
         })
        }
    })
  })
//   end point
});  
   
    



